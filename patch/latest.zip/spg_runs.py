# -*- coding: utf-8 -*-
"""牌局记录（复盘）：按「每回合商店基线」比对

规则（用户指定）：
1. 每回合第一次看到商店 → 截一张图，作为这一回合的**基线**
2. 金额 -1 且整排都变了 → **刷新**（刷新后重新截图，作为后续基线）
3. 金额变了、商品槽向左扩充一个空位 → **升本**
4. 金额变了、商品和基线相比少了东西 → **买**（记名字，不校验谁买的）
5. 商品不变、金额增加 → **卖出**（不统计卖了谁）
6. 第 14 回合结束生成复盘；如果触发第 15 回合，15 回合的变动并入 14 回合
"""
import io
import json
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))
import spg_paths
ROOT = spg_paths.ROOT
RUNS_DIR = os.path.join(ROOT, 'records', 'runs')
PATH = os.path.join(ROOT, 'runs.json')
CUR = os.path.join(ROOT, 'runs_current.json')
REPORT = os.path.join(ROOT, '复盘-最近3把.txt')
MAX_RUNS = 3


def _read(path, default):
    try:
        with io.open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def _write(path, obj):
    try:
        with io.open(path, 'w', encoding='utf-8') as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def _fmt_covs(covs):
    if not covs:
        return '—'
    return ' '.join('%s%d' % (k, v) for k, v in sorted(covs.items(), key=lambda x: -x[1])[:6] if v)


def _report(runs):
    lines = ['# 卫戍协议 · 最近 %d 把复盘' % len(runs), '']
    for run in runs:
        lines.append('## %s ~ %s  %s  %s' % (run.get('start', ''), run.get('end', ''),
                                             run.get('map', ''), run.get('plan', '')))
        for e in run.get('events') or []:
            lines.append('R%-2s %s  %-30s 金%-3s  层[%s]' % (
                e.get('r'), e.get('time', ''), e.get('act', ''), e.get('gold'),
                _fmt_covs(e.get('covs'))))
        lines.append('')
    try:
        io.open(REPORT, 'w', encoding='utf-8').write('\n'.join(lines))
    except Exception:
        pass


def start(holder, map_name='', plan_title=''):
    cur = _read(CUR, None)
    if not cur or cur.get('id') != holder.get('_run_id'):
        if cur and (cur.get('events') or cur.get('shots')):
            finalize(holder, 'new-run')
            cur = _read(CUR, None)
    if not cur or cur.get('id') != holder.get('_run_id'):
        cur = {'id': time.strftime('%Y%m%d_%H%M%S'), 'start': time.strftime('%m-%d %H:%M'),
               'map': map_name, 'plan': plan_title, 'events': [], 'shots': []}
        holder['_run_id'] = cur['id']
        holder['_shot_seq'] = 0
        holder['_base'] = None
        _write(CUR, cur)
    return cur


def _snap(holder, cur, img, tag, rnd, gold, shop, covs):
    """存一张图（基线/刷新时用）"""
    try:
        seq = int(holder.get('_shot_seq') or 0) + 1
        holder['_shot_seq'] = seq
        d = os.path.join(RUNS_DIR, cur['id'])
        os.makedirs(d, exist_ok=True)
        fn = '%02d_%s_R%s_%s.png' % (seq, tag, rnd, gold)
        fp = os.path.join(d, fn)
        if img is not None:
            img.save(fp)
        return os.path.relpath(fp, ROOT).replace('\\', '/')
    except Exception:
        return ''


def note_frame(holder, img, round_no, gold, shop, covs=None, map_name=''):
    """每一帧（休整期）调用：跟本回合基线比对，产出操作事件"""
    try:
        if round_no is None or gold is None:
            return None
        cur = start(holder, map_name)
        shop = [[n, int(p or 0)] for n, p in (shop or [])]
        # 资金要去抖：连续两帧读到同一个数才算数（OCR 偶尔把 2 读成 25）
        if holder.get('_gold_prev') != gold:
            holder['_gold_prev'] = gold
            return cur
        base = holder.get('_base')
        # 新回合 / 第一次进入 → 建基线
        if not base or base.get('r') != round_no:
            if not shop:
                return cur      # 商店还没读出来，等下一帧
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
            f = _snap(holder, cur, img, 'initial', round_no, gold, shop, covs)
            cur.setdefault('baselines', []).append({'r': round_no, 'gold': gold,
                                                    'shop': shop, 'file': f})
            _write(CUR, cur)
            return cur
        if not shop:                      # 商店收起，不比对
            return cur
        if not (base.get('shop') or []):  # 基线也没牌，没法比
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
            return cur
        d = gold - int(base.get('gold') or 0)
        bshop = [tuple(x) for x in (base.get('shop') or [])]
        cshop = [tuple(x) for x in shop]
        removed = [n for n, _ in bshop if n not in [c[0] for c in cshop]]
        added = [n for n, _ in cshop if n not in [b[0] for b in bshop]]
        if d == 0 and not removed and not added:
            return cur

        ev = None
        if d == -1 and len(removed) >= 3:
            ev = ('刷新', -1)
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
            f = _snap(holder, cur, img, 'refresh', round_no, gold, shop, covs)
            cur.setdefault('shots', []).append(f)
        elif d < 0 and added and not removed:
            ev = ('升本', d)
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
        elif d < 0 and removed:
            ev = ('买 ' + '/'.join(removed), d)
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
        elif d > 0 and not removed and not added:
            ev = ('卖出', d)
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
        elif d < 0:
            ev = ('升本', d)
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}
        elif d > 0:
            ev = ('收入', d)
            holder['_base'] = {'r': round_no, 'gold': gold, 'shop': shop}

        if ev:
            cur.setdefault('events', []).append({
                'r': round_no, 'time': time.strftime('%H:%M:%S'),
                'act': '%s(%+d金)' % (ev[0], ev[1]), 'gold': gold,
                'covs': dict(covs or {}),
            })
            _write(CUR, cur)
        return cur
    except Exception:
        return None


def finalize(holder, reason='lobby'):
    cur = _read(CUR, None)
    if not cur or not (cur.get('events') or cur.get('shots')):
        try:
            if cur:
                os.remove(CUR)
        except Exception:
            pass
        holder.pop('_run_id', None)
        return None
    cur['end'] = time.strftime('%m-%d %H:%M')
    cur['reason'] = reason
    # 截图保留（用户要对着图复盘），只把 shots 目录记进 runs.json
    try:
        cur['shot_dir'] = 'records/runs/' + cur['id']
    except Exception:
        pass
    runs = _read(PATH, [])
    runs.append(cur)
    _write(PATH, runs[-MAX_RUNS:])
    _report(runs[-MAX_RUNS:])
    try:
        os.remove(CUR)
    except Exception:
        pass
    holder.pop('_run_id', None)
    holder.pop('_base', None)
    return cur
