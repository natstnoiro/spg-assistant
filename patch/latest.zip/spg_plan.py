# -*- coding: utf-8 -*-
"""打法锁定：从 playbooks.json 里挑一套打法，让推荐跟着「这局要做什么」走

用法：
    key, plan = spg_plan.plan_for(hand_names, main_cov)
    recs = spg_score.recommend(..., plan=plan)
    hint = spg_plan.stage_hint(plan, round_no)

规则（以「森蚺 → 不屈灵巧大丑」为例）：
  · 手里的干员命中某套打法的 strategy 名（如 暴躁铁皮）→ 锁定该打法
  · 本家盟约 = engines 的键（不屈/灵巧/卡西米尔）→ 非本家只打 0.75 折，不再砍半
  · priority 前 4 名 +35 分、其余 +18 分
"""
import io, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(HERE, 'data', 'playbooks.json')

with io.open(P, encoding='utf-8') as f:
    PLAY = json.load(f)

# 手动指定：WRITABLE/live_plan.json 里写 {"plan": "卡西米尔·不屈"}
OVERRIDE = os.environ.get('SPG_PLAN') or ''


def _override_path():
    root = os.path.dirname(os.path.dirname(HERE))
    return os.path.join(root, 'live_plan.json')


_OV_CACHE = None


def load_override():
    """手动锁定打法：按 mtime 缓存，切换仍即时生效"""
    global _OV_CACHE
    try:
        path = _override_path()
        mt = os.path.getmtime(path)
    except Exception:
        _OV_CACHE = None
        return ''
    c = _OV_CACHE
    if c and c[0] == mt:
        return c[1]
    v = ''
    try:
        with io.open(path, encoding='utf-8') as f:
            v = (json.load(f) or {}).get('plan') or ''
    except Exception:
        v = ''
    _OV_CACHE = (mt, v)
    return v


def _fits(key, plan, main_cov):
    """这套打法是不是跟当前主盟约一家"""
    if not main_cov:
        return False
    if key == main_cov or key.split('·')[0] == main_cov:
        return True
    return main_cov in (plan.get('engines') or {})


def plan_for(hand, main_cov=None, main_layers=0):
    """返回 (key, plan) 或 (None, None)

    · 手动锁定优先
    · 有主盟约叠层时：只认跟主盟约同家的打法（手里凑了别的家的卡不算）
    · 还没开盟约时：手牌命中 >=2 才自动锁
    """
    key = OVERRIDE or load_override()
    if key and key in PLAY:
        return key, PLAY[key]
    hand = list(hand or [])
    best, best_n = None, 0
    for k, d in PLAY.items():
        names = list(d.get('strategy') or []) + list(d.get('core') or [])
        n = sum(1 for s in names if s in hand)
        if n > best_n:
            best, best_n = k, n
    if main_layers >= 1:
        if best and best_n >= 1 and _fits(best, PLAY[best], main_cov):
            return best, PLAY[best]
        return None, None
    if best_n >= 2:
        return best, PLAY[best]
    if main_cov and main_cov in PLAY:
        return main_cov, PLAY[main_cov]
    return None, None


def family_covs(plan):
    """本家盟约集合（engines 的键 + 核心干员自带的盟约不在此列）"""
    if not plan:
        return set()
    return set((plan.get('engines') or {}).keys())


def stage_hint(plan, round_no=None):
    """一句话：现在该干什么"""
    if not plan:
        return ''
    r = round_no or 0
    if r <= 2:
        return 'R1-2 升2本、先把大丑/核心买到手'
    if r <= 5:
        t = plan.get('targets') or ''
        return 'R3-5 ' + (t.split('→')[0].strip() if t else '叠主盟约层数')
    return 'R6+ 升5本、转终局装备（' + (plan.get('targets') or '').split('→')[-1].strip() + '）'


def equipment_priority(plan):
    """打法里的装备优先级，已把黑话换成官方名（只保留数据里存在的）"""
    raw = list((plan or {}).get('equipment') or [])
    try:
        import spg_ocr
        known = set(spg_ocr.EQUIP_NAMES)
    except Exception:
        known = set()
    alias = {'金不融冰': '谢拉格不融冰'}
    out = []
    for n in raw:
        t = alias.get(n, n)
        if not known or t in known:
            if t not in out:
                out.append(t)
    return out
