# -*- coding: utf-8 -*-
"""不依赖 OpenCV 的图像小工具（打包用）

只有两个功能：模板匹配（归一化互相关，FFT 实现）和孔洞计数。
OpenCV 能装就优先用 OpenCV（快），没有就用这里的 numpy 版（exe 里不带 cv2，省 100MB）。
"""
import os

import numpy as np
from PIL import Image

try:
    import cv2
except Exception:
    cv2 = None

_FORCE_NUMPY = os.environ.get('SPG_NO_CV2') == '1'


def have_cv2():
    return (cv2 is not None) and not _FORCE_NUMPY


def load_gray(path):
    """读成灰度 ndarray"""
    if have_cv2():
        im = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
        if im is not None:
            return im
    return np.asarray(Image.open(path).convert('L'))


def _box_sum(S, h, w):
    return S[h:, w:] - S[:-h, w:] - S[h:, :-w] + S[:-h, :-w]


def match_template(a, t):
    """归一化互相关（等价 cv2.TM_CCOEFF_NORMED），返回 (H-h+1, W-w+1)"""
    if have_cv2():
        return cv2.matchTemplate(a.astype(np.uint8), t.astype(np.uint8), cv2.TM_CCOEFF_NORMED)
    a = np.asarray(a, dtype=np.float32)
    t = np.asarray(t, dtype=np.float32)
    th, tw = t.shape
    ah, aw = a.shape
    if th > ah or tw > aw:
        return np.zeros((0, 0), np.float32)
    t0 = t - t.mean()
    tn = float(np.sqrt((t0 * t0).sum())) or 1.0

    A = np.pad(a, ((1, 0), (1, 0)), mode='constant')
    S1 = A.cumsum(0).cumsum(1)
    S2 = (A * A).cumsum(0).cumsum(1)
    n = float(th * tw)
    s1 = _box_sum(S1, th, tw)
    s2 = _box_sum(S2, th, tw)
    mean = s1 / n
    var = np.maximum(s2 / n - mean * mean, 1e-6)

    H, W = ah + th - 1, aw + tw - 1
    fa = np.fft.rfft2(a, (H, W))
    ft = np.fft.rfft2(t0[::-1, ::-1], (H, W))
    cc = np.fft.irfft2(fa * ft, (H, W))[th - 1:th - 1 + ah - th + 1,
                                        tw - 1:tw - 1 + aw - tw + 1]
    return cc / (np.sqrt(var * n) * tn)


def count_holes(mask):
    """封闭孔洞数：先把与边界连通的背景清掉，再数剩下的连通块"""
    if have_cv2():
        inv = (1 - mask).astype(np.uint8)
        h, w = inv.shape
        if h < 3 or w < 3:
            return 0
        ff = inv.copy()
        pad = np.zeros((h + 2, w + 2), np.uint8)
        for x in range(w):
            if ff[0, x]:
                cv2.floodFill(ff, pad, (x, 0), 0)
            if ff[h - 1, x]:
                cv2.floodFill(ff, pad, (x, h - 1), 0)
        for y in range(h):
            if ff[y, 0]:
                cv2.floodFill(ff, pad, (0, y), 0)
            if ff[y, w - 1]:
                cv2.floodFill(ff, pad, (w - 1, y), 0)
        return max(0, int(cv2.connectedComponents(ff)[0]) - 1)

    inv = (1 - np.asarray(mask)).astype(np.uint8)
    h, w = inv.shape
    if h < 3 or w < 3:
        return 0
    seen = np.zeros_like(inv, dtype=bool)
    # 从边界泛洪，标记所有与边界连通的反色像素
    stack = []
    for x in range(w):
        if inv[0, x] and not seen[0, x]:
            stack.append((0, x))
        if inv[h - 1, x] and not seen[h - 1, x]:
            stack.append((h - 1, x))
    for y in range(h):
        if inv[y, 0] and not seen[y, 0]:
            stack.append((y, 0))
        if inv[y, w - 1] and not seen[y, w - 1]:
            stack.append((y, w - 1))
    while stack:
        y, x = stack.pop()
        if y < 0 or y >= h or x < 0 or x >= w or seen[y, x] or not inv[y, x]:
            continue
        seen[y, x] = True
        stack.extend(((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)))
    rest = inv.astype(bool) & (~seen)
    # 剩下的连通块个数
    total = 0
    visited = np.zeros_like(rest, dtype=bool)
    for y in range(h):
        for x in range(w):
            if rest[y, x] and not visited[y, x]:
                total += 1
                stack = [(y, x)]
                while stack:
                    cy, cx = stack.pop()
                    if cy < 0 or cy >= h or cx < 0 or cx >= w or visited[cy, cx] or not rest[cy, cx]:
                        continue
                    visited[cy, cx] = True
                    stack.extend(((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1)))
    return total


def largest_box(mask):
    """最大连通块的外接框 (x, y, w, h)；没有返回 None"""
    m = np.asarray(mask).astype(np.uint8)
    h, w = m.shape
    if m.sum() < 10:
        return None
    if have_cv2():
        n, _lab, stats, _c = cv2.connectedComponentsWithStats(m, 8)
        if n <= 1:
            return None
        k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        return (int(stats[k, cv2.CC_STAT_LEFT]), int(stats[k, cv2.CC_STAT_TOP]),
                int(stats[k, cv2.CC_STAT_WIDTH]), int(stats[k, cv2.CC_STAT_HEIGHT]))
    seen = np.zeros_like(m, dtype=bool)
    best = None
    best_area = 0
    for y0 in range(h):
        for x0 in range(w):
            if not m[y0, x0] or seen[y0, x0]:
                continue
            stack = [(y0, x0)]
            area = 0
            x1 = x2 = x0
            y1 = y2 = y0
            while stack:
                cy, cx = stack.pop()
                if cy < 0 or cy >= h or cx < 0 or cx >= w or seen[cy, cx] or not m[cy, cx]:
                    continue
                seen[cy, cx] = True
                area += 1
                x1, x2 = min(x1, cx), max(x2, cx)
                y1, y2 = min(y1, cy), max(y2, cy)
                stack.extend(((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1)))
            if area > best_area:
                best_area = area
                best = (x1, y1, x2 - x1 + 1, y2 - y1 + 1)
    return best
