# -*- coding: utf-8 -*-
"""地图识别 + 棋盘坐标投影（卫戍协议·规程）

算法与数据来自 bingyunhe/hongxue-stronghold-companion（Apache-2.0）：
- 每张地图在「商店收起 / 展开」两种镜头下各有一套 90 点 RGB 指纹
  （行 0–4 × 列 -1–7 × 每格 2 个取样点，取样点避开格心和左上角，半径 0.1 格）
- 画面上用同样的 4 角点单应矩阵取样，逐点算颜色距离，最接近的地图即当前地图

对外接口：
    rec = Recognizer()                 # 读 data/board/board_refs.json
    m = rec.match(img)                 # {'id','name','camera','score','margin'} 或 None
    rec.project(cam, col, row)         # 格子坐标 -> 归一化客户区坐标
    rec.cell_corners(cam, col, row)    # 四角（用于画站位框）
"""
import io, json, os, time

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA = os.path.join(HERE, 'data', 'board')

FIRST_COL, LAST_COL = -1, 7
FIRST_ROW, LAST_ROW = 0, 4
SAMPLE_POINTS = ((0.32, 0.72), (0.72, 0.32))
PATCH_RADIUS = 0.1
DIST_CAP = 45.0          # 单点距离上限，几个被干员挡住的格子不至于拉爆
KEPT_SHARE = 0.7         # 只用最近的 70% 取样点判定「是不是棋盘」
MAX_SCORE = 11.0         # 判定为棋盘：trimmed <= 11
MIN_MARGIN = 5.0         # 且与第二名至少差 5

# 地图 id -> 中文名（m0x 是我们自己的编号；上游 id 来自 garrison_maps.json）
NAMES = {
    'desert_crates': '沙漠（中央木箱）',
    'palace': '宫殿',
    'snow': '雪原（隐匿格）',
    'desert_camo': '沙漠（沼泽）',
    'desert_steel': '沙漠（铁板箱）',
    'palace_arrows': '宫殿（蓝箭头）',
    'desert_laser': '沙漠（红地板）',
    'city': '城区',
    'desert_cactus': '沙漠（双仙人掌）',
    'snow_ice': '雪原（冰面）',
}
# m0x -> 上游 id（board_refs.json 里数组完全一致，2026-11-14 已核对）
UPSTREAM = {
    'm01': 'desert_crates', 'm02': 'desert_cactus', 'm03': 'desert_steel',
    'm04': 'desert_laser', 'm05': 'city', 'm06': 'desert_camo',
    'm09': 'snow', 'm10': 'palace', 'm11': 'snow_ice', 'm12': 'palace_arrows',
}


def homography(points):
    """4 组 ((col,row),(x,y)) -> f(col,row)=(x,y)，与 C# BoardProjection 同解。"""
    a, b = [], []
    for (c, r), (x, y) in points:
        a.append([c, r, 1, 0, 0, 0, -x * c, -x * r]); b.append(x)
        a.append([0, 0, 0, c, r, 1, -y * c, -y * r]); b.append(y)
    n = 8
    m = [row[:] + [v] for row, v in zip(a, b)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(m[k][i]))
        m[i], m[p] = m[p], m[i]
        for k in range(n):
            if k != i:
                f = m[k][i] / m[i][i]
                m[k] = [vk - f * vi for vk, vi in zip(m[k], m[i])]
    h = [m[i][n] / m[i][i] for i in range(n)] + [1.0]
    return h


def _apply(h, u, v):
    w = h[6] * u + h[7] * v + h[8]
    return ((h[0] * u + h[1] * v + h[2]) / w, (h[3] * u + h[4] * v + h[5]) / w)


def _invert(m):
    a, b, c, d, e, f, g, h, i = m
    A = e * i - f * h; B = -(d * i - f * g); C = d * h - e * g
    det = a * A + b * B + c * C
    return [A / det, -(b * i - c * h) / det, (b * f - c * e) / det,
            B / det, (a * i - c * g) / det, -(a * f - c * d) / det,
            C / det, -(a * h - b * g) / det, (a * e - b * d) / det]


class Projection(object):
    """grid(col,row) <-> 归一化客户区坐标（0..1）。格 (c,r) 覆盖 c..c+1, r..r+1。"""

    def __init__(self, corners):
        self.h = homography(corners)
        self.inv = _invert(self.h)

    def project(self, col, row):
        return _apply(self.h, col, row)

    def unproject(self, x, y):
        return _apply(self.inv, x, y)

    def cell_at(self, x, y):
        c, r = self.unproject(x, y)
        return int(np.floor(c)), int(np.floor(r))

    def cell_corners(self, col, row):
        return [self.project(col, row), self.project(col + 1, row),
                self.project(col + 1, row + 1), self.project(col, row + 1)]


class Recognizer(object):
    def __init__(self, data_dir=None, load_names=True):
        d = data_dir or DEFAULT_DATA
        with io.open(os.path.join(d, 'board_refs.json'), encoding='utf-8') as f:
            refs = json.load(f)
        self.cams = {}
        for k, v in refs['cameras'].items():
            self.cams[k] = Projection([((c, r), (x, y)) for (c, r), (x, y) in v])
        self.refs = refs['maps']                      # m0x -> {camera: [90 x [r,g,b]]}
        self.ids = sorted(self.refs)
        self.names = {}
        for mid in self.ids:
            up = UPSTREAM.get(mid)
            self.names[mid] = NAMES.get(up, up or mid)
        self._np = {mid: {cam: np.asarray(arr, dtype=np.float32) for cam, arr in v.items()}
                    for mid, v in self.refs.items()}
        self.last_cost = 0.0

    # ---------- 取样 ----------
    def sample(self, arr, cam):
        """arr: HxWx3 float32 归一化图像 → 90x3 取样色"""
        h, w = arr.shape[:2]
        proj = self.cams[cam]
        out = np.empty((0, 3), dtype=np.float32)
        vals = []
        for r in range(FIRST_ROW, LAST_ROW + 1):
            for c in range(FIRST_COL, LAST_COL + 1):
                for sx, sy in SAMPLE_POINTS:
                    x, y = proj.project(c + sx, r + sy)
                    x2, _ = proj.project(c + sx + PATCH_RADIUS, r + sy)
                    rad = max(2, int(abs(x2 - x) * w))
                    cx, cy = int(x * w), int(y * h)
                    y0, y1 = max(0, cy - rad), min(h, cy + rad + 1)
                    x0, x1 = max(0, cx - rad), min(w, cx + rad + 1)
                    if y1 <= y0 or x1 <= x0:
                        vals.append((0.0, 0.0, 0.0))
                    else:
                        vals.append(tuple(arr[y0:y1, x0:x1].reshape(-1, 3).mean(axis=0)))
        return np.asarray(vals, dtype=np.float32)

    # ---------- 比对 ----------
    def _distance(self, sample, ref):
        d = np.sqrt(((sample - ref) ** 2).sum(axis=1))
        d = np.minimum(d, DIST_CAP)
        n = len(d)
        keep = max(1, int(n * KEPT_SHARE))
        trimmed = float(np.sort(d)[:keep].mean())
        return float(d.mean()), trimmed

    def match(self, img=None, arr=None, per_cam=None):
        """返回 {'id','code','name','camera','score','margin','full'} 或 None"""
        t0 = time.time()
        if arr is None:
            arr = np.asarray(img.convert('RGB'), dtype=np.float32)
        samples = {}
        for cam in self.cams:
            samples[cam] = self.sample(arr, cam)
        scored = []
        for mid in self.ids:
            refs = self._np[mid]
            for cam, s in samples.items():
                ref = refs.get(cam)
                if ref is None:                       # 缺这个镜头就用另一个
                    ref = next(iter(refs.values()))
                full, trimmed = self._distance(s, ref)
                scored.append((full, trimmed, mid, cam))
        scored.sort(key=lambda x: x[0])
        best = scored[0]
        others = [s for s in scored if s[2] != best[2]]
        margin = (others[0][0] - best[0]) if others else 999.0
        self.last_cost = time.time() - t0
        if best[1] > MAX_SCORE or margin < MIN_MARGIN:
            return None
        return {'id': best[2], 'code': UPSTREAM.get(best[2], best[2]),
                'name': self.names[best[2]], 'camera': best[3],
                'score': round(best[1], 2), 'margin': round(margin, 2),
                'full': round(best[0], 2)}

    # ---------- 投影辅助 ----------
    def project(self, cam, col, row):
        return self.cams[cam].project(col, row)

    def cell_corners(self, cam, col, row):
        return self.cams[cam].cell_corners(col, row)

    def cell_at(self, cam, x, y):
        return self.cams[cam].cell_at(x, y)


class Stabilizer(object):
    """连续两帧一致才切换地图；连续 4 帧认不出才清空。"""

    def __init__(self, misses=4):
        self.misses = misses
        self.current = None
        self._pending = None
        self._miss = 0

    def observe(self, m):
        if not m:
            self._pending = None
            if self.current is None:
                return False
            self._miss += 1
            if self._miss < self.misses:
                return False
            self.current = None
            return True
        self._miss = 0
        key = (m['id'], m['camera'])
        if self.current and (self.current['id'], self.current['camera']) == key:
            self._pending = None
            return False
        if self._pending and (self._pending['id'], self._pending['camera']) == key:
            self.current = m
            self._pending = None
            return True
        self._pending = m
        return False

    def reset(self):
        self.current = None
        self._pending = None
        self._miss = 0


if __name__ == '__main__':
    import sys
    r = Recognizer()
    for p in sys.argv[1:]:
        img = Image.open(p)
        m = r.match(img)
        print(os.path.basename(p), img.size, '->', m, '(%d ms)' % (r.last_cost * 1000))
