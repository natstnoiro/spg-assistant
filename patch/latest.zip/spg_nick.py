# -*- coding: utf-8 -*-
"""昵称解析：把攻略里的黑话映射到官方干员名，并清洗 playbooks。"""
import io, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, 'data')

with io.open(os.path.join(D, 'nicknames.json'), encoding='utf-8') as f:
    NICK = json.load(f)
with io.open(os.path.join(D, 'ops_full.json'), encoding='utf-8') as f:
    OPS = {o['name'] for o in json.load(f)}


def resolve(name):
    n = (name or '').strip()
    if n in OPS:
        return n, True
    if n in NICK:
        t = NICK[n]
        return t, t in OPS
    # 去掉括号备注再试一次
    import re
    base = re.sub(r'[（(].*?[)）]', '', n).strip()
    if base and base in OPS:
        return base, True
    if base and base in NICK:
        t = NICK[base]
        return t, t in OPS
    return n, False


def resolve_list(names):
    out, miss = [], []
    for n in names or []:
        t, ok = resolve(n)
        if ok:
            if t not in out:
                out.append(t)
        else:
            miss.append(n)
    return out, miss


if __name__ == '__main__':
    p = os.path.join(D, 'playbooks.json')
    with io.open(p, encoding='utf-8') as f:
        pb = json.load(f)
    for cov, d in pb.items():
        for k in ('core', 'priority'):
            r, m = resolve_list(d.get(k))
            d[k] = r
            if m:
                d.setdefault('unresolved', []).extend(m)
        eng = d.get('engines') or {}
        for ek in list(eng):
            r, m = resolve_list(eng[ek])
            eng[ek] = r
            if m:
                d.setdefault('unresolved', []).extend(m)
        d.setdefault('unresolved', [])
        d['unresolved'] = sorted(set(d['unresolved']))
    with io.open(p, 'w', encoding='utf-8') as f:
        json.dump(pb, f, ensure_ascii=False, indent=1)
    for cov, d in pb.items():
        print(cov, '| 核心', d['core'], '| 未解析', d['unresolved'])
