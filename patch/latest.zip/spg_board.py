# -*- coding: utf-8 -*-
"""把开源棋盘数据整理成前端能用的 maps.json（含敌人路线与前后排评分）"""
import io, json, os

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'board')
BOARD = json.load(io.open(os.path.join(D, 'board_refs.json'), encoding='utf-8'))
ROUTES = json.load(io.open(os.path.join(D, 'routes.json'), encoding='utf-8'))


def walk_cells(seg, grid_w, grid_h):
    """把折线段的格点展开成格子集合"""
    out = set()
    for a, b in zip(seg, seg[1:]):
        c1, r1 = int(a['col']), int(a['row'])
        c2, r2 = int(b['col']), int(b['row'])
        steps = max(abs(c2 - c1), abs(r2 - r1))
        if steps == 0:
            if 0 <= c1 < grid_w and 0 <= r1 < grid_h:
                out.add((r1, c1))
            continue
        for i in range(steps + 1):
            c = c1 + round((c2 - c1) * i / steps)
            r = r1 + round((r2 - r1) * i / steps)
            if 0 <= c < grid_w and 0 <= r < grid_h:
                out.add((r, c))
    return out


def build():
    maps = {}
    for mid, m in ROUTES['maps'].items():
        walk = m.get('walkable') or []
        if not walk:
            continue
        h, w = len(walk), len(walk[0])
        route = set()
        for lv in (m.get('levels') or {}).values():
            for rt in (lv.get('routes') or []):
                for seg in (rt.get('segments') or []):
                    if len(seg) >= 2:
                        route |= walk_cells(seg, w, h)
        # 每个可站格到路线的距离
        dist = {}
        for r in range(h):
            for c in range(w):
                if not walk[r][c]:
                    continue
                if not route:
                    dist[f'{r},{c}'] = 9
                    continue
                dist[f'{r},{c}'] = min(abs(r - rr) + abs(c - cc) for rr, cc in route)
        maps[mid] = {
            'w': w, 'h': h,
            'walk': [[1 if v else 0 for v in row] for row in walk],
            'route': sorted([list(x) for x in route]),
            'dist': dist,
            'cameras': BOARD['cameras'],
        }
    return maps


if __name__ == '__main__':
    m = build()
    out = os.path.join(D, 'maps.json')
    with io.open(out, 'w', encoding='utf-8') as f:
        json.dump(m, f, ensure_ascii=False, separators=(',', ':'))
    print('maps', len(m), 'size', os.path.getsize(out))
    for mid, v in m.items():
        print(mid, f"{v['w']}x{v['h']}", 'route cells', len(v['route']),
              'walkable', sum(sum(r) for r in v['walk']))

def _load():
    import json, os
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, 'data', 'board', 'maps.json')
    with io.open(p, encoding='utf-8') as f:
        return json.load(f)


# m0x -> 上游 id；上游棋盘列号 -2..9、行 0..4，与相机投影同一坐标系
UPSTREAM = {
    'm01': 'desert_crates', 'm02': 'desert_cactus', 'm03': 'desert_steel',
    'm04': 'desert_laser', 'm05': 'city', 'm06': 'desert_camo',
    'm09': 'snow', 'm10': 'palace', 'm11': 'snow_ice', 'm12': 'palace_arrows',
}
CELL_OK = {'G': ('front', 'back'), 'T': ('front', 'back'), 'H': ('back',)}


def _load_upstream():
    import json, os
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, 'data', 'board', '_upstream_maps.json')
    if not os.path.exists(p):
        return None
    with io.open(p, encoding='utf-8') as f:
        return json.load(f)


def _load_side():
    import json, os
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, 'data', 'op_side.json')
    if not os.path.exists(p):
        return {}
    with io.open(p, encoding='utf-8') as f:
        return json.load(f)


def plan(ops, map_id='m01'):
    """站位：用上游棋盘数据（真实格子类型 + 敌人路线），近战贴路线、远程拉远/上高台。

    返回 ([(name, row, col, dir)], map_id)，row/col 是上游坐标（列 -2..9）
    """
    up = _load_upstream()
    code = UPSTREAM.get(map_id, map_id)
    if not up:
        return [], map_id
    entry = next((m for m in up['maps'] if m['id'] == code), None)
    if entry is None:
        entry = up['maps'][0]
        code = entry['id']
    cells = entry.get('cells') or []
    first_col = up.get('columns', [-2, 9])[0]
    route = set()
    for rt in entry.get('routes') or []:
        for c, r in rt.get('cells') or []:
            route.add((r, int(c)))
    side = _load_side()

    def cell_at(r, c):
        i = c - first_col
        if 0 <= r < len(cells) and 0 <= i < len(cells[r]):
            return cells[r][i]
        return 'X'

    def nearest_route(r, c):
        best, bd = None, 999
        for rr, cc in route:
            dd = abs(rr - r) + abs(cc - c)
            if dd < bd:
                bd, best = dd, (rr, cc)
        return best, bd

    tiles = []
    for r in range(len(cells)):
        for i, t in enumerate(cells[r]):
            c = first_col + i
            if t in CELL_OK:
                best, bd = nearest_route(r, c)
                tiles.append((bd, r, c, t))
    # 近战（front）：优先踩在/贴着路线的地面格
    front_pool = sorted([t for t in tiles if t[3] in ('G', 'T')],
                        key=lambda t: (t[3] != 'G', t[0], t[1], t[2]))
    # 远程（back）：先抢离路线最近的高台，高台用完了再退到远离路线的地面
    high = sorted([t for t in tiles if t[3] == 'H'], key=lambda t: (t[0], t[1], t[2]))
    far = sorted([t for t in tiles if t[3] in ('G', 'T')], key=lambda t: (-t[0], t[1], t[2]))
    back_pool = high + far
    out, used = [], set()
    for want in ('front', 'back'):
        pool = front_pool if want == 'front' else back_pool
        for n in ops:
            if side.get(n, 'back') != want:
                continue
            for d, r, c, t in pool:
                if (r, c) in used:
                    continue
                used.add((r, c))
                best, _bd = nearest_route(r, c)
                dirs = ''
                if best and _bd > 0:
                    dr, dc = best[0] - r, best[1] - c
                    dirs = ('↓' if dr > 0 else '↑') if abs(dr) >= abs(dc) else ('→' if dc > 0 else '←')
                out.append((n, r, c, dirs))
                break
    return out, map_id

