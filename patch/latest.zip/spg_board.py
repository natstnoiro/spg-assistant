# -*- coding: utf-8 -*-
"""把开源棋盘数据整理成前端能用的 maps.json（含敌人路线与前后排评分）"""
import io, json, os

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'board')
BOARD = json.load(io.open(os.path.join(D, 'board_refs.json'), encoding='utf-8'))
ROUTES = json.load(io.open(os.path.join(D, 'routes.json'), encoding='utf-8'))


def walk_cells(seg, grid_w, grid_h):
    """把折线段的格点展开成格子集合"""
    out = set()
    for a, b in zip(seg, seg[1:]):
        c1, r1 = int(a['col']), int(a['row'])
        c2, r2 = int(b['col']), int(b['row'])
        steps = max(abs(c2 - c1), abs(r2 - r1))
        if steps == 0:
            if 0 <= c1 < grid_w and 0 <= r1 < grid_h:
                out.add((r1, c1))
            continue
        for i in range(steps + 1):
            c = c1 + round((c2 - c1) * i / steps)
            r = r1 + round((r2 - r1) * i / steps)
            if 0 <= c < grid_w and 0 <= r < grid_h:
                out.add((r, c))
    return out


def build():
    maps = {}
    for mid, m in ROUTES['maps'].items():
        walk = m.get('walkable') or []
        if not walk:
            continue
        h, w = len(walk), len(walk[0])
        route = set()
        for lv in (m.get('levels') or {}).values():
            for rt in (lv.get('routes') or []):
                for seg in (rt.get('segments') or []):
                    if len(seg) >= 2:
                        route |= walk_cells(seg, w, h)
        # 每个可站格到路线的距离
        dist = {}
        for r in range(h):
            for c in range(w):
                if not walk[r][c]:
                    continue
                if not route:
                    dist[f'{r},{c}'] = 9
                    continue
                dist[f'{r},{c}'] = min(abs(r - rr) + abs(c - cc) for rr, cc in route)
        maps[mid] = {
            'w': w, 'h': h,
            'walk': [[1 if v else 0 for v in row] for row in walk],
            'route': sorted([list(x) for x in route]),
            'dist': dist,
            'cameras': BOARD['cameras'],
        }
    return maps


if __name__ == '__main__':
    m = build()
    out = os.path.join(D, 'maps.json')
    with io.open(out, 'w', encoding='utf-8') as f:
        json.dump(m, f, ensure_ascii=False, separators=(',', ':'))
    print('maps', len(m), 'size', os.path.getsize(out))
    for mid, v in m.items():
        print(mid, f"{v['w']}x{v['h']}", 'route cells', len(v['route']),
              'walkable', sum(sum(r) for r in v['walk']))

def _load():
    import json, os
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, 'data', 'board', 'maps.json')
    with io.open(p, encoding='utf-8') as f:
        return json.load(f)


# m0x -> 上游 id；上游棋盘列号 -2..9、行 0..4，与相机投影同一坐标系
UPSTREAM = {
    'm01': 'desert_crates', 'm02': 'desert_cactus', 'm03': 'desert_steel',
    'm04': 'desert_laser', 'm05': 'city', 'm06': 'desert_camo',
    'm09': 'snow', 'm10': 'palace', 'm11': 'snow_ice', 'm12': 'palace_arrows',
}
CELL_OK = {'G': ('front', 'back'), 'T': ('front', 'back'), 'H': ('back',)}


def _load_upstream():
    import json, os
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, 'data', 'board', '_upstream_maps.json')
    if not os.path.exists(p):
        return None
    with io.open(p, encoding='utf-8') as f:
        return json.load(f)


def _load_side():
    import json, os
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, 'data', 'op_side.json')
    if not os.path.exists(p):
        return {}
    with io.open(p, encoding='utf-8') as f:
        return json.load(f)


def plan(ops, map_id='m01'):
    """站位：用上游棋盘数据（真实格子类型 + 敌人路线），近战贴路线、远程拉远/上高台。

    返回 ([(name, row, col, dir)], map_id)，row/col 是上游坐标（列 -2..9）
    """
    up = _load_upstream()
    code = UPSTREAM.get(map_id, map_id)
    if not up:
        return [], map_id
    entry = next((m for m in up['maps'] if m['id'] == code), None)
    if entry is None:
        entry = up['maps'][0]
        code = entry['id']
    cells = entry.get('cells') or []
    first_col = up.get('columns', [-2, 9])[0]
    route = set()
    for rt in entry.get('routes') or []:
        for c, r in rt.get('cells') or []:
            route.add((r, int(c)))
    side = _load_side()

    def cell_at(r, c):
        i = c - first_col
        if 0 <= r < len(cells) and 0 <= i < len(cells[r]):
            return cells[r][i]
        return 'X'

    def nearest_route(r, c):
        best, bd = None, 999
        for rr, cc in route:
            dd = abs(rr - r) + abs(cc - c)
            if dd < bd:
                bd, best = dd, (rr, cc)
        return best, bd

    tiles = []
    for r in range(len(cells)):
        for i, t in enumerate(cells[r]):
            c = first_col + i
            if t in CELL_OK:
                best, bd = nearest_route(r, c)
                tiles.append((bd, r, c, t))
    # ---- 按路线的「行」分道：每条道先放 1 个阻挡，再补第二个 ----
    lane_rows = sorted({r for r, _ in route})
    lanes = []
    for r in lane_rows:
        if lanes and r - lanes[-1][-1] <= 1:
            lanes[-1].append(r)
        else:
            lanes.append([r])
    lane_of_row = {}
    for li, rows in enumerate(lanes):
        for r in rows:
            lane_of_row[r] = li
    lane_route = {li: {(r, c) for (r, c) in route if lane_of_row.get(r) == li}
                  for li in range(len(lanes))}

    def lane_dist(r, c, li):
        rt = lane_route.get(li) or route
        return min((abs(r - rr) + abs(c - cc) for rr, cc in rt), default=99)

    # 每条道的地面池
    lane_front = {}
    for li in range(len(lanes)):
        pool = [t for t in tiles if t[3] in ('G', 'T')]
        lane_front[li] = sorted(pool, key=lambda t: (lane_dist(t[1], t[2], li), t[3] != 'G', t[1], t[2]))

    # 近战（front）：轮转各道，优先没放过的道
    front_pool = sorted([t for t in tiles if t[3] in ('G', 'T')],
                        key=lambda t: (t[3] != 'G', t[0], t[1], t[2]))
    # 远程（back）：先抢「自己那条道」上离路线最近的高台，用完再退到同道的远处地面
    high = sorted([t for t in tiles if t[3] == 'H'], key=lambda t: (t[0], t[1], t[2]))
    far = sorted([t for t in tiles if t[3] in ('G', 'T')], key=lambda t: (-t[0], t[1], t[2]))
    back_pool = high + far
    out, used = [], set()
    lane_count = {li: 0 for li in range(len(lanes))}
    lane_front_cell = {}
    # 近战：按道轮转，保证每条道都有阻挡
    for n in [x for x in ops if side.get(x, 'back') == 'front']:
        # 选「放得最少」的道
        order = sorted(lane_count, key=lambda li: lane_count[li])
        placed = False
        for li in order:
            for d, r, c, t in lane_front.get(li, []):
                if (r, c) in used:
                    continue
                used.add((r, c))
                lane_count[li] += 1
                lane_front_cell[li] = (r, c)
                best, _bd = nearest_route(r, c)
                dirs = ''
                if best and _bd > 0:
                    dr, dc = best[0] - r, best[1] - c
                    dirs = ('↓' if dr > 0 else '↑') if abs(dr) >= abs(dc) else ('→' if dc > 0 else '←')
                out.append((n, r, c, dirs))
                placed = True
                break
            if placed:
                break
        if not placed:      # 所有道都满了，退回通用池
            for d, r, c, t in front_pool:
                if (r, c) in used:
                    continue
                used.add((r, c))
                out.append((n, r, c, ''))
                break

    # 远程：优先贴在自己那道「阻挡位」附近的高台，再退同道的远处地面
    def near_front(li, cell):
        fr = lane_front_cell.get(li)
        if not fr:
            return 99
        return abs(cell[0] - fr[0]) + abs(cell[1] - fr[1])

    for n in [x for x in ops if side.get(x, 'back') != 'front']:
        best_tile, best_key = None, None
        for li in range(len(lanes)):
            for d, r, c, t in (high + far):
                if (r, c) in used:
                    continue
                key = (t != 'H', near_front(li, (r, c)), lane_dist(r, c, li))
                if best_key is None or key < best_key:
                    best_key, best_tile = key, (r, c, t)
                break
        if best_tile is None:
            for d, r, c, t in back_pool:
                if (r, c) not in used:
                    best_tile = (r, c, t)
                    break
        if best_tile is None:
            continue
        r, c, t = best_tile
        used.add((r, c))
        best, _bd = nearest_route(r, c)
        dirs = ''
        if best and _bd > 0:
            dr, dc = best[0] - r, best[1] - c
            dirs = ('↓' if dr > 0 else '↑') if abs(dr) >= abs(dc) else ('→' if dc > 0 else '←')
        out.append((n, r, c, dirs))
    return out, map_id

