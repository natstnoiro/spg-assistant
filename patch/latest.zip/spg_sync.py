# -*- coding: utf-8 -*-
"""把 sganggs/Stronghold-Protocol 的数据同步成本项目用的紧凑数据

来源目录：_download/Stronghold-Protocol-master/data
输出：
  data/economy.json      经济/价格/升级/收入/商店格位
  data/bands.json        40 个策略（band）
  data/item_combo.json   装备组合（"若与X一起装备"）
  data/equip_full.json   装备完整信息（名字/阶/价/说明/给盟约）
并打印与现有数据的差异（干员/盟约/装备）。
"""
import io
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
_BASE = os.path.join(ROOT, '_download', 'Stronghold-Protocol-master', 'data')
# 优先用最新赛季（规程 = act3）的数据目录
SRC = os.path.join(_BASE, 'versions', 'act3autochess-v3_1')
if not os.path.isdir(SRC):
    SRC = _BASE
OUT = os.path.join(HERE, 'data')


def load(name, default=None):
    try:
        with io.open(os.path.join(SRC, name), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def dump(name, obj):
    p = os.path.join(OUT, name)
    with io.open(p, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    print('  ->', name, len(json.dumps(obj, ensure_ascii=False)) // 1024, 'KB')


def norm_desc(s):
    return re.sub(r'<[^>]+>', '', s or '')


def main():
    cfg = load('config.json', {}) or {}
    items = load('items.json', {}) or {}
    bonds = load('bonds.json', {}) or {}
    bands = load('bands.json', {}) or {}
    chess = load('chess.json', {}) or {}

    # ---- 经济 ----
    eco = {}
    modes = cfg.get('modes', {}) or {}
    for mid, m in modes.items():
        if not str(mid).startswith('mode_single_'):
            continue
        diff = m.get('difficulty')
        eco.setdefault('upgradePricesByDifficulty', {})[diff] = m.get('upgradePrices')
        eco.setdefault('shopSlotsByDifficulty', {})[diff] = m.get('shopSlots')
        eco.setdefault('lastRoundByDifficulty', {})[diff] = m.get('lastRound')
        eco.setdefault('hiddenRoundByDifficulty', {})[diff] = m.get('hiddenRound')
        eco.setdefault('stagesByDifficulty', {})[diff] = m.get('stages')
    e = cfg.get('economy', {}) or {}
    eco.update({
        'refreshPrice': e.get('refreshPrice', 1),
        'income': e.get('income') or [],
        'incomeFormula': e.get('incomeFormula'),
        'incomeCap': e.get('incomeCap', 12),
        'leftoverFundsLost': e.get('leftoverFundsLost', True),
        'chessPrice': e.get('chessPrice') or {},
        'chessSell': e.get('chessSell') or {},
        'benchSize': e.get('benchSize', 10),
        'deployCap': e.get('deployCap', 8),
        'storeCntMax': e.get('storeCntMax', 6),
        'equipPerChess': e.get('equipPerChess', 2),
        'mergeCount': e.get('mergeCount', 3),
        'itemMergeCount': e.get('itemMergeCount', 2),
        'maxArtsPerRound': e.get('maxArtsPerRound', 2),
        'defaultStartLp': e.get('defaultStartLp', 28),
    })
    print('[economy]')
    dump('economy.json', eco)

    # ---- 装备 ----
    equip = {}
    combos = {}
    for v in items.values():
        if v.get('isGolden'):
            continue
        name = v.get('name')
        if not name:
            continue
        d = norm_desc(v.get('descRaw') or v.get('desc'))
        if name in equip and equip[name].get('desc') == d:
            continue
        equip.setdefault(name, {
            'name': name, 'tier': v.get('tier'), 'price': v.get('price'),
            'desc': d, 'giveBond': v.get('giveBondId') or '',
        })
        m = re.search(r'若与[“"]([^”"]+)[”"](?:一起装备|同时持有则组合为[“"]([^”"]+)[”"])', d)
        if m:
            combos.setdefault(name, {'partner': m.group(1),
                                     'result': (m.group(2) if m.lastindex and m.lastindex >= 2 else ''),
                                     'desc': d})
    print('[equip]', len(equip), '件, 组合', len(combos), '条')
    dump('equip_full.json', equip)
    dump('item_combo.json', combos)

    # ---- 策略（band）----
    bd = {k: {'name': v.get('name'), 'desc': norm_desc(v.get('desc')),
              'totalHp': v.get('totalHp'), 'effectName': v.get('effectName')}
          for k, v in bands.items()}
    print('[bands]', len(bd), '个策略')
    dump('bands.json', bd)

    # ---- 盟约 ----
    cov = {k: {'name': v.get('name'), 'core': bool(v.get('isCore')),
               'thresholds': v.get('thresholds'), 'activeCount': v.get('activeCount'),
               'countsHand': v.get('countsHand'), 'countMode': v.get('countMode')}
           for k, v in bonds.items()}
    print('[bonds]', len(cov), '个盟约')
    dump('bonds.json', cov)

    # ---- 差异 ----
    ours_ops = {o['name'] for o in load_local('ops_full.json') or []}
    ours_cov = {o['name'] for o in load_local('covenants.json') or []}
    ours_eq = {o['name'] for o in load_local('equipment.json') or []}
    chess_names = set()
    for v in chess.values():
        if v.get('isGolden'):
            continue
        n = v.get('name')
        if n:
            chess_names.add(n)
    print('\n[diff]')
    print('  干员: 上游', len(chess_names), '本地', len(ours_ops),
          '| 上游有本地没有:', sorted(chess_names - ours_ops)[:15])
    print('  本地多出(可能是别名/旧版):', sorted(ours_ops - chess_names)[:15])
    print('  盟约: 上游', len(cov), '本地', len(ours_cov),
          '| 差:', sorted(set(cov.values().__iter__().__class__ and []) or []))
    print('  盟约名差:', sorted({v['name'] for v in cov.values()} ^ ours_cov))
    print('  装备: 上游', len(equip), '本地', len(ours_eq),
          '| 上游有本地没有:', sorted(set(equip) - ours_eq)[:15],
          '| 本地多:', sorted(ours_eq - set(equip))[:10])


def load_local(name):
    try:
        with io.open(os.path.join(OUT, name), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


if __name__ == '__main__':
    main()
