# -*- coding: utf-8 -*-
"""读调度中心等级：左下角 LEVEL 罗马数字"""
import re

ROMAN = {'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5, 'VI': 6}
MIN_COST = {1: 4, 2: 6, 3: 9, 4: 12, 5: 16}   # 升级到下一级的大致花费


def read_level(im, eng):
    W, H = im.size
    box = (int(W * 0.09), int(H * 0.78), int(W * 0.30), int(H * 1.0))
    roi = im.crop(box)
    its = eng.run(roi, scale=3, pre='auto')
    txt = ' '.join((x['text'] or '') for x in its).upper()
    if 'LEVEL' not in txt and not re.search(r'\b(I{1,3}|IV|V|VI)\b', txt):
        return None
    # 优先找独立的罗马数字
    for tok in re.findall(r'\b(I{1,3}|IV|VI|V)\b', txt):
        if tok in ROMAN:
            return ROMAN[tok]
    return None


def upgrade_hint(level, gold):
    if not level:
        return ''
    if level >= 6:
        return 'Lv.6 已满'
    need = MIN_COST.get(level)
    if need is None:
        return f'Lv.{level}'
    return f"Lv.{level}→{level + 1}(需{need})" + ('  可升' if gold and gold >= need else '')
