# -*- coding: utf-8 -*-
"""盟约全览面板识别（点左上放大镜打开的那一屏）

布局固定 3 排（26 个盟约，**跟 data/covs_full.json 的顺序不一样**）：
  核心盟约 10 个 → 亮的（亮绿圆环）= 本局可用，灰白的 = 被 ban
  附加盟约 10 个 → 同上
  附加盟约 6 个  → 同上

做法（v25.12 重写，修「卡西米尔被误判成 ban」「伊比利亚整只漏读」）：
1. OCR 只负责读名字，**读漏/读错一个不影响整排**
2. 用读到的名字反推每排的格位：x = a + b * 排内序号（最小二乘 + 去离群点），
   按 LAYOUT 补全漏读的格子
3. 每排沿 y 扫出「绿度最高的一条带」= 图标中心，再在格位中心量一个圆里的绿度
   （旧版量的是「名字上方 25~80px 的方块」，对符号大的图标——比如卡西米尔那把大 X——
    会量到黑色符号，绿度掉到阈值以下，于是误报成 ban）
"""
import sys

import numpy as np

import spg_ocr

SCAN_BOX = (0.00, 0.13, 0.72, 0.93)   # 左半边面板
ROW_TOL = 36                          # 同一行 y 容差（像素）
GREEN_ON = 35.0                       # 绿度阈值（亮 ≈ 90+，灰 ≈ 5）

# 面板从左到右的固定顺序（游戏 UI 固定的，别按 data 顺序改）
LAYOUT = (
    ('炎', '阿戈尔', '叙拉古', '卡西米尔', '伊比利亚', '萨尔贡',
     '维多利亚', '谢拉格', '乌萨斯', '莱塔尼亚'),
    ('精准', '坚守', '奇迹', '投资人', '不屈', '调和',
     '协防干员', '独行', '绝技', '聚合'),
    ('奥术', '迅捷', '灵巧', '助力', '远见', '突袭'),
)


def _cluster_rows(items):
    """按 y 聚成排，每排按 x 从左到右；少于 3 个的排丢掉（标题/杂字）"""
    items = sorted(items, key=lambda d: d['y'])
    rows = []
    for d in items:
        if rows and abs(rows[-1][-1]['y'] - d['y']) <= ROW_TOL:
            rows[-1].append(d)
        else:
            rows.append([d])
    return [sorted(r, key=lambda d: d['x']) for r in rows if len(r) >= 3]


def _spacing(row):
    xs = sorted(d['x'] for d in row)
    gaps = [b - a for a, b in zip(xs, xs[1:]) if b - a > 0]
    return float(np.median(gaps)) if gaps else 100.0


def _fit_slots(row, seq):
    """用读到的名字拟合格位 x = a + b*序号；返回 (a, b) 或 None"""
    pts, seen = [], set()
    for d in row:
        if d['name'] in seq and d['name'] not in seen:
            seen.add(d['name'])
            pts.append((float(seq.index(d['name'])), float(d['x'])))
    a = b = None
    for _ in range(3):
        if len(pts) < 2:
            return None
        n = float(len(pts))
        sx = sum(p[0] for p in pts)
        sy = sum(p[1] for p in pts)
        sxx = sum(p[0] * p[0] for p in pts)
        sxy = sum(p[0] * p[1] for p in pts)
        den = n * sxx - sx * sx
        if not den:
            return None
        b = (n * sxy - sx * sy) / den
        a = (sy - b * sx) / n
        if b < 8:
            return None
        keep = [(i, x) for i, x in pts if abs(x - (a + b * i)) <= 0.35 * abs(b)]
        if len(keep) == len(pts) or len(keep) < 2:
            return a, b
        pts = keep
    return a, b


def _row_band(grn, row, xs, b):
    """名字上方扫一条「绿度最高」的带 = 图标中心 y；全灰就按比例估"""
    h, w = grn.shape
    y_name = float(np.median([d['y'] for d in row]))
    half = max(2, int(round(0.12 * b)))
    lo = max(0, int(round(y_name - 1.05 * b)))
    hi = min(h - 1, int(round(y_name - 0.15 * b)))
    best_y, best_v = None, -1e9
    for y in range(lo, hi):
        y0, y1 = max(0, y - half), min(h, y + half + 1)
        tot, n = 0.0, 0
        for x in xs:
            x0, x1 = max(0, x - half), min(w, x + half + 1)
            blk = grn[y0:y1, x0:x1]
            if blk.size:
                tot += float(blk.mean())
                n += 1
        if n and tot / n > best_v:
            best_v, best_y = tot / n, y
    if best_y is None or best_v < 6.0:
        return int(round(y_name - 0.62 * b))
    return best_y


def _glow(grn, cx, cy, b):
    """格位中心圆内平均绿度（半径 0.30b，够大能盖住整个符号，又不会串到隔壁格）"""
    h, w = grn.shape
    half = max(3, int(round(0.30 * b)))
    y0, y1 = max(0, cy - half), min(h, cy + half + 1)
    x0, x1 = max(0, cx - half), min(w, cx + half + 1)
    blk = grn[y0:y1, x0:x1]
    if not blk.size:
        return 0.0
    hh, ww = blk.shape
    yy, xx = np.ogrid[0:hh, 0:ww]
    m = (((yy - hh / 2.0) / max(1.0, hh / 2.0)) ** 2
         + ((xx - ww / 2.0) / max(1.0, ww / 2.0)) ** 2) <= 1.0
    return float(blk[m].mean())


def _pick_seq(row, ri):
    """这一排对应 LAYOUT 里的哪一行：先按顺序，对不上再按名字重合度找"""
    names = {d['name'] for d in row}
    pref = LAYOUT[ri] if ri < len(LAYOUT) else None
    if pref and len(names & set(pref)) >= max(2, int(round(len(names) * 0.5))):
        return pref
    best, best_n = None, 0
    for cand in LAYOUT:
        n = len(names & set(cand))
        if n > best_n:
            best, best_n = cand, n
    return best if best_n >= 2 else None


def read_full_panel(img, eng, detail=False):
    """返回 {'core_on','core_off','addons_on','addons_off','rows'}；不是该面板返回 None

    detail=True 时多返回 'detail'：每排 [(名字, 绿度, 是否可用), ...]，调试用
    """
    W, H = img.size
    box = (int(W * SCAN_BOX[0]), int(H * SCAN_BOX[1]), int(W * SCAN_BOX[2]), int(H * SCAN_BOX[3]))
    crop = img.crop(box)
    a = np.asarray(crop.convert('RGB')).astype(np.int16)
    # 绿度图：G - (R+B)/2；亮绿图标 ≈ 90+，灰图标 ≈ 5
    grn = a[:, :, 1].astype(np.float32) - (a[:, :, 0] + a[:, :, 2]) * 0.5
    h, w = grn.shape

    its = eng.run(crop, scale=2, pre='auto')
    items = []
    for it in its:
        nm = spg_ocr.match_cov((it['text'] or '').strip(), cutoff=0.6)
        if not nm:
            continue
        cx, cy = int(it['cx']), int(it['cy'])
        if 0 <= cx < w and 0 <= cy < h:
            items.append({'name': nm, 'x': cx, 'y': cy})
    if len(items) < 5:
        return None
    rows = _cluster_rows(items)
    if len(rows) < 2:
        return None

    res = {'core_on': [], 'core_off': [], 'addons_on': [], 'addons_off': [],
           'rows': len(rows)}
    if detail:
        res['detail'] = []
    for ri, row in enumerate(rows):
        seq = _pick_seq(row, ri)
        if seq is None:
            continue
        fit = _fit_slots(row, seq)
        if fit:
            a_, b_ = fit
            xs = [int(round(a_ + b_ * i)) for i in range(len(seq))]
            names = list(seq)
        else:
            xs = [int(round(d['x'])) for d in row]
            names = [d['name'] for d in row]
            b_ = _spacing(row)
        yb = _row_band(grn, row, xs, b_)
        on, off, det = [], [], []
        for nm, x in zip(names, xs):
            if not (0 <= x < w and 0 <= yb < h):
                continue
            g = _glow(grn, x, yb, b_)
            ok = g >= GREEN_ON
            (on if ok else off).append(nm)
            det.append((nm, round(g, 1), ok))
        if ri == 0:
            res['core_on'], res['core_off'] = on, off
        else:
            res['addons_on'] += on
            res['addons_off'] += off
        if detail:
            res['detail'].append(det)
    return res


def probe_panel(img):
    """快速判断：屏幕上是不是「盟约全览」那种 2~3 排亮绿圆环（不做 OCR，~10ms）"""
    try:
        W, H = img.size
        crop = img.crop((int(W * SCAN_BOX[0]), int(H * SCAN_BOX[1]),
                         int(W * SCAN_BOX[2]), int(H * SCAN_BOX[3])))
        a = np.asarray(crop.convert('RGB'))
        mask = _green_mask(a)
        ratio = mask.mean()
        if ratio < 0.03:
            return False
        rp = mask.sum(axis=1)
        thr = max(12, int(rp.max() * 0.45))
        runs = _runs(rp, thr, int(crop.height * 0.02))
        return len(runs) >= 2
    except Exception:
        return False


def _green_mask(a):
    r = a[:, :, 0].astype(np.int16)
    g = a[:, :, 1].astype(np.int16)
    b = a[:, :, 2].astype(np.int16)
    return (g > 105) & (g > r + 22) & (g > b + 22)


def _runs(profile, thr, min_len):
    out = []
    i, n = 0, len(profile)
    while i < n:
        if profile[i] >= thr:
            j = i
            while j < n and profile[j] >= thr:
                j += 1
            if j - i >= min_len:
                out.append((i, j - 1, (i + j - 1) // 2))
            i = j
        else:
            i += 1
    return out


if __name__ == '__main__':
    # 调试：python spg_open.py 全览截图.png
    from PIL import Image
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    eng = spg_ocr.Engine()
    r = read_full_panel(Image.open(sys.argv[1]).convert('RGB'), eng, detail=True)
    if not r:
        print('没认出全览面板')
        sys.exit(1)
    print('核心 可用:', '/'.join(r['core_on']))
    print('核心 ban :', '/'.join(r['core_off']))
    print('附加 可用:', '/'.join(r['addons_on']))
    print('附加 ban :', '/'.join(r['addons_off']))
    for i, det in enumerate(r.get('detail') or []):
        print('第%d排:' % (i + 1), ' '.join('%s=%.0f%s' % (n, g, '' if ok else '(灰)') for n, g, ok in det))
