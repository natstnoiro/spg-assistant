# -*- coding: utf-8 -*-
"""盟约全览面板识别（点左上放大镜打开的那一屏）

布局（3 行）：
  核心盟约 10 个   → 亮的 = 本局可选，灰的 = 被 ban（右上角带「禁」）
  附加盟约 10 个   → 亮的 = 可选
  附加盟约第二排 6 个 → 亮的 = 可选，灰的 = 被 ban

做法：OCR 图标下面的名字 → 按 y 聚类成行 → 取名字上方那块图标算「绿度」，
绿度高 = 亮色（可用），绿度低 = 灰（被 ban）。
"""
import numpy as np

import spg_ocr

SCAN_BOX = (0.00, 0.13, 0.72, 0.93)   # 左半边面板
ROW_TOL = 36                          # 同一行 y 容差（像素）
ICON_UP = (25, 80)                    # 图标区域：名字上方 25~80 像素
GREEN_ON = 35.0                       # 绿度阈值


def read_full_panel(img, eng):
    """返回 {'core_on','core_off','addons_on','addons_off','rows'}；不是该面板返回 None"""
    W, H = img.size
    box = (int(W * SCAN_BOX[0]), int(H * SCAN_BOX[1]), int(W * SCAN_BOX[2]), int(H * SCAN_BOX[3]))
    crop = img.crop(box)
    a = np.asarray(crop.convert('RGB')).astype(np.int16)
    its = eng.run(crop, scale=2, pre='auto')
    items = []
    for it in its:
        nm = spg_ocr.match_cov((it['text'] or '').strip(), cutoff=0.6)
        if not nm:
            continue
        cx, cy = int(it['cx']), int(it['cy'])
        up0, up1 = ICON_UP
        y0, y1 = max(0, cy - up1), max(0, cy - up0)
        patch = a[y0:y1, max(0, cx - 38):cx + 38]
        if patch.size == 0:
            continue
        grn = float(patch[:, :, 1].mean() - (patch[:, :, 0].mean() + patch[:, :, 2].mean()) / 2)
        items.append({'name': nm, 'x': cx, 'y': cy, 'green': round(grn, 1)})
    if len(items) < 8:
        return None
    # 按 y 聚类成行
    items.sort(key=lambda d: d['y'])
    rows = []
    for d in items:
        if rows and abs(rows[-1][-1]['y'] - d['y']) <= ROW_TOL:
            rows[-1].append(d)
        else:
            rows.append([d])
    rows = [sorted(r, key=lambda d: d['x']) for r in rows if len(r) >= 3]
    if len(rows) < 2:
        return None

    def on(d):
        return d['green'] >= GREEN_ON

    core_on = [d['name'] for d in rows[0] if on(d)]
    core_off = [d['name'] for d in rows[0] if not on(d)]
    add_on, add_off = [], []
    for r in rows[1:]:
        for d in r:
            (add_on if on(d) else add_off).append(d['name'])
    return {'core_on': core_on, 'core_off': core_off,
            'addons_on': add_on, 'addons_off': add_off,
            'rows': len(rows)}


import numpy as _np


def _green_mask(a):
    r = a[:, :, 0].astype(_np.int16)
    g = a[:, :, 1].astype(_np.int16)
    b = a[:, :, 2].astype(_np.int16)
    return (g > 105) & (g > r + 22) & (g > b + 22)


def _runs(profile, thr, min_len):
    out = []
    i, n = 0, len(profile)
    while i < n:
        if profile[i] >= thr:
            j = i
            while j < n and profile[j] >= thr:
                j += 1
            if j - i >= min_len:
                out.append((i, j - 1, (i + j - 1) // 2))
            i = j
        else:
            i += 1
    return out


def probe_panel(img):
    """快速判断：屏幕上是不是「盟约全览」那种 2~3 排亮绿圆环（不做 OCR，~10ms）"""
    try:
        W, H = img.size
        crop = img.crop((int(W * SCAN_BOX[0]), int(H * SCAN_BOX[1]),
                         int(W * SCAN_BOX[2]), int(H * SCAN_BOX[3])))
        a = np.asarray(crop.convert('RGB'))
        mask = _green_mask(a)
        ratio = mask.mean()
        if ratio < 0.03:
            return False
        rp = mask.sum(axis=1)
        thr = max(12, int(rp.max() * 0.45))
        runs = _runs(rp, thr, int(crop.height * 0.02))
        return len(runs) >= 2
    except Exception:
        return False
