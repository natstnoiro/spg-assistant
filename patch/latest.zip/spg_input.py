# -*- coding: utf-8 -*-
"""输入层：把「客户区坐标」变成真实点击 / 按键（DPI 感知）

安全约定：
  · 只在游戏窗口处于前台时才动作（否则跳过，不会误点别的窗口）
  · F12 = 急停；也可以创建文件 spg_auto_stop 来停
  · 每次点击前把光标挪过去，点完不动（方便肉眼确认点在哪）
"""
import ctypes
import os
import time
from ctypes import wintypes

user32 = ctypes.windll.user32

MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000
VK_F12 = 0x7B


def dpi_aware():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass


def client_origin(hwnd):
    pt = wintypes.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    return pt.x, pt.y


def is_foreground(hwnd):
    return user32.GetForegroundWindow() == hwnd


VK_F8 = 0x77


def f8_down():
    return bool(user32.GetAsyncKeyState(VK_F8) & 0x8000)


def f12_down():
    return bool(user32.GetAsyncKeyState(VK_F12) & 0x8000)


def _send(dx=0, dy=0, flags=0):
    user32.mouse_event(flags, dx, dy, 0, 0)


def move_to(x, y):
    user32.SetCursorPos(int(x), int(y))


def click_client(hwnd, cx, cy, settle=0.05, hold=0.06):
    """点击客户区 (cx, cy)：绝对坐标下发（避免中途光标被人挪走），且要求窗口在前台"""
    if not is_foreground(hwnd):
        return False
    ox, oy = client_origin(hwnd)
    x, y = int(ox + cx), int(oy + cy)
    sw = max(1, user32.GetSystemMetrics(0))
    sh = max(1, user32.GetSystemMetrics(1))
    ax = int(x * 65535 / (sw - 1))
    ay = int(y * 65535 / (sh - 1))
    move_to(x, y)
    time.sleep(settle)
    flags = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE | MOUSEEVENTF_LEFTDOWN
    user32.mouse_event(flags, ax, ay, 0, 0)
    time.sleep(hold)
    user32.mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE | MOUSEEVENTF_LEFTUP, ax, ay, 0, 0)
    time.sleep(0.12)
    return True


def drag_client(hwnd, x1, y1, x2, y2, steps=12):
    """从 (x1,y1) 拖到 (x2,y2)（拖拽放人用）"""
    if not is_foreground(hwnd):
        return False
    ox, oy = client_origin(hwnd)
    move_to(ox + x1, oy + y1)
    time.sleep(0.08)
    _send(flags=MOUSEEVENTF_LEFTDOWN)
    time.sleep(0.1)
    for i in range(1, steps + 1):
        move_to(ox + x1 + (x2 - x1) * i / steps, oy + y1 + (y2 - y1) * i / steps)
        time.sleep(0.02)
    time.sleep(0.08)
    _send(flags=MOUSEEVENTF_LEFTUP)
    time.sleep(0.15)
    return True


def key(vk, hold=0.05):
    user32.keybd_event(vk, 0, 0, 0)
    time.sleep(hold)
    user32.keybd_event(vk, 0, 2, 0)


def stop_requested(hwnd=None):
    if f12_down():
        return True
    if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'spg_auto_stop')):
        return True
    if hwnd is not None and not is_foreground(hwnd):
        return True
    return False
