# -*- coding: utf-8 -*-
"""exe 入口：默认启动助手；带 --hud 时只启动 HUD 子进程

打包后路径约定：
- 资源（data/、html）在 _MEIPASS 里，只读
- 运行时文件（live_hud.txt、live_state.json、runs.json、records/）放 exe 同级目录
- HTTP 服务根目录 = exe 同级目录（所以启动时把 html 复制过去）
"""
import os
import shutil
import sys

FROZEN = getattr(sys, 'frozen', False)
HERE = os.path.dirname(os.path.abspath(__file__))
HTML = '卫戍协议-规程-抓牌演算器.html'

if FROZEN:
    try:
        import spg_patch
        spg_patch.apply_on_startup()
    except Exception:
        pass
    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    os.environ.setdefault('SPG_DATA', exe_dir)
    os.environ.setdefault('SPG_ROOT', exe_dir)
    try:
        src = os.path.join(sys._MEIPASS, HTML)
        dst = os.path.join(exe_dir, HTML)
        if os.path.exists(src) and (not os.path.exists(dst) or os.path.getmtime(src) > os.path.getmtime(dst)):
            shutil.copy2(src, dst)
    except Exception:
        pass
sys.path.insert(0, HERE)


def main():
    # exe 启动时先看一眼有没有新版本（失败静默跳过，不阻塞）
    if getattr(sys, 'frozen', False) and '--hud' not in sys.argv:
        try:
            import spg_updater
            spg_updater.check_and_update(quiet=True)
        except Exception:
            pass
    if '--hud' in sys.argv:
        import spg_hud
        if spg_hud._singleton():
            spg_hud.Hud().run()
        return
    import spg
    spg.main()


if __name__ == '__main__':
    main()
