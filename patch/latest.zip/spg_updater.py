# -*- coding: utf-8 -*-
"""在线更新（exe 启动时自动检查）

机制：
1. exe 同级目录放 `update_url.txt`，里面写一行清单地址（例如 https://xxx/update.json）
   没有这个文件就跳过更新（源码运行也一样跳过）
2. 清单格式（update.json）：
   {
     "version": "v26",
     "url": "https://.../卫戍协议助手-v26.zip",
     "notes": "修了资金识别",
     "sha256": "可选，用于校验"
   }
3. 发现版本比当前新 → 下载 zip 到临时文件 → 生成 `_apply_update.bat` → 退出自己，
   bat 负责解压覆盖、删临时文件、重新启动 exe

安全兜底：
- 网络失败/超时/清单坏 → 静默跳过，绝不阻塞启动
- 设环境变量 SPG_NO_UPDATE=1 可完全关闭

多源（v25.13）：清单优先 raw，失败自动换 GitHub API contents，再换 jsDelivr；
补丁包同理（jsDelivr 失败用 Contents API 兜底）。每次尝试都记到 exe 同级 `_update_log.txt`。
"""
import base64
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import urllib.request

VERSION = 'v25'


def _exe_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _ver_num(v):
    m = re.findall(r'\d+', str(v or ''))
    return tuple(int(x) for x in m) if m else (0,)


def _get(url, timeout=6):
    req = urllib.request.Request(url, headers={'User-Agent': 'spg-updater/1'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _log(d, msg):
    """记一行到 exe 同级的 _update_log.txt（自动更新失败时能查原因）"""
    try:
        p = os.path.join(d, '_update_log.txt')
        if os.path.exists(p) and os.path.getsize(p) > 200 * 1024:
            os.remove(p)
        with io.open(p, 'a', encoding='utf-8') as f:
            f.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except Exception:
        pass


def _url_variants(url):
    """update_url.txt 里那一条 → 多个候选地址（raw → GitHub API → jsDelivr）

    raw.githubusercontent 在国内经常被掐；只认它的话更新会静默失败（v25.12 之前就是这样，
    安装目录卡在 v25.8 好几天）。
    """
    out = [url] if url else []
    if 'raw.githubusercontent.com/' in url:
        parts = url.split('raw.githubusercontent.com/', 1)[1].split('/')
        if len(parts) >= 4:
            owner, repo, branch = parts[0], parts[1], parts[2]
            path = '/'.join(parts[3:])
            out.append('https://api.github.com/repos/%s/%s/contents/%s' % (owner, repo, path))
            out.append('https://fastly.jsdelivr.net/gh/%s/%s@%s/%s' % (owner, repo, branch, path))
    return out


def _is_api(url):
    return 'api.github.com' in url and '/contents/' in url


def _api_bytes(raw):
    j = json.loads(raw.decode('utf-8'))
    return base64.b64decode((j.get('content') or '').replace('\n', ''))


def _get_bytes(url, timeout=180):
    raw = _get(url, timeout=timeout)
    return _api_bytes(raw) if _is_api(url) else raw


def _get_json(url, timeout=15):
    raw = _get(url, timeout=timeout)
    return json.loads((_api_bytes(raw) if _is_api(url) else raw).decode('utf-8'))


def _src_name(u):
    if _is_api(u):
        return 'api.github.com'
    return 'jsDelivr' if 'jsdelivr' in u else 'raw'


def _fetch_manifest(url, d):
    """清单多源 + 重试；返回 (manifest, 成功用的地址)"""
    last = None
    for u in _url_variants(url):
        for _i in range(2):
            try:
                man = _get_json(u)
                if isinstance(man, dict) and man.get('patch'):
                    _log(d, '清单 OK（%s）' % _src_name(u))
                    return man, u
                last = '清单内容不对'
            except Exception as e:
                last = e
                _log(d, '清单失败（%s）：%s' % (_src_name(u), e))
                time.sleep(1.5)
    raise RuntimeError(last)


def _download_patch(pt, base_url, d):
    """补丁包：清单里的地址 → Contents API 兜底；sha256 不对就换源（别死磕 CDN 旧缓存）"""
    want = str(pt.get('sha256') or '').lower()
    urls = [pt.get('url') or '']
    for u in _url_variants(base_url):
        if _is_api(u):
            urls.append(u.replace('/contents/update.json', '/contents/patch/latest.zip'))
    last = None
    for u in urls:
        if not u:
            continue
        for _i in range(2):
            try:
                data = _get_bytes(u, timeout=180)
                got = hashlib.sha256(data).hexdigest().lower()
                if want and got != want:
                    last = 'sha256 不一致（%s）' % got[:12]
                    _log(d, '补丁内容不对（%s）：sha256 不一致，换源' % _src_name(u))
                    break
                _log(d, '补丁下载 OK %d B（%s）' % (len(data), _src_name(u)))
                return data
            except Exception as e:
                last = e
                _log(d, '补丁下载失败（%s）：%s' % (_src_name(u), e))
                time.sleep(2)
    raise RuntimeError(last)


def _apply_patch_zip(data, ver):
    """把补丁 zip 解到 _patch/ 并重启自己"""
    import zipfile
    d = _exe_dir()
    pdir = os.path.join(d, '_patch')
    os.makedirs(pdir, exist_ok=True)
    tmp = os.path.join(d, '_patch.zip')
    with open(tmp, 'wb') as f:
        f.write(data)
    with zipfile.ZipFile(tmp) as z:
        z.extractall(pdir)
    try:
        io.open(os.path.join(pdir, 'version.txt'), 'w', encoding='utf-8').write(str(ver))
    except Exception:
        pass
    try:
        os.remove(tmp)
    except Exception:
        pass
    exe = os.path.abspath(sys.executable)
    bat = os.path.join(d, '_restart_after_patch.bat')
    io.open(bat, 'w', encoding='gbk', errors='ignore').write(
        '@echo off\r\nping 127.0.0.1 -n 3 >nul\r\nstart "" "%s"\r\ndel /q "%%~f0"\r\n' % exe)
    print('[update] 补丁已解压到 _patch/，重启生效…')
    try:
        subprocess.Popen(['cmd', '/c', bat], cwd=d,
                         creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))
    except Exception:
        pass
    time.sleep(0.4)
    os._exit(0)


def check_and_update(quiet=False):
    if os.environ.get('SPG_NO_UPDATE') == '1':
        return None
    d = _exe_dir()
    url_file = os.path.join(d, 'update_url.txt')
    if not os.path.exists(url_file):
        return None
    try:
        url = io.open(url_file, encoding='utf-8').read().strip().splitlines()[0].strip()
    except Exception:
        return None
    if not url:
        return None
    try:
        man, src = _fetch_manifest(url, d)
    except Exception as e:
        _log(d, '本次跳过更新：%s' % e)
        if not quiet:
            print('[update] 清单读取失败，跳过：%s' % e)
        return None
    remote = str(man.get('version') or '')
    # ---- 优先走补丁包（体积小，几秒下完）----
    pt = man.get('patch') or {}
    if pt.get('version') and pt.get('url'):
        try:
            import spg_patch
            cur_patch = spg_patch.patch_version()
        except Exception:
            cur_patch = ''
        _cur = max(_ver_num(cur_patch or VERSION), _ver_num(VERSION))
        if _ver_num(pt['version']) > _cur:
            _log(d, '发现补丁 %s（当前 %s）' % (pt['version'], cur_patch or VERSION))
            print('[update] 发现补丁 %s：%s' % (pt['version'], pt.get('notes') or ''))
            try:
                data = _download_patch(pt, src, d)
                if pt.get('sha256') and hashlib.sha256(data).hexdigest().lower() != str(pt['sha256']).lower():
                    _log(d, '补丁 sha256 不一致，放弃')
                    print('[update] 补丁校验失败，放弃')
                else:
                    _log(d, '应用补丁 %s，准备重启' % pt['version'])
                    _apply_patch_zip(data, pt['version'])
            except Exception as e:
                _log(d, '补丁下载失败：%s' % e)
                print('[update] 补丁下载失败：%s' % e)
        # 补丁更新完就不再做全量更新
        return None
    if _ver_num(remote) <= _ver_num(VERSION):
        return None

    parts = man.get('parts') or []
    pkg = man.get('url')
    if not parts and not pkg:
        return None
    print('[update] 发现新版本 %s（当前 %s）：%s' % (remote, VERSION, man.get('notes') or ''))
    tmp = os.path.join(d, '_update_download.zip')
    try:
        if parts:
            # 分段包：逐段下载后拼接
            buf = []
            for i, pt in enumerate(parts):
                print('[update] 下载 %d/%d …' % (i + 1, len(parts)))
                buf.append(_get(pt['url'], timeout=180))
            data = b''.join(buf)
        else:
            data = _get(pkg, timeout=180)
        if man.get('sha256'):
            import hashlib
            if hashlib.sha256(data).hexdigest().lower() != str(man['sha256']).lower():
                print('[update] 校验失败，放弃更新')
                return None
        with open(tmp, 'wb') as f:
            f.write(data)
    except Exception as e:
        print('[update] 下载失败：%s' % e)
        return None
    bat = os.path.join(d, '_apply_update.bat')
    exe = os.path.abspath(sys.executable)
    try:
        io.open(bat, 'w', encoding='gbk', errors='ignore').write(
            '@echo off\r\n'
            'chcp 936 >nul\r\n'
            'ping 127.0.0.1 -n 4 >nul\r\n'
            'powershell -NoProfile -Command "Expand-Archive -Force -LiteralPath \'%s\' -DestinationPath \'%s\'"\r\n'
            'del /q "%s"\r\n'
            'start "" "%s"\r\n'
            'del /q "%%~f0"\r\n' % (tmp, d, tmp, exe))
    except Exception:
        return None
    try:
        subprocess.Popen(['cmd', '/c', bat], cwd=d,
                         creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))
    except Exception:
        return None
    print('[update] 即将重启完成更新…')
    time.sleep(0.5)
    os._exit(0)
    return remote


if __name__ == '__main__':
    print(check_and_update())
