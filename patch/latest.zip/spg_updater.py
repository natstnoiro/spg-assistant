# -*- coding: utf-8 -*-
"""在线更新（exe 启动时自动检查）

机制：
1. exe 同级目录放 `update_url.txt`，里面写一行清单地址（例如 https://xxx/update.json）
   没有这个文件就跳过更新（源码运行也一样跳过）
2. 清单格式（update.json）：
   {
     "version": "v26",
     "url": "https://.../卫戍协议助手-v26.zip",
     "notes": "修了资金识别",
     "sha256": "可选，用于校验"
   }
3. 发现版本比当前新 → 下载 zip 到临时文件 → 生成 `_apply_update.bat` → 退出自己，
   bat 负责解压覆盖、删临时文件、重新启动 exe

安全兜底：
- 网络失败/超时/清单坏 → 静默跳过，绝不阻塞启动
- 设环境变量 SPG_NO_UPDATE=1 可完全关闭
"""
import io
import json
import os
import re
import subprocess
import sys
import time
import urllib.request

VERSION = 'v25'


def _exe_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _ver_num(v):
    m = re.findall(r'\d+', str(v or ''))
    return tuple(int(x) for x in m) if m else (0,)


def _get(url, timeout=6):
    req = urllib.request.Request(url, headers={'User-Agent': 'spg-updater/1'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check_and_update(quiet=False):
    if os.environ.get('SPG_NO_UPDATE') == '1':
        return None
    d = _exe_dir()
    url_file = os.path.join(d, 'update_url.txt')
    if not os.path.exists(url_file):
        return None
    try:
        url = io.open(url_file, encoding='utf-8').read().strip().splitlines()[0].strip()
    except Exception:
        return None
    if not url:
        return None
    try:
        man = json.loads(_get(url).decode('utf-8'))
    except Exception:
        if not quiet:
            print('[update] 清单读取失败，跳过')
        return None
    remote = str(man.get('version') or '')
    if _ver_num(remote) <= _ver_num(VERSION):
        return None
    # ---- 优先走补丁包（体积小，几秒下完）----
    pt = man.get('patch') or {}
    if pt.get('version') and pt.get('url'):
        try:
            import spg_patch
            cur_patch = spg_patch.patch_version()
        except Exception:
            cur_patch = ''
        _cur = max(_ver_num(cur_patch or VERSION), _ver_num(VERSION))
        if _ver_num(pt['version']) > _cur:
            print('[update] 发现补丁 %s：%s' % (pt['version'], pt.get('notes') or ''))
            try:
                data = _get(pt['url'], timeout=180)
                if pt.get('sha256'):
                    import hashlib
                    if hashlib.sha256(data).hexdigest().lower() != str(pt['sha256']).lower():
                        print('[update] 补丁校验失败，放弃')
                    else:
                        _apply_patch_zip(data, pt['version'])
                else:
                    _apply_patch_zip(data, pt['version'])
            except Exception as e:
                print('[update] 补丁下载失败：%s' % e)
        # 补丁更新完就不再做全量更新
        return None

    parts = man.get('parts') or []
    pkg = man.get('url')
    if not parts and not pkg:
        return None
    print('[update] 发现新版本 %s（当前 %s）：%s' % (remote, VERSION, man.get('notes') or ''))
    tmp = os.path.join(d, '_update_download.zip')
    try:
        if parts:
            # 分段包：逐段下载后拼接
            buf = []
            for i, pt in enumerate(parts):
                print('[update] 下载 %d/%d …' % (i + 1, len(parts)))
                buf.append(_get(pt['url'], timeout=180))
            data = b''.join(buf)
        else:
            data = _get(pkg, timeout=180)
        if man.get('sha256'):
            import hashlib
            if hashlib.sha256(data).hexdigest().lower() != str(man['sha256']).lower():
                print('[update] 校验失败，放弃更新')
                return None
        with open(tmp, 'wb') as f:
            f.write(data)
    except Exception as e:
        print('[update] 下载失败：%s' % e)
        return None
    bat = os.path.join(d, '_apply_update.bat')
    exe = os.path.abspath(sys.executable)
    try:
        io.open(bat, 'w', encoding='gbk', errors='ignore').write(
            '@echo off\r\n'
            'chcp 936 >nul\r\n'
            'ping 127.0.0.1 -n 4 >nul\r\n'
            'powershell -NoProfile -Command "Expand-Archive -Force -LiteralPath \'%s\' -DestinationPath \'%s\'"\r\n'
            'del /q "%s"\r\n'
            'start "" "%s"\r\n'
            'del /q "%%~f0"\r\n' % (tmp, d, tmp, exe))
    except Exception:
        return None
    try:
        subprocess.Popen(['cmd', '/c', bat], cwd=d,
                         creationflags=getattr(subprocess, 'CREATE_NEW_CONSOLE', 0))
    except Exception:
        return None
    print('[update] 即将重启完成更新…')
    time.sleep(0.5)
    os._exit(0)
    return remote


if __name__ == '__main__':
    print(check_and_update())
