# -*- coding: utf-8 -*-
"""一局结束自动生成 MVP 报告（复盘用）

数据来源：
- 本局事件流（spg_runs 的 events：买/刷新/升本/卖出，带当时的盟约层数）
- 退出时的最终状态（回合、生命、资金、盟约层数）

输出：records/mvp/MVP报告-<时间>.md
"""
import io
import os
import time

HERE = os.path.dirname(os.path.abspath(__file__))
import spg_paths
ROOT = spg_paths.ROOT
OUT_DIR = os.path.join(ROOT, 'records', 'mvp')


def _fmt_covs(covs, top=6):
    pairs = [(k, v) for k, v in (covs or {}).items() if v]
    pairs.sort(key=lambda x: -x[1])
    return ' ｜ '.join('%s %d' % (k, v) for k, v in pairs[:top]) or '—'


def _counts(events):
    c = {'买': 0, '刷新': 0, '升本': 0, '卖出': 0, '收入': 0}
    for e in events or []:
        act = e.get('act') or ''
        for k in c:
            if act.startswith(k):
                c[k] += 1
                break
    return c


def make_report(cur, final=None):
    """cur: runs_current 的内容；final: {'round','life','gold','covs','plan','map'}"""
    try:
        os.makedirs(OUT_DIR, exist_ok=True)
    except Exception:
        pass
    ev = (cur or {}).get('events') or (cur or {}).get('summary') or []
    final = final or {}
    covs = final.get('covs') or {}
    tot = sum(v for v in covs.values() if isinstance(v, int))
    cnt = _counts(ev)
    ts = time.strftime('%m-%d %H:%M')
    name = 'MVP报告-%s.md' % time.strftime('%Y%m%d_%H%M%S')
    path = os.path.join(OUT_DIR, name)
    lines = []
    lines.append('# 卫戍协议 · 本局 MVP 报告')
    lines.append('')
    lines.append('生成时间：%s　|　地图：%s　|　打法：%s' % (
        ts, final.get('map') or (cur or {}).get('map') or '—', final.get('plan') or (cur or {}).get('plan') or '—'))
    lines.append('')
    lines.append('## 一、结束状态')
    lines.append('')
    lines.append('| 项目 | 数值 |')
    lines.append('|---|---|')
    lines.append('| 回合 | %s |' % (final.get('round') or '—'))
    lines.append('| 目标生命 | %s |' % (final.get('life') if final.get('life') is not None else '—'))
    lines.append('| 资金 | %s |' % (final.get('gold') if final.get('gold') is not None else '—'))
    lines.append('| 总层数 | %s |' % tot)
    lines.append('| 盟约结构 | %s |' % _fmt_covs(covs))
    lines.append('')
    lines.append('## 二、操作统计')
    lines.append('')
    lines.append('| 买牌 | 刷新 | 升本 | 卖出 | 收入 |')
    lines.append('|---|---|---|---|---|')
    lines.append('| %d | %d | %d | %d | %d |' % (cnt['买'], cnt['刷新'], cnt['升本'], cnt['卖出'], cnt['收入']))
    lines.append('')
    lines.append('## 三、关键节点（按回合）')
    lines.append('')
    by_round = {}
    for e in ev:
        by_round.setdefault(e.get('r'), []).append(e)
    for r in sorted([x for x in by_round if x], key=lambda x: x):
        acts = ' / '.join(x.get('act') for x in by_round[r])
        covs_r = _fmt_covs(by_round[r][-1].get('covs'), 4)
        lines.append('- **R%s**：%s　　（层数 %s）' % (r, acts, covs_r))
    lines.append('')
    lines.append('## 四、诊断与建议')
    lines.append('')
    pairs = sorted([(k, v) for k, v in covs.items() if v], key=lambda x: -x[1])
    if pairs:
        top = pairs[0]
        share = top[1] / max(1, tot) * 100
        lines.append('- 最高盟约：**%s %d 层**（占 %.0f%%）' % (top[0], top[1], share))
        if share < 35 and len(pairs) >= 3:
            lines.append('- ⚠ 层数比较分散（前三：%s），建议下局早点锁定主盟约，别四面开花。' %
                         '、'.join('%s%d' % p for p in pairs[:3]))
        if tot < 150:
            lines.append('- ⚠ 总层数偏低（%d），通常是升本/买牌节奏偏慢。' % tot)
    if cnt['刷新'] > cnt['买']:
        lines.append('- ⚠ 刷新次数（%d）多于买牌次数（%d），说明商店一直没找到想要的牌，注意别把钱刷空。' %
                     (cnt['刷新'], cnt['买']))
    if final.get('life') is not None and final['life'] <= 10:
        lines.append('- ⚠ 生命只剩 %s，前期漏怪偏多，注意阻挡位。' % final['life'])
    if not lines[-1].startswith('-'):
        lines.append('- 数据正常，暂无明显问题。')
    lines.append('')
    try:
        io.open(path, 'w', encoding='utf-8').write('\n'.join(lines))
        print('[mvp] 已生成', path)
        return path
    except Exception:
        return None


if __name__ == '__main__':
    print(make_report({'events': [], 'map': '测试'}, {'round': 14, 'life': 21, 'gold': 3,
                                                     'covs': {'精准': 80, '灵巧': 40}}))
