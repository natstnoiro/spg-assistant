# -*- coding: utf-8 -*-
"""卫戍协议 游戏内红框提示（overlay）

透明、置顶、鼠标穿透的覆盖层，叠在游戏窗口上：
- 休整期：在「最该买的干员」卡片上画红框 + 顶部提示
- 开局选策略：在推荐策略格子上画红框（需策略图标模板，见 --with-strats）

用法:
    python spg_overlay.py --window          # 自动找明日方舟窗口
    python spg_overlay.py --bbox 0,0,1600,900
    python spg_overlay.py --demo            # 不截屏，仅测试红框渲染
"""
import argparse, ctypes, io, json, os, queue, sys, threading, time, traceback
import tkinter as tk
from tkinter import font as tkfont

from PIL import ImageGrab
import spg_inspect

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)

RED = '#ff2d2d'
GOLD = '#ffcc33'
CYAN = '#2ee6b0'


def dpi_aware():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


BAD_TITLE = ('助手', 'harness', 'browser', 'prts', 'wiki', '计算器', 'console')


def find_window(keywords=('明日方舟', 'Arknights')):
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n == 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        low = buf.value.lower()
        if any(b in low for b in BAD_TITLE):
            return True
        if any(k.lower() in low for k in keywords):
            r = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(r))
            w, h = r.right - r.left, r.bottom - r.top
            if w > 400 and h > 300:
                found.append((hwnd, r.left, r.top, w, h, buf.value))
        return True

    user32.EnumWindows(cb, 0)
    if not found:
        return None
    found.sort(key=lambda x: x[3] * x[4], reverse=True)
    hwnd, x, y, w, h, title = found[0]
    # 客户区（去掉标题栏/边框）
    from ctypes import wintypes
    cr = wintypes.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(cr))
    pt = wintypes.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    print(f'[window] {title} client @ {pt.x},{pt.y} {cr.right}x{cr.bottom}')
    return (pt.x, pt.y, pt.x + cr.right, pt.y + cr.bottom)


class Overlay:
    def __init__(self, bbox, demo=False):
        self.bbox = bbox                 # (x1,y1,x2,y2) 屏幕坐标
        self.demo = demo
        self.q = queue.Queue()
        self.boxes = []
        self.hud = ''
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        self.root.attributes('-transparentcolor', '#010203')
        self.root.configure(bg='#010203')
        if bbox:
            x1, y1, x2, y2 = bbox
            self.root.geometry(f'{x2-x1}x{y2-y1}+{x1}+{y1}')
        else:
            sw = self.root.winfo_screenwidth()
            sh = self.root.winfo_screenheight()
            self.root.geometry(f'{sw}x{sh}+0+0')
        self.cv = tk.Canvas(self.root, bg='#010203', highlightthickness=0)
        self.cv.pack(fill='both', expand=True)
        self.f_big = tkfont.Font(family='Microsoft YaHei', size=15, weight='bold')
        self.f_sm = tkfont.Font(family='Microsoft YaHei', size=10, weight='bold')
        self.info_win = spg_inspect.InfoWindow(self.root)
        self.info = None
        self.root.after(120, self._click_through)
        # HUD 改由独立的 spg_hud.py 进程显示（可拖动）

    def _make_hud(self):
        """可拖动的小提示窗（独立于红框层）"""
        self.hud_win = tk.Toplevel(self.root)
        self.hud_win.overrideredirect(True)
        self.hud_win.attributes('-topmost', True)
        self.hud_win.configure(bg='#0b1512')
        try:
            self.hud_win.attributes('-alpha', 0.88)
        except Exception:
            pass
        self.hud_lbl = tk.Label(self.hud_win, text='卫戍协议助手 · 拖动我调整位置',
                                bg='#0b1512', fg='#2ee6b0', font=self.f_big,
                                justify='left', anchor='w', padx=10, pady=6)
        self.hud_lbl.pack(fill='both', expand=True)
        x = (self.bbox[0] if self.bbox else 40) + 24
        y = (self.bbox[1] if self.bbox else 40) + 24
        self.hud_win.geometry(f'560x120+{x}+{y}')
        self._drag = {'x': 0, 'y': 0}
        for w in (self.hud_win, self.hud_lbl):
            w.bind('<Button-1>', self._drag_start)
            w.bind('<B1-Motion>', self._drag_move)

    def _drag_start(self, e):
        self._drag['x'] = e.x_root - self.hud_win.winfo_x()
        self._drag['y'] = e.y_root - self.hud_win.winfo_y()

    def _drag_move(self, e):
        self.hud_win.geometry(f'+{e.x_root - self._drag["x"]}+{e.y_root - self._drag["y"]}')

    def reposition(self, x, y, w, h):
        try:
            self.root.geometry(f'{w}x{h}+{x}+{y}')
        except Exception:
            pass

    def _click_through(self):
        try:
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            GWL_EXSTYLE = -20
            WS_EX_LAYERED = 0x80000
            WS_EX_TRANSPARENT = 0x20
            WS_EX_TOOLWINDOW = 0x80
            ex = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            ctypes.windll.user32.SetWindowLongW(
                hwnd, GWL_EXSTYLE, ex | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW)
        except Exception:
            pass

    def draw(self):
        self.cv.delete('all')
        for b in self.boxes:
            x1, y1, x2, y2 = b['xy']
            col = b.get('color', RED)
            w = b.get('width', 4)
            if not b.get('nobox'):
                self.cv.create_rectangle(x1, y1, x2, y2, outline=col, width=w)
                self.cv.create_rectangle(x1 + w, y1 + w, x2 - w, y2 - w, outline=col, width=1)
            if b.get('label'):
                self.cv.create_text(x1 + 4, y1 - 10, text=b['label'], anchor='w',
                                    fill=col, font=self.f_sm)
            if b.get('sub'):
                self.cv.create_text((x1 + x2) / 2, y2 + 2, text=b['sub'], anchor='n',
                                    fill=col, font=self.f_sm)
            if b.get('symbol'):
                sym = b['symbol']
                size = max(14, int(min(x2 - x1, y2 - y1) * 0.55))
                cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
                try:
                    fnt = tkfont.Font(family='Segoe UI Symbol', size=size, weight='bold')
                except Exception:
                    fnt = self.f_big
                if sym == 'UR':
                    # 必拿：发光 UR（先描一层暗底，再叠亮色）
                    try:
                        fnt = tkfont.Font(family='Impact', size=size + 2, weight='bold')
                    except Exception:
                        pass
                    for dx, dy, col in ((2, 2, '#3a0d52'), (1, 1, '#8a1fd0'), (0, 0, '#ff4bd8')):
                        self.cv.create_text(cx + dx, cy + dy, text=sym, fill=col, font=fnt)
                else:
                    self.cv.create_text(cx, cy, text=sym, fill=col, font=fnt)
        if self.info:
            self.info_win.show(self.info['text'], self.info['x'], self.info['y'])
        else:
            self.info_win.hide()
        if self.hud and getattr(self, 'hud_lbl', None):
            try:
                self.hud_lbl.config(text=self.hud)
            except Exception:
                pass

    def tick(self):
        try:
            while True:
                data = self.q.get_nowait()
                if 'boxes' in data:
                    self.boxes = data['boxes']
                if 'hud' in data:
                    self.hud = data['hud']
                if 'info' in data:
                    self.info = data['info']
        except queue.Empty:
            pass
        self.draw()
        self.root.after(120, self.tick)

    def run(self):
        self.root.after(50, self.tick)
        self.root.mainloop()


def demo():
    ov = Overlay(None, demo=True)
    sw = ov.root.winfo_screenwidth()
    sh = ov.root.winfo_screenheight()
    ov.q.put({'hud': '演示模式：红框 = 最该买的干员',
              'boxes': [{'xy': (sw * .28, sh * .72, sw * .38, sh * .93), 'label': '买：黍 73'},
                        {'xy': (sw * .40, sh * .72, sw * .50, sh * .93), 'label': '备选：仇白 68', 'color': GOLD}]})
    ov.run()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--window', action='store_true')
    ap.add_argument('--bbox', default=None)
    ap.add_argument('--demo', action='store_true')
    ap.add_argument('--interval', type=float, default=1.6)
    a = ap.parse_args()

    dpi_aware()
    if a.demo:
        demo()
        return

    bbox = None
    if a.bbox:
        bbox = tuple(int(x) for x in a.bbox.split(','))
    elif a.window:
        bbox = find_window()
        if not bbox:
            print('[warn] 没找到游戏窗口，改为全屏')
    ov = Overlay(bbox, demo=False)

    import spg_ocr, spg_score

    state = {'last': None}

    def worker():
        eng = spg_ocr.Engine()
        last_parts = None
        while True:
            try:
                img = ImageGrab.grab(bbox=bbox, all_screens=True) if bbox else ImageGrab.grab(all_screens=True)
                W, H = img.size
                cov = img.crop((int(W * .15), int(H * .05), int(W * .86), int(H * .195)))
                hand = img.crop((int(W * .05), int(H * .73), int(W * .90), int(H * 1.0)))
                st = spg_ocr.analyze(img, eng)
                hand_names = st.get('ops') or []
                covs = st.get('covenants') or {}
                layers = {k: v for k, v in covs.items() if v}
                # 主盟约：层数最高的核心
                cores = [c for c in covs if c in spg_score.CORE]
                main = max(cores, key=lambda c: covs[c]) if cores else '炎'
                recs = spg_score.recommend(hand_names, layers, main,
                                           round_no=st.get('round') or 8,
                                           level=5, gold=st.get('gold') or 30,
                                           goal='core' if st.get('goal') == 'core' else 'clear')
                # 用名字的 x 反推卡片框
                items = [h for h in st.get('hand', []) if h.get('kind') == 'op']
                xs = sorted([h['cx'] for h in items])
                pitch = 0
                if len(xs) >= 2:
                    diffs = sorted([xs[i + 1] - xs[i] for i in range(len(xs) - 1)])
                    pitch = diffs[len(diffs) // 2]
                cw = pitch * 0.92 if pitch else W * 0.098
                top = int(H * 0.735)
                bh = int(H * 0.26)
                rank = {r['name']: (i, r) for i, r in enumerate(recs)}
                boxes = []
                for h in items:
                    i, r = rank.get(h['name'], (9, None))
                    if i == 0:
                        boxes.append({'xy': (h['cx'] - cw / 2, top, h['cx'] + cw / 2, top + bh),
                                      'label': f"买 {r['name']} {round(r['score'])}", 'color': RED, 'width': 5})
                    elif i == 1:
                        boxes.append({'xy': (h['cx'] - cw / 2, top, h['cx'] + cw / 2, top + bh),
                                      'label': f"备选 {r['name']} {round(r['score'])}", 'color': GOLD, 'width': 3})
                tot = sum(layers.values())
                hud = f"R{st.get('round') or '?'}  资金{st.get('gold') or '?'}  总层数{tot}  {main}"
                ov.q.put({'boxes': boxes, 'hud': hud})
            except Exception:
                traceback.print_exc()
            time.sleep(a.interval)

    threading.Thread(target=worker, daemon=True).start()
    ov.run()


if __name__ == '__main__':
    main()
