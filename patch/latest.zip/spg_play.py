# -*- coding: utf-8 -*-
"""盟约打法库：读取 playbooks.json，给 HUD / 面板用。"""
import io, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(HERE, 'data', 'playbooks.json')

with io.open(P, encoding='utf-8') as f:
    PLAY = json.load(f)


def get(cov):
    return PLAY.get(cov)


def brief(cov):
    """一行 HUD 摘要"""
    d = PLAY.get(cov)
    if not d:
        return ''
    st = '、'.join(d.get('strategy') or []) or '—'
    return f"{d['title']}  策略:{st}  升本:{d.get('leveling','')[:24]}"


def outline(cov):
    d = PLAY.get(cov)
    if not d:
        return []
    rows = [('策略', '、'.join(d.get('strategy') or [])),
            ('升本', d.get('leveling', '')),
            ('核心', '、'.join(d.get('core') or [])),
            ('优先级', '→'.join(d.get('priority') or [])),
            ('站位', d.get('position', '')),
            ('目标', d.get('targets', ''))]
    return [(k, v) for k, v in rows if v]
