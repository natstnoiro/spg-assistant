# -*- coding: utf-8 -*-
"""核心盟约选择界面：读出 10 个盟约名 + 判断哪一组被选中

依据：选中组图标亮（>95），未选组暗（~85）。
"""
CORE = ["炎", "萨尔贡", "维多利亚", "谢拉格", "阿戈尔", "叙拉古",
        "卡西米尔", "乌萨斯", "伊比利亚", "莱塔尼亚"]


def detect(img, eng):
    """返回 {'all': [(name, bright)], 'selected': [name...]}"""
    W, H = img.size
    y0 = int(H * 0.16)
    band = img.crop((0, y0, int(W * 0.85), int(H * 0.58)))
    its = eng.run(band, scale=2, pre='auto')
    g = img.convert('L')
    rows = []
    for x in its:
        t = (x['text'] or '').strip()
        if t not in CORE:
            continue
        cx = x['cx']
        cy = x['cy'] + y0
        box = g.crop((int(cx - 38), int(cy - 100), int(cx + 38), int(cy - 42)))
        px = box.tobytes()
        m = sum(px) / max(1, len(px))
        rows.append((t, m))
    seen = {}
    for n, m in rows:
        if n not in seen or m > seen[n]:
            seen[n] = m
    selected = [n for n, m in seen.items() if m > 95]
    return {'all': sorted(seen.items(), key=lambda p: -p[1]), 'selected': selected}
