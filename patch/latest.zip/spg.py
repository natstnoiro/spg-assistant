# -*- coding: utf-8 -*-
"""卫戍协议助手 · 单入口

一条命令同时启动：
  1) 屏幕捕捉 + OCR（自动读回合/资金/盟约层数/手牌干员）
  2) 本地 HTTP 服务 + 浏览器面板（演算器）
  3) 游戏内透明红框（推荐买哪张）

用法:
    python spg.py                 # 全开（默认）
    python spg.py --no-overlay    # 只开面板
    python spg.py --no-open       # 不自动开浏览器
    python spg.py --bbox 0,0,1600,900
    python spg.py --port 8765 --interval 1.6
"""
import argparse, ctypes, io, json, os, sys, threading, time, traceback, urllib.parse, webbrowser

VERSION = 'v25'   # 与 spg_updater.VERSION 保持一致（更新检查以那边为准）
ENABLE_BOARD = True         # 站位推荐已恢复
READY_BOX = (0.870, 0.120, 0.980, 0.195)   # 右上「准备就绪」按钮，用来判断休整期
BANNER_BOX = (0.420, 0.020, 0.600, 0.070)  # 顶部「休息一下 / 作战中」横幅
LOBBY_BOX = (0.780, 0.860, 0.990, 0.970)   # 大厅右下按钮
# 非对局界面的锚点：只要任一框里出现这些词，就当成「待机」完全停读
RESULT_BOX = (0.120, 0.270, 0.340, 0.380)   # 结算页「模拟完成」
COOP_BOX = (0.330, 0.150, 0.660, 0.240)     # 协防视角「层数叠加已禁用」
ENEMY_BOX = (0.318, 0.036, 0.424, 0.092)    # 作战时「8/23」敌人数量
IDLE_ANCHORS = [
    ((0.780, 0.860, 0.990, 0.970), ('模拟', '搜寻', '训练', '队友', '同盟', '创建', '加入',
                                      '准备', '就绪', '取消')),
    ((0.550, 0.800, 0.990, 0.960), ('同盟', '搜寻', '训练', '创建', '加入', '模拟邀约',
                                      '准备', '就绪', '取消')),
    ((0.080, 0.580, 0.320, 0.720), ('已就绪', '就绪')),          # 同盟房间左侧「已就绪」勾选
    ((0.620, 0.010, 0.990, 0.080), ('选择', '难度')),          # 「请选择模拟难度」「选择同盟方式」
    ((0.550, 0.430, 0.990, 0.620), ('模拟邀约', '同盟密钥')),
    ((0.040, 0.020, 0.200, 0.090), ('返回',)),                  # 子页面左上返回
]
PHASE = {'v': 'rest'}
THEME_EQ = '#ff9f1c'
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import spg_paths
# 打包后：程序资源在 _MEIPASS，运行时文件写到 exe 同级目录
# 必须和 HTTP 服务的根目录一致，否则 live_state.json 客户端取不到
HERE = spg_paths.HERE
ROOT = spg_paths.ROOT
WRITABLE = spg_paths.WRITABLE
FROZEN = spg_paths.IS_FROZEN

# 经济表（真实价目/升本/收入）：只读一次。收入显示目前用 min(3+回合+1,12) 公式，
# 表里的 income 字段留作后续校准用
try:
    _ECONOMY = json.load(io.open(os.path.join(HERE, 'data', 'economy.json'), encoding='utf-8'))
except Exception:
    _ECONOMY = {}

import spg_live
import spg_overlay
import spg_ocr
import spg_score
import spg_strat
import spg_equip
import spg_grab
import spg_level
import spg_inspect
import spg_map
import spg_fast
import spg_plan
import spg_open
import spg_input
import spg_goal


def res_tip(bbox):
    """启动时的分辨率提醒：手牌格位/顶栏数字/地图指纹都按 1920x1080 16:9 标定。

    返回 '1920x1080' 这类尺寸文本，供 HUD 显示。勾「不再提示」后不再弹。
    """
    try:
        if not bbox:
            return '?'
        cw, ch = bbox[2] - bbox[0], bbox[3] - bbox[1]
        ratio = cw / max(1, ch)
        ok = abs(ratio - 16 / 9) <= 0.06 and ch >= 700
        txt = f'{cw}x{ch}'
        flag = os.path.join(WRITABLE, '_no_res_tip')
        if os.path.exists(flag):
            return txt
        import tkinter as tk
        root = tk.Tk()
        root.title('分辨率检查')
        root.attributes('-topmost', True)
        root.resizable(False, False)
        head = '✅ 分辨率符合要求' if ok else '⚠️ 分辨率不符合要求'
        color = '#1a7f37' if ok else '#c62828'
        tk.Label(root, text=head, fg=color, font=('Microsoft YaHei', 13, 'bold')).pack(anchor='w', padx=16, pady=(14, 4))
        body = (
            f'当前游戏窗口：{cw} × {ch}　（比例 {ratio:.2f}）\n\n'
            '本程序按以下设置标定：\n'
            '　· 分辨率 1920×1080\n'
            '　· 比例 16:9\n'
            '　· 窗口化（不要全屏拉伸）\n\n'
            '手牌格位、顶栏回合/血量、资金、地图指纹都依赖这个比例；\n'
            '换成别的分辨率识别会明显变差，需要重新标定。'
        )
        if not ok:
            body += '\n\n请进游戏设置改成 1920×1080 窗口化，改完重开本程序。'
        tk.Label(root, text=body, justify='left', font=('Microsoft YaHei', 10)).pack(anchor='w', padx=16)
        v = tk.IntVar()
        tk.Checkbutton(root, text='启动时不再提示', variable=v,
                       font=('Microsoft YaHei', 9)).pack(anchor='w', padx=12, pady=(6, 0))
        def _ok():
            try:
                if v.get():
                    io.open(flag, 'w', encoding='utf-8').write('1')
            except Exception:
                pass
            root.destroy()
        tk.Button(root, text='知道了', width=12, command=_ok).pack(pady=10)
        root.update_idletasks()
        w, h = root.winfo_width(), root.winfo_height()
        root.geometry(f'{w}x{h}+{(root.winfo_screenwidth() - w) // 2}+{(root.winfo_screenheight() - h) // 3}')
        root.after(2500, root.destroy)   # 自动关闭，避免挡住自动化
        root.mainloop()
        return txt
    except Exception:
        traceback.print_exc()
        return '?'



REC_DIR = os.path.join(WRITABLE, 'records')
os.makedirs(REC_DIR, exist_ok=True)
_rec = {'last': 0.0, 'hash': None}


def rec_save(img, st, tag='game'):
    """录制：变化才存，>=3 秒一张，最多留 300 组"""
    try:
        now = time.time()
        if now - _rec['last'] < 20.0:
            return
        small = img.crop((0, 0, img.width, img.height)).resize((32, 18))
        h = hash(tuple(small.convert('L').getdata()))
        if h == _rec['hash']:
            return
        _rec['hash'] = h
        _rec['last'] = now
        ts = time.strftime('%Y%m%d_%H%M%S')
        name = f'{ts}_{tag}'
        img.save(os.path.join(REC_DIR, name + '.png'))
        with io.open(os.path.join(REC_DIR, name + '.json'), 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False, indent=1)
        files = sorted(x for x in os.listdir(REC_DIR) if x.endswith('.png'))
        for old in files[:-300]:
            for ext in ('.png', '.json'):
                p = os.path.join(REC_DIR, old.replace('.png', ext))
                if os.path.exists(p):
                    os.remove(p)
    except Exception:
        pass



def _single_instance():
    """只允许一个助手实例：否则两个 overlay 会同时往游戏上画（♥ 和 ★ 叠在一张卡上）"""
    import os as _os
    import ctypes as _ct
    pidf = _os.path.join(WRITABLE, 'spg.pid')
    try:
        if _os.path.exists(pidf):
            old = int(io.open(pidf, encoding='utf-8').read().strip() or 0)
            if old and old != _os.getpid():
                h = _ct.windll.kernel32.OpenProcess(0x1000, False, old)
                if h:
                    _ct.windll.kernel32.CloseHandle(h)
                    return old
    except Exception:
        pass
    try:
        io.open(pidf, 'w', encoding='utf-8').write(str(_os.getpid()))
    except Exception:
        pass
    return 0


HUD_FILE = os.path.join(WRITABLE, 'live_hud.txt')
MODE_FILE = os.path.join(WRITABLE, 'live_hud_mode.txt')
GOAL_FILE = os.path.join(WRITABLE, 'live_goal.json')
HOVER = {'items': [], 'top': 0, 'bh': 0, 'bbox': None, 'img': None}

# 精锐化需要几张同名（默认 3；星极这类特殊干员 2 张）
try:
    MERGE_NEED = json.load(io.open(os.path.join(HERE, 'data', 'merge_overrides.json'), encoding='utf-8'))
except Exception:
    MERGE_NEED = {}
MERGE_DEFAULT = 3


def write_state(st):
    """给面板网页用：spg.py 不写 live_state.json 的话，网页「实时看牌」一直是旧数据"""
    try:
        d = dict(st)
        d['ts'] = time.time()
        with io.open(os.path.join(WRITABLE, 'live_state.json'), 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False)
    except Exception:
        pass


def set_hud(txt):
    try:
        with io.open(HUD_FILE, 'w', encoding='utf-8') as f:
            f.write(txt)
    except Exception:
        pass


def goal_line(layers, round_no, state):
    """目标层数：面板设定 live_goal.json 后，HUD 显示「当前/预计/差/缺什么」

    没设定返回 ''；evaluate 结果也写进 state['goal']，网页端直接读 live_state.json 显示。
    """
    g = spg_goal.load_goal(GOAL_FILE)
    if not g:
        state.pop('goal', None)
        return ''
    cov, target, cmds = g
    cur = int((layers or {}).get(cov) or 0)
    try:
        ev = spg_goal.evaluate(cov, target, current=cur, round_now=round_no or 1,
                               owned=state.get('_owned') or [], cmd_names=cmds)
    except Exception:
        traceback.print_exc()
        return ''
    state['goal'] = ev
    return spg_goal.brief(ev)


_hud_proc = {'p': None}


def kill_hud():
    try:
        if _hud_proc['p'] and _hud_proc['p'].poll() is None:
            _hud_proc['p'].terminate()
    except Exception:
        pass


def start_hud():
    try:
        import subprocess
        if FROZEN:
            _cmd = [sys.executable, '--hud', '--parent', str(os.getpid())]
        else:
            _cmd = [sys.executable, os.path.join(HERE, 'spg_hud.py'), '--parent', str(os.getpid())]
        _env = dict(os.environ); _env['SPG_DATA'] = WRITABLE
        _hud_proc['p'] = subprocess.Popen(
            _cmd, cwd=WRITABLE, env=_env, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        try:
            with io.open(os.path.join(WRITABLE, '_hud_spawn.log'), 'a', encoding='utf-8') as _lf:
                _lf.write('%s pid=%s cmd=%s\n' % (time.strftime('%H:%M:%S'), _hud_proc['p'].pid, _cmd))
        except Exception:
            pass
        import atexit
        atexit.register(kill_hud)
    except Exception:
        pass


def open_browser_later(port, delay=1.2):
    def go():
        time.sleep(delay)
        url = 'http://127.0.0.1:%d/%s?live=1' % (port, urllib.parse.quote('卫戍协议-规程-抓牌演算器.html'))
        try:
            webbrowser.open(url)
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--window', action='store_true', default=True)
    ap.add_argument('--bbox', default=None)
    ap.add_argument('--port', type=int, default=8765)
    ap.add_argument('--interval', type=float, default=0.03)
    ap.add_argument('--no-overlay', action='store_true')
    ap.add_argument('--no-open', action='store_true')
    ap.add_argument('--auto', action='store_true', help='自动打：休整期自动点「准备就绪」')
    ap.add_argument('--threads', type=int, default=0, help='ONNX 线程数（默认按核数自动）')
    a = ap.parse_args()

    spg_overlay.dpi_aware()

    bbox = None
    hwnd = None
    win = None
    if a.bbox:
        bbox = tuple(int(x) for x in a.bbox.split(','))
    else:
        win = spg_grab.find_hwnd()
        if win:
            hwnd, wtitle, _ = win
            from ctypes import wintypes
            cr = wintypes.RECT()
            ctypes.windll.user32.GetClientRect(hwnd, ctypes.byref(cr))
            pt = wintypes.POINT(0, 0)
            ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(pt))
            bbox = (pt.x, pt.y, pt.x + cr.right, pt.y + cr.bottom)
            print(f'[window] {wtitle} client @ {pt.x},{pt.y} {cr.right}x{cr.bottom}')
        else:
            bbox = spg_overlay.find_window()

    size_txt = res_tip(bbox)

    print('[1/3] 启动本地服务…')
    threading.Thread(target=spg_live.serve, args=(a.port, ROOT), daemon=True).start()
    if not a.no_open:
        open_browser_later(a.port, 0.8)
    start_hud()
    set_hud('正在加载识别模型，约 10 秒…（要求 1920×1080 窗口化，当前 ' + size_txt + '）')
    print('  面板:', 'http://127.0.0.1:%d/' % a.port)
    print('[2/3] 加载 OCR 引擎…')
    eng = spg_ocr.Engine(threads=(a.threads or None))
    _ready = threading.Event()

    def _warm():
        try:
            eng.warmup()
        except Exception:
            pass
        _ready.set()
        set_hud('识别已就绪，等待画面…')

    threading.Thread(target=_warm, daemon=True).start()
    print('[3/3] 启动捕捉线程…（模型后台加载中）')
    # 旧的双worker会同时写 live_state.json（面板显示的就是它写的那份，常年是空手牌）
    # 现在只保留下面的 worker()，由它统一写 live_state.json


    print('  红框:', '开启' if not a.no_overlay else '关闭')

    if a.no_overlay:
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            return

    ov = spg_overlay.Overlay(bbox, demo=False)

    def grid_signature(img):
        """4x4 亮格检测：策略界面的格子明显比缝隙亮"""
        try:
            W, H = img.size
            g = img.convert('L')
            vals = []
            for r in range(4):
                for c in range(4):
                    x = (0.5063 + c * 0.1084) * W
                    y = (0.2842 + r * 0.1841) * H
                    t = 0.0895 * W
                    box = g.crop((int(x + t * 0.2), int(y + t * 0.2),
                                  int(x + t * 0.8), int(y + t * 0.8)))
                    px = list(box.getdata())
                    vals.append(sum(px) / max(1, len(px)))
            bright = sum(1 for v in vals if v > 55)
            return bright >= 11
        except Exception:
            return False

    def strategy_check(img):
        """策略界面：只认「泛用型策略 / 选择策略」标题，避免战场/桌面误判"""
        try:
            W, H = img.size
            for x0, y0, x1, y1 in ((0.44, 0.12, 0.86, 0.32), (0.02, 0.05, 0.45, 0.14)):
                band = img.crop((int(W * x0), int(H * y0), int(W * x1), int(H * y1)))
                its = eng.run(band, scale=2, pre='auto')
                txt = ''.join(x['text'] for x in its)
                if ('泛用型策略' in txt) or ('选择策略' in txt) or ('STRATEGY' in txt.upper()):
                    return True
            return False
        except Exception:
            return False

    state = {'main': '炎'}
    COV = {'v': {}}          # 盟约层数：后台线程慢慢刷（完整 OCR 要 1.5-2.5s）
    LATEST = {'img': None}   # 最新一帧，给后台线程用
    FASTC = {}               # 快速识别的区域指纹缓存
    _map_t = {'t': 0.0}      # 上次地图识别时间
    _lvl_t = {'t': 0.0}      # 上次等级识别时间

    # 地图识别（指纹比对）：识别成功一次后沿用，稳定器过滤单帧误判
    try:
        _maprec = spg_map.Recognizer()
        _mapstab = spg_map.Stabilizer()
    except Exception:
        traceback.print_exc()
        _maprec, _mapstab = None, None

    def main_cov_now():
        return state.get('main', '炎')

    def cur_map():
        return state.get('map') or {}

    def worker():
        nonlocal bbox
        last = None
        tick = 0
        lvl = {'v': None}
        prev_state = {'t': 0, 'round': None, 'gold': None, 'covs': {}}
        ocr_cache = {}
        # 结算页/大厅分支在 st/covs/_plan 赋值之前就会引用它们（首轮会 UnboundLocalError，
        # MVP 报告静默丢字段）——循环外先给默认值
        st = {}
        covs = {}
        _plan = None
        while True:
            try:
                tick += 1
                # 屏幕截图（客户区坐标已校准）；PrintWindow 对 DX 游戏会返回旧帧，只作兜底
                img = None
                try:
                    img = spg_live.grab(bbox)
                except Exception:
                    img = None
                if img is None and hwnd:
                    try:
                        img = spg_grab.capture(hwnd)
                    except Exception:
                        img = None
                if img is None:
                    time.sleep(a.interval)
                    continue
                # ---- 结算页：认到「模拟完成」就当这局结束，立刻归档 ----
                try:
                    if time.time() - state.get('_res_t', 0) > 1.5:
                        state['_res_t'] = time.time()
                        _rt, _ = spg_fast._rec(eng, spg_fast._crop(img, RESULT_BOX), 3)
                        _rt = _rt or ''
                        if ('模拟完成' in _rt) or ('通过回合' in _rt):
                            import spg_runs as _sr
                            import spg_mvp as _mv
                            _cur = _sr._read(_sr.CUR, None)
                            if _cur and state.get('_ended_id') != _cur.get('id'):
                                state['_ended_id'] = _cur.get('id')
                                try:
                                    _sd = os.path.join(ROOT, 'records', 'runs', _cur['id'])
                                    os.makedirs(_sd, exist_ok=True)
                                    img.save(os.path.join(_sd, 'end.png'))
                                except Exception:
                                    pass
                                try:
                                    _cov_now = dict(state.get('layers') or {})
                                    _mv.make_report(_cur, {
                                        'round': st.get('round'), 'life': st.get('life'),
                                        'gold': st.get('gold'), 'covs': _cov_now,
                                        'plan': (_plan or {}).get('title') or '',
                                        'map': (cur_map() or {}).get('name') or ''})
                                except Exception:
                                    pass
                                _sr.finalize(state, 'result')
                                _h = '✅ 本局结束（模拟完成）· 已归档复盘 + MVP 报告'
                                set_hud(_h)
                                ov.q.put({'boxes': [], 'hud': _h, 'info': None})
                                print('[result] 模拟完成 → 归档')
                except Exception:
                    traceback.print_exc()

                # ---- 大厅/菜单：认到「独立模拟」就彻底停（省 CPU）----
                try:
                    _now_l = time.time()
                    if _now_l - state.get('_lobby_t', 0) > 1.5:
                        state['_lobby_t'] = _now_l
                        _is_lobby = False
                        for _box, _words in IDLE_ANCHORS:
                            try:
                                _t, _sc = spg_fast._rec(eng, spg_fast._crop(img, _box), 3)
                            except Exception:
                                continue
                            if _t and any(w in _t for w in _words):
                                _is_lobby = True
                                break
                        if _is_lobby != bool(state.get('lobby')):
                            state['lobby'] = _is_lobby
                            if _is_lobby:
                                try:
                                    import spg_runs as _sr
                                    import spg_mvp as _mv
                                    _cur_run = _sr._read(_sr.CUR, None)
                                    if _cur_run:
                                        try:
                                            _sd = os.path.join(ROOT, 'records', 'runs', _cur_run['id'])
                                            os.makedirs(_sd, exist_ok=True)
                                            img.save(os.path.join(_sd, 'end.png'))
                                        except Exception:
                                            pass
                                        _mv.make_report(_cur_run, {
                                            'round': st.get('round'), 'life': st.get('life'),
                                            'gold': st.get('gold'), 'covs': covs,
                                            'plan': (_plan or {}).get('title') or '',
                                            'map': (cur_map() or {}).get('name') or ''})
                                    _sr.finalize(state, 'lobby')
                                except Exception:
                                    pass
                                _h = '⚔ 大厅/菜单…完全停读（回到对局自动恢复）'
                                set_hud(_h)
                                ov.q.put({'boxes': [], 'hud': _h, 'info': None})
                                print('[lobby] 进入大厅，停读')
                            else:
                                print('[lobby] 离开大厅，恢复')
                    if state.get('lobby'):
                        time.sleep(0.8)
                        continue
                except Exception:
                    traceback.print_exc()

                # ---- 盟约全览界面：自动探测（1.5 秒一次）或按 F8 手动 ----
                _panel_hit = False
                try:
                    _now8 = time.time()
                    if spg_input.f8_down() or (_now8 - state.get('_panel_t', 0) > 1.5):
                        if spg_input.f8_down() or spg_open.probe_panel(img):
                            state['_panel_t'] = _now8
                            _r8 = spg_open.read_full_panel(img, eng)
                            if _r8:
                                state['opening'] = _r8
                                print('[opening]', _r8)
                                _h = '盟约全览：可用 ' + '/'.join(_r8.get('core_on') or [])
                                if _r8.get('core_off'):
                                    _h += '　ban ' + '/'.join(_r8['core_off'])
                                if _r8.get('addons_off'):
                                    _h += '　附加ban ' + '/'.join(_r8['addons_off'])
                                set_hud(_h)
                                ov.q.put({'boxes': [], 'hud': _h, 'info': None})
                                _panel_hit = True
                except Exception:
                    traceback.print_exc()
                if _panel_hit:
                    time.sleep(0.8)
                    continue
                # 先认「是不是休整期」：点准备就绪后进入作战，作战期间停读，回来再继续
                _rtxt, _ = spg_fast._rec(eng, spg_fast._crop(img, READY_BOX), 3)
                _btxt, _ = spg_fast._rec(eng, spg_fast._crop(img, BANNER_BOX), 3)
                # 两个条件都要满足：顶部横幅是「休息一下」+ 右上角有「准备就绪」
                # 只靠准备就绪会误判（作战界面某些状态也能凑出这几个字）
                _looks_rest = (('准备' in (_rtxt or '')) and ('就' in (_rtxt or ''))
                               and ('休息' in (_btxt or '')))
                # 休整期必须「连续稳定 1.2 秒」才认，避免两个画面之间来回抖
                _now2 = time.time()
                if _looks_rest:
                    if not state.get('_rest_since'):
                        state['_rest_since'] = _now2
                else:
                    state['_rest_since'] = None
                _in_rest = bool(state.get('_rest_since')) and (_now2 - state['_rest_since']) >= 1.2
                if not _in_rest:
                    PHASE['miss'] = PHASE.get('miss', 0) + 1
                    if PHASE['miss'] < 3:
                        time.sleep(a.interval)
                        continue
                    if PHASE['v'] != 'combat' and (time.time() - PHASE.get('t_rest', 0)) > 1.2:
                        PHASE['v'] = 'combat'
                        PHASE['t_combat'] = time.time()
                        LATEST['img'] = None
                        _h = '⚔ 非休整期（作战/结算/菜单）…停读，回到休整期自动继续'
                        HOVER['items'] = []
                        HOVER['ts'] = 0
                        set_hud(_h)
                        ov.q.put({'boxes': [], 'hud': _h, 'info': None})
                        print('[phase] 作战/非休整期，暂停读取')
                    time.sleep(a.interval)
                    continue
                PHASE['miss'] = 0
                if PHASE['v'] != 'rest':
                    PHASE['v'] = 'rest'
                    PHASE['t_rest'] = time.time()
                    print('[phase] 回到休整期，恢复读取')
                LATEST['img'] = img
                try:
                    _st0 = spg_fast.read_fast(img, eng, COV['v'], FASTC)
                except Exception:
                    traceback.print_exc()
                    _st0 = spg_ocr.analyze_cached(img, [eng], ocr_cache, do_gold=(tick % 2 == 1))
                _is_game = bool(_st0.get('ops')) or bool(_st0.get('round'))
                if (not _is_game) and strategy_check(img):
                    recs = spg_strat.recommend(main_cov_now())
                    W, H = img.size
                    vis = [r for r in recs if r['idx'] < 16]
                    offv = [r for r in recs if r['idx'] >= 16]
                    _better = bool(offv and vis and offv[0]['score'] > vis[0]['score'])
                    boxes = []
                    for i, r in enumerate(vis[:2]):
                        for idx, x1, y1, x2, y2 in spg_strat.cells(W, H):
                            if idx == r['idx']:
                                _first = (i == 0 and not _better)
                                boxes.append({
                                    'xy': (x1, y1, x2, y2),
                                    'label': (('选 ' if _first else '本屏最优 ') if i == 0 else '备选 ') + f"{r['name']} {round(r['score'])}",
                                    'color': spg_overlay.RED if _first else spg_overlay.GOLD,
                                    'width': 6 if _first else 3})
                    tip = ' / '.join(f"{r['name']}{round(r['score'])}" for r in recs[:3])
                    off = [r for r in recs if r['idx'] >= 16]
                    better = [r for r in off if vis and r['score'] > vis[0]['score']]
                    hint = ''
                    if better:
                        b = better[0]
                        hint = f"　↓ 下滑到第{b['idx']//4+1}屏 第{b['idx']%4+1}格「{b['name']}」{round(b['score'])}"
                        boxes.append({'xy': (W * 0.50, H * 0.235, W * 0.86, H * 0.275),
                                      'label': f"↓ 第{b['idx']//4+1}屏 第{b['idx']%4+1}格 {b['name']} {round(b['score'])}",
                                      'color': '#2ee6b0', 'width': 4})
                    _h = '推荐策略：' + tip + hint
                    set_hud(_h)
                    ov.q.put({'boxes': boxes, 'hud': _h})
                    rec_save(img, {'mode': 'strategy', 'recs': recs}, 'strategy')
                    time.sleep(a.interval)
                    continue
                st = _st0
                # 资金纠错：0~40 之外视为串位；"55/11/88" 这种重复位且比上帧暴涨的，取首位
                try:
                    _g = st.get('gold')
                    if _g is not None:
                        _g = int(_g)
                        _pg = prev_state.get('gold')
                        if not (0 <= _g <= 40):
                            _g = None
                        elif _g >= 11 and _g <= 99 and _g % 11 == 0 and _pg is not None and _g > _pg + 12:
                            _g = _g // 11
                        st['gold'] = _g
                except Exception:
                    pass
                # 过渡帧（加载/黑屏）沿用 6 秒内上一次有效数据，避免 HUD 闪「未识别」
                _now = time.time()
                if not st.get('round') and not st.get('ops') and not any((st.get('covenants') or {}).values()):
                    if _now - prev_state['t'] < 6:
                        st = dict(st)
                        st['round'] = prev_state['round']
                        if st.get('gold') is None:
                            st['gold'] = prev_state['gold']
                        st['covenants'] = prev_state['covs']
                else:
                    prev_state['t'] = _now
                    prev_state['round'] = st.get('round')
                    prev_state['gold'] = st.get('gold')
                    prev_state['covs'] = st.get('covenants') or {}
                if not (st.get('ops') or st.get('covenants') or st.get('round')):
                    try:
                        n = len([x for x in os.listdir(REC_DIR) if x.startswith('_nocap')]) // 2
                        if n < 3:
                            img.save(os.path.join(REC_DIR, f'_nocap{n+1}.png'))
                    except Exception:
                        pass
                hand = st.get('ops') or []
                covs = st.get('covenants') or {}
                # 地图识别（指纹比对）：60ms 左右，每 3 帧一次；连续两帧一致才切换
                if _maprec is not None and (hand or st.get('round')) and (_now - _map_t['t'] > 15):
                    _map_t['t'] = _now
                    try:
                        _m = _maprec.match(img)
                        if _mapstab.observe(_m):
                            if _m:
                                print('[map]', _m)
                            state['map'] = _m
                    except Exception:
                        traceback.print_exc()
                # 盟约层数：本局内只增不减（OCR 偶尔读空，别把总层数打回 0）
                try:
                    _r = st.get('round')
                    if _r == 1 and state.get('last_round') not in (None, 1):
                        state['layers'] = {}
                        state['life'] = None
                    state['last_round'] = _r
                    _keep = state.setdefault('layers', {})
                    if state.get('coop_view'):
                        # 协防视角：顶上读到的层数是队友的，直接沿用自己之前的
                        covs = dict(_keep)
                        st = dict(st)
                        st['covenants'] = covs
                        _coop_skip = True
                    else:
                        _coop_skip = False
                    _tot_before = sum(_keep.values())
                    for _k, _v in ([] if _coop_skip else (covs or {}).items()):
                        _v = int(_v or 0)
                        _old = _keep.get(_k, 0)
                        # 单条盟约一帧暴涨 25 层以上 → OCR 读飞了，丢掉这帧
                        if _old and _v - _old > 25:
                            continue
                        if not _old and _v > 60:
                            continue
                        if _v > _old:
                            _keep[_k] = _v
                    # 按回合给层数上限：超过上限只「本帧不更新」，不再清空已有数据
                    _cap = {1: 40, 2: 90, 3: 160, 4: 240, 5: 340, 6: 460}.get(_r or 0, 999)
                    if sum(_keep.values()) > _cap:
                        _keep.clear()
                        for _k2, _v2 in (covs or {}).items():
                            if int(_v2 or 0) <= _cap // 2:
                                _keep[_k2] = int(_v2)
                    if _keep:
                        covs = dict(_keep)
                        st = dict(st)
                        st['covenants'] = covs
                except Exception:
                    pass
                # 血量误读保护：塔图标常被认成前导 1（20 读成 120）
                try:
                    _lf = st.get('life')
                    if _lf is not None:
                        _prev = state.get('life')
                        if _lf > 60:
                            _s = str(_lf)
                            _fixed = None
                            if _s.startswith('1') and len(_s) >= 3:
                                _cand = int(_s[1:])
                                if 0 < _cand <= 60:
                                    _fixed = _cand
                            if _fixed is None and _prev and _prev <= 60:
                                _fixed = _prev
                            if _fixed is not None:
                                st = dict(st)
                                st['life'] = _fixed
                                _lf = _fixed
                        state['life'] = _lf
                except Exception:
                    pass
                # 左上详情面板：点单位会显示名字 → 用来补「已拥有」清单
                # 每 3 帧读一次就够（省一次 rec 推理）
                try:
                    _selname, _selraw = (None, '')
                    if (tick % 3) == 0:
                        _selname, _selraw = spg_fast.read_selected(img, eng)
                    state['_sel'] = _selname
                    if _selname:
                        _shop_names = {h['name'] for h in (st.get('hand') or [])}
                        _own = state.setdefault('_owned', [])
                        if _selname in spg_ocr._EQ_NORM.values():
                            _selname = None
                        if _selname and _selname not in _shop_names and _selname not in _own:
                            _own.append(_selname)
                            state.setdefault('_owned_cnt', {})[_selname] = state['_owned_cnt'].get(_selname, 0) + 1
                            print('[owned+]', _selname)
                except Exception:
                    pass
                layers = {k: v for k, v in covs.items() if v}
                cores = [c for c in covs if c in spg_score.CORE and (covs.get(c) or 0) > 0]
                main_cov = max(cores, key=lambda c: covs[c]) if cores else state.get('main', '炎')
                state['main'] = main_cov
                # 打法锁定：手里出现某套打法的核心（如 暴躁铁皮）就切到那套
                # 注意：商店卡（st['hand']）不等于已拥有；打法只按主盟约认，避免把商店卡当自己的
                _plan_key, _plan = spg_plan.plan_for(state.get('_owned') or [], main_cov, layers.get(main_cov, 0))
                # 打法被 ban 掉就别硬推：该打法的盟约全在 ban 名单里，或者主盟约被 ban
                try:
                    _bans = set((state.get('opening') or {}).get('core_off') or [])
                    if _plan and _bans:
                        _peng = set((_plan.get('engines') or {}).keys())
                        if _peng and (_peng <= _bans or (main_cov in _bans and not (_peng - _bans))):
                            print('[plan] %s 已被 ban，改回按层数识别' % _plan_key)
                            _plan, _plan_key = None, ''
                except Exception:
                    pass
                # 推荐范围：锁定打法时只按打法的盟约（engines）来；否则主盟约 + 配套
                _act_now = {k for k, v in (st.get('covenants') or {}).items() if v}
                _plan_covs = set(((_plan or {}).get('engines') or {}).keys())
                if _plan_covs:
                    _focus_covs = _plan_covs
                elif _act_now:
                    _main_act = max(_act_now, key=lambda c: (st.get('covenants') or {}).get(c, 0))
                    _focus_covs = {_main_act} | set(spg_score.support_covs(_main_act, 2))
                else:
                    _focus_covs = set()
                # 森蚺（不屈卡西米尔）策略开局固定送「暴躁铁皮」，购买推断抓不到 → 自动记进已拥有
                try:
                    if _plan and '森蚺' in (_plan.get('title') or ''):
                        _own_sn = state.setdefault('_owned', [])
                        if '暴躁铁皮' not in _own_sn:
                            _own_sn.append('暴躁铁皮')
                            state.setdefault('_owned_cnt', {})['暴躁铁皮'] = 1
                            print('[owned+] 暴躁铁皮（森蚺策略固定给）')
                except Exception:
                    pass
                recs = spg_score.recommend(hand, layers, main_cov,
                                           round_no=st.get('round') or 8,
                                           level=5,
                                           gold=(st.get('gold') if st.get('gold') is not None else 30),
                                           plan=_plan,
                                           active=_focus_covs,
                                           owned=state.get('_owned') or [])
                # 策略适配：连续 3 回合没本家牌 → 转保活；R8 起提示转回主盟约
                _tgt_cov = next(iter(((_plan or {}).get('engines') or {}).keys()), '') or main_cov
                try:
                    import spg_adapt
                    # 手牌只有 name，盟约要查干员表
                    _shop_cards = [(h['name'], ((spg_score.OP.get(h['name']) or {}).get('covs') or []))
                                   for h in (allh or [])]
                    spg_adapt.observe(state, st.get('round'), _shop_cards, _tgt_cov)
                    if spg_adapt.is_survive(state):
                        recs = spg_adapt.filter_cards(state, recs)
                    state['_adapt_tip'] = spg_adapt.status_line(state, st.get('round'), _tgt_cov)
                except Exception:
                    state['_adapt_tip'] = ''
                if not recs and not _plan and (st.get('covenants') or {}):
                    # 盟约识别不全/读错时，先别把牌全过滤掉
                    recs = spg_score.recommend(hand, layers, main_cov,
                                               round_no=st.get('round') or 8, level=5,
                                               gold=(st.get('gold') if st.get('gold') is not None else 30),
                                               plan=_plan, owned=state.get('_owned') or [])
                W, H = img.size
                # 手牌坐标是相对 hand ROI 的，要加回 ROI 左边界
                for h in st.get('hand', []):
                    h['ax'] = h['cx'] + W * spg_ocr.ROI['hand'][0]
                # 卡片左上角 = 名字中心 - 固定内边距 - 每字宽度（1920 标定：45 / 11 / 210）
                top, bh = int(H * 0.698), int(H * 0.279)
                allh = sorted(st.get('hand', []), key=lambda h: h['cx'])
                for h in allh:
                    L = max(1, len(h['name']))
                    h['bx'] = h['ax'] - W * 0.0234 - W * 0.0057 * L
                    h['bw'] = W * 0.1094
                def _small(bx, bw):
                    cx2 = bx + bw / 2
                    w2 = bw * 0.5
                    h2 = bh * 0.5
                    cy2 = top + bh / 2
                    return (cx2 - w2 / 2, cy2 - h2 / 2, cx2 + w2 / 2, cy2 + h2 / 2)
                # 排名防抖：EMA 平滑 + 3 分滞回，避免 ♥/★ 在两张卡之间来回跳
                _ema = state.setdefault('ema', {})
                for _r in recs:
                    _ema[_r['name']] = 0.5 * _ema.get(_r['name'], _r['score']) + 0.5 * _r['score']
                _order = sorted([_r['name'] for _r in recs], key=lambda n: -_ema.get(n, 0))
                _prev = state.get('pick') or []
                if _order and _prev:
                    for _keep in _prev[:2]:
                        if _keep in _order and _ema.get(_order[0], 0) - _ema.get(_keep, 0) <= 3:
                            _order.remove(_keep)
                            _order.insert(0, _keep)
                            break
                state['pick'] = _order[:2]
                # 商店没变就冻结标记（避免 OCR 抖动导致 ♥/★ 在几张卡之间跳）
                _now3 = time.time()
                _shop = tuple(h['name'] for h in allh)
                if state.get('shop') != _shop:
                    state['shop'] = _shop
                    state['pick_frozen'] = _order[:2]
                    state['pick_t'] = _now3
                elif _now3 - state.get('pick_t', 0) > 8:
                    state['pick_frozen'] = _order[:2]
                    state['pick_t'] = _now3
                _frozen = state.get('pick_frozen') or _order[:2]
                _order = _frozen + [n for n in _order if n not in _frozen]
                _rank_i = {n: i for i, n in enumerate(_order)}
                recs = sorted(recs, key=lambda r: _rank_i.get(r['name'], 99))
                rank = {r['name']: (i, r) for i, r in enumerate(recs)}

                boxes = []
                # 装备推荐：买哪件、给谁
                ops_in_hand = [h['name'] for h in allh if h.get('kind') == 'op']
                eq_recs = spg_equip.recommend(st.get('equips') or [], main_cov, ops_in_hand, plan=_plan,
                                              round_no=st.get('round') or 8)
                eq_rank = {e['name']: (i, e) for i, e in enumerate(eq_recs)}
                for h in allh:
                    if h.get('kind') != 'equip':
                        continue
                    j, e = eq_rank.get(h['name'], (9, None))
                    if j > 1:
                        continue
                    tgt = e.get('target')
                    lab = ('买装备 ' if j == 0 else '装备备选 ') + f"{h['name']}" + (f" → {tgt}" if tgt else '')
                    boxes.append({'xy': _small(h['bx'], h['bw']),
                                  'label': '', 'sub': str(round(e['score'])), 'symbol': '♥' if j == 0 else '★', 'nobox': True,
                                  'color': THEME_EQ if j == 0 else spg_overlay.GOLD,
                                  'width': 5 if j == 0 else 3})
                for h in allh:
                    if h.get('kind') != 'op':
                        continue
                    i, r = rank.get(h['name'], (9, None))
                    # 精锐化：已有 N-1 张同名，商店这张就是最后一张 → 无论分数都标
                    _need = MERGE_NEED.get(h['name'], MERGE_DEFAULT)
                    _mine = (state.get('_owned_cnt') or {}).get(h['name'], 0)
                    _is_merge = (_mine >= _need - 1 and _mine < _need)
                    if i > 1 and not _is_merge:
                        continue
                    if r is None:
                        r = {'score': 0, 'flags': [], 'status': ''}
                    # 必拿判定：打法核心 / 一号位 / 能开第6人 / 分高 / 明显领先
                    _lead = r['score'] - (recs[1]['score'] if len(recs) > 1 else 0)
                    _flags = r.get('flags') or []
                    # UR 只给「真的该抢」的：打法核心/一号位、能开盟约/质变、或分数够高
                    # 不再因为「领先第二名」或「盟约已经叠很高」就标 UR（那样太吵）
                    _opens = any(f.startswith('开') for f in _flags)
                    _must = (('核心' in _flags) or ('一号位' in _flags) or ('第6名' in _flags)
                             or _opens or r['score'] >= 45)
                    # 叠层类核心（吃层数的盟约）= 空心心；其余推荐 = 星；第二张 = 文字「备选」
                    _stack = bool(set(h.get('covs') or []) &
                                  (set((layers or {}).keys()) | set(spg_score.DAMAGE_COVS) |
                                   set(((_plan or {}).get('engines') or {}).keys())))
                    if _is_merge:
                        _sym, _col = '精', '#ffd24a'
                    elif i == 0 and _stack:
                        _sym, _col = '♡', spg_overlay.RED
                    elif i == 0:
                        _sym, _col = '⭐', spg_overlay.GOLD
                    else:
                        _sym, _col = '备选', '#8fd7ff'
                    boxes.append({
                        'xy': _small(h['bx'], h['bw']),
                        'label': '', 'sub': str(round(r['score'])),
                        'symbol': _sym, 'nobox': True,
                        'color': _col,
                        'width': 5 if i == 0 else 3,
                    })
                tot = sum(layers.values())
                if time.time() - _lvl_t['t'] > 20:
                    _lvl_t['t'] = time.time()
                    try:
                        lvl['v'] = spg_level.read_level(img, eng) or lvl['v']
                    except Exception:
                        pass
                # 窗口被拖动时让红框层跟随
                if tick % 3 == 1 and hwnd:
                    try:
                        from ctypes import wintypes as _wt
                        _cr = _wt.RECT()
                        ctypes.windll.user32.GetClientRect(hwnd, ctypes.byref(_cr))
                        _pt = _wt.POINT(0, 0)
                        ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(_pt))
                        _bb = (_pt.x, _pt.y, _pt.x + _cr.right, _pt.y + _cr.bottom)
                        if _bb != bbox:
                            bbox = _bb
                            ov.reposition(_pt.x, _pt.y, _cr.right, _cr.bottom)
                    except Exception:
                        pass
                _lv = spg_level.upgrade_hint(lvl['v'], st.get('gold'))
                if not st.get('round') and not st.get('ops'):
                    boxes = []
                    _h = "未识别画面：把游戏窗口放到最前（别被浏览器挡住）"
                else:
                    if tot > 0:
                        _tag = main_cov
                    elif recs:
                        # 没叠层时按推荐干员的盟约给个方向
                        _tag = '＋'.join(recs[0].get('covs', [])[:2]) + '（待定）'
                    else:
                        _tag = '待定（先开本家）'
                    _h = f"R{st.get('round') or '?'}  资金{st.get('gold') if st.get('gold') is not None else '?'}"
                    if st.get('life') is not None:
                        _h += f"  血{st.get('life')}"
                    _h += f"  总层数{tot}"
                    _mp = cur_map()
                    if _mp.get('name'):
                        _h += '  ' + _mp['name']
                    if _plan:
                        _t = _plan.get('title') or _plan_key or ''
                        _h += '  【' + (_t[:12] + ('…' if len(_t) > 12 else '')) + '】'
                    _h += '  推荐盟约:' + _tag
                    _gold = st.get('gold')
                    _best = recs[0]['score'] if recs else 0
                    _lead = (recs[0]['score'] - recs[1]['score']) if len(recs) > 1 else 99
                    _rno = st.get('round') or 0
                    _raise_rounds = (2, 3, 5, 7, 9, 11, 13)
                    _core_hit = bool(recs and _plan and recs[0]['name'] in (_plan.get('core') or []))
                    _adv = ''
                    if _gold is not None:
                        _h += f'  可刷{int(_gold)}次'
                        # 规则：钱每回合清零（特例策略除外）→ 别囤钱，尽量花；
                        # 冻结 = 保商店的牌，不是保钱
                        if _core_hit or _best >= 60 or _lead >= 10:
                            _adv = '→ 买 ♥' + (recs[0]['name'] if recs else '')
                        elif _rno in _raise_rounds and _best < 45:
                            _adv = f'→ 升本（R{_rno} 升本回合）'
                        elif _best < 30 and _gold >= 2:
                            _adv = '→ 刷新（没有本家牌）'
                        elif _best >= 45:
                            _adv = '→ 买 ♥' + (recs[0]['name'] if recs else '')
                        elif _best <= 0:
                            _adv = '→ 没有激活盟约的牌：升本/刷新'
                        else:
                            _adv = '→ 凑对子或升本，把钱花掉'
                        _h += '  ' + _adv
                        if state.get('_adapt_tip'):
                            _h += '\n' + state['_adapt_tip']
                        try:
                            _nr = min(3 + int(_rno) + 1, 12)
                            _h += f'（下回合收入{_nr}）'
                        except Exception:
                            pass
                    if not hand:
                        _h += '  （商店收起：展开看牌）'
                    if tot == 0:
                        _h += '  （点左上🔍打开盟约全览，会自动读 ban）'
                    if _lv:
                        _h += '  ' + _lv
                    if _plan:
                        _hint = spg_plan.stage_hint(_plan, st.get('round'))
                        if _hint:
                            _h += '\n' + _hint
                        _own_now = set(state.get('_owned') or [])
                        _miss = [n for n in (_plan.get('priority') or []) if n not in _own_now][:3]
                        _h += '　已有%d' % len(_own_now)
                        if _miss:
                            _h += ' 还差:' + '/'.join(_miss)
                # 读取 HUD 模式（点击 HUD 切换；本版本已关闭站位推荐）
                _mode = 'live'
                try:
                    if ENABLE_BOARD and os.path.exists(MODE_FILE):
                        _mode = io.open(MODE_FILE, encoding='utf-8').read().strip() or 'live'
                except Exception:
                    _mode = 'live'
                _gtxt = goal_line(layers, st.get('round'), state)
                if _gtxt and _mode != 'board':
                    _h += '\n' + _gtxt
                if _mode == 'board':
                    try:
                        import spg_board
                        _mp = cur_map()
                        _mid = _mp.get('id') or 'm01'
                        _cam = _mp.get('camera') or 'expanded'
                        # 站位要用「已拥有」的干员，不是商店里的卡
                        _eqnames = set(spg_ocr._EQ_NORM.values())
                        _names = [n for n in (state.get('_owned') or []) if n and n not in _eqnames]
                        # 同一回合内位置要稳定：同样的干员集合直接复用上次排位
                        _key = tuple(sorted(_names))
                        _cache = state.setdefault('_place', {})
                        if _cache.get('r') != st.get('round'):
                            _cache.clear()
                            _cache['r'] = st.get('round')
                        if _cache.get('key') == _key and _cache.get('pl'):
                            _pl = _cache['pl']
                        else:
                            _pl, _mid = spg_board.plan(_names, _mid)
                            _cache['key'] = _key
                            _cache['pl'] = _pl
                        boxes = []
                        _side = {}
                        try:
                            import spg_board as _sb
                            _side = _sb._load_side()
                        except Exception:
                            pass
                        for _n, _r, _c, _d in _pl:
                            try:
                                _pts = _maprec.cell_corners(_cam, _c, _r)
                                _xs = [p[0] * W for p in _pts]
                                _ys = [p[1] * H for p in _pts]
                                _bb = (min(_xs), min(_ys), max(_xs), max(_ys))
                            except Exception:
                                continue
                            _front = _side.get(_n, 'back') == 'front'
                            boxes.append({'xy': _bb, 'label': _n, 'symbol': _d,
                                          'color': spg_overlay.RED if _front else spg_overlay.GOLD,
                                          'width': 4 if _front else 3})
                        _own_txt = '、'.join(_names[:6]) if _names else '还没有（买牌后自动记录）'
                        _lines = [f'站位[{_mp.get("name") or "地图未识别→按m01"}] 点我切回抓牌']
                        _lines.append('已拥有: ' + _own_txt)
                        if _plan:
                            _lines[0] += '  ' + (_plan.get('title') or '')
                        _sum = f"R{st.get('round') or '?'}  资金{st.get('gold') if st.get('gold') is not None else '?'}"
                        if st.get('life') is not None:
                            _sum += f"  血{st.get('life')}"
                        _sum += f"  层{tot}"
                        _lines.append(_sum)
                        for _n, _r, _c, _d in _pl:
                            _lines.append(f'{_n}({_r},{_c}){_d}')
                        _h = '\n'.join(_lines[:8])
                    except Exception:
                        traceback.print_exc()
                        _h = '[站位] 计算出错，点我切回'
                else:
                    if not eq_recs and (st.get('equips') or []):
                        _h += "　装备:都不建议买"
                    if eq_recs:
                        _parts = []
                        for _e in eq_recs[:2]:
                            _t2 = _e['name'] + (f"→{_e['target']}" if _e.get('target') else '')
                            _parts.append(_t2 + f"({round(_e['score'])})")
                        _h += "　装备:" + " / ".join(_parts)
                    _h = ('[抓牌] 点我切到站位\n' if ENABLE_BOARD else '[抓牌] ') + _h
                set_hud(_h)
                try:
                    st['owned'] = list(state.get('_owned') or [])
                    st['main'] = state.get('main') or main_cov
                    st['goal'] = state.get('goal')
                    if state.get('opening'):
                        st['opening'] = state['opening']
                except Exception:
                    pass
                write_state(st)
                # 买牌推断（只为维护「已拥有」；复盘只记资金变动，不存截图）
                try:
                    _cur_i = [(h['name'], h.get('price') or 0) for h in allh]
                    _g_i = st.get('gold')
                    _pg_i = state.get('_gold_inf')
                    _ps_i = state.get('_shop_inf')
                    if _ps_i is not None and _g_i is not None and _pg_i is not None and _g_i < _pg_i:
                        _cur_names = {n for n, _ in _cur_i}
                        _rem = [(n, p) for n, p in _ps_i if n not in _cur_names]
                        _dg_i = int(_pg_i) - int(_g_i)
                        _sum_p = sum(int(p or 0) for _, p in _rem)
                        # 三个硬条件：扣款 1~12、消失 1~2 张、价格和 == 实际扣款
                        if not (0 < _dg_i <= 12 and _sum_p == _dg_i):
                            _rem = []
                        if 0 < len(_rem) <= 2:      # 刷新会整排消失，这里只认少量消失
                            _own_i = state.setdefault('_owned', [])
                            _cnt_i = state.setdefault('_owned_cnt', {})
                            for _n_i, _p_i in _rem:
                                if _n_i in spg_ocr._EQ_NORM.values():
                                    continue
                                _cnt_i[_n_i] = _cnt_i.get(_n_i, 0) + 1
                                if _n_i not in _own_i:
                                    _own_i.append(_n_i)
                                print('[owned+]', _n_i, 'x', _cnt_i[_n_i])
                    state['_shop_inf'] = _cur_i
                    state['_gold_inf'] = _g_i
                except Exception:
                    pass
                # 每帧跟「本回合商店基线」比对，记买/刷新/升本/卖出
                try:
                    import spg_runs as _sr
                    _sr.note_frame(state, img, st.get('round'), st.get('gold'),
                                   [(h['name'], h.get('price') or 0) for h in allh],
                                   covs, (cur_map() or {}).get('name') or '')
                except Exception:
                    pass
                # 鼠标悬停在手牌上 -> 显示该干员特质
                HOVER['items'] = [(h['bx'], h['bw'], h['name']) for h in allh]
                HOVER['ts'] = time.time()
                # 只在「名字条」那一条带上才响应悬停：策略/盟约图标也在这块区域，
                # 用整块手牌高度会误触发
                _ih = int(getattr(img, 'height', 1080) or 1080)
                HOVER['top'] = int(_ih * 0.885)
                HOVER['bh'] = int(_ih * 0.095)
                HOVER['bbox'] = bbox
                HOVER['img'] = img
                ov.q.put({'boxes': boxes, 'hud': _h})
                try:
                    with io.open(os.path.join(WRITABLE, 'boxes.txt'), 'w', encoding='utf-8') as _f:
                        _f.write('hand=' + str([(h['name'], round(h['ax']), round(h['bx'])) for h in allh]) + chr(10))
                        _f.write('boxes=' + str([(b['label'], [round(v) for v in b['xy']]) for b in boxes]) + chr(10))
                        _f.write('slots=' + str(getattr(spg_fast, 'LAST_SLOTS', [])) + chr(10))
                        try:
                            import spg_cov as _covd
                            _f.write('covs=' + str(getattr(_covd, 'COV_DEBUG', [])) + chr(10))
                        except Exception:
                            pass
                except Exception:
                    pass
                rec_save(img, st, 'game')
            except Exception:
                traceback.print_exc()
            time.sleep(a.interval)


    def hover_thread():
        """80ms 轮询鼠标；先用缓存名字秒出，再后台校正"""
        last_key = None
        last_fix = 0
        while True:
            try:
                from ctypes import wintypes as _wt2
                bb = HOVER.get('bbox')
                items = HOVER.get('items') or []
                top, bh = HOVER.get('top', 0), HOVER.get('bh', 0)
                stale = (time.time() - (HOVER.get('ts') or 0)) > 0.8
                if not (bb and items) or stale:
                    # 手牌没了 / 画面已经停更（回主页、结算、切页面）→ 收掉浮窗
                    if last_key is not None:
                        last_key = None
                        ov.q.put({'info': None})
                    time.sleep(0.15)
                    continue
                if bb and items:
                    p = _wt2.POINT()
                    ctypes.windll.user32.GetCursorPos(ctypes.byref(p))
                    lx, ly = p.x - bb[0], p.y - bb[1]
                    hit = None
                    if 0 <= lx < 3000 and top <= ly <= top + bh:
                        for bx, bw, nm in items:
                            if bx <= lx <= bx + bw:
                                hit = (bx, bw, nm)
                                break
                    key = (hit[2] if hit else None, hit[0] if hit else None)
                    now = time.time()
                    if key != last_key:
                        last_key = key
                        last_fix = 0
                        if not hit:
                            ov.q.put({'info': None})
                        else:
                            _act = {k for k, v in (COV.get('v') or {}).items() if v}
                            t = spg_inspect.text_for(hit[2], _act)
                            if t:
                                ov.q.put({'info': {'text': t, 'x': bb[0] + hit[0],
                                                   'y': bb[1] + top - 150}})
                    # 停留一会儿后，只重认这张卡的名字条（很便宜）
                    if hit and (now - last_fix > 0.8):
                        last_fix = now
                        img = HOVER.get('img')
                        if img is not None:
                            try:
                                bx, bw, nm = hit
                                y0 = int(top + bh * 0.74)
                                strip = img.crop((int(bx + bw * 0.08), y0,
                                                  int(bx + bw * 0.92), top + bh))
                                its = eng.run(strip, scale=2, pre='auto')
                                for it in its:
                                    cand = (it['text'] or '').strip()
                                    if cand in spg_inspect.OPS and cand != nm:
                                        nm = cand
                                        _act = {k for k, v in (COV.get('v') or {}).items() if v}
                                        t = spg_inspect.text_for(nm, _act)
                                        if t:
                                            ov.q.put({'info': {'text': t, 'x': bb[0] + bx,
                                                               'y': bb[1] + top - 150}})
                                        break
                            except Exception:
                                pass
            except Exception:
                pass
            time.sleep(0.08)

    threading.Thread(target=hover_thread, daemon=True).start()

    def cov_thread():
        """盟约层数变化慢，后台每 ~2 秒用完整 OCR 刷一次，不挡主循环"""
        while True:
            img = LATEST.get('img')
            if img is not None:
                try:
                    _c = spg_fast.read_cov(img, eng)
                    if _c:
                        COV['v'] = _c
                except Exception:
                    pass
            time.sleep(5.0)

    threading.Thread(target=cov_thread, daemon=True).start()

    if a.auto:
        def auto_loop():
            """自动点「准备就绪」：只在前台、间隔 >=3s，识别到休整期才点"""
            import spg_input
            _box = (0.870, 0.120, 0.980, 0.195)
            _last = [0.0]
            while True:
                try:
                    if hwnd and spg_input.is_foreground(hwnd) and time.time() - _last[0] > 3.0:
                        _im = spg_live.grab(bbox)
                        _txt, _ = spg_fast._rec(eng, spg_fast._crop(_im, _box), 3)
                        if ('准备' in (_txt or '')) and ('就' in (_txt or '')):
                            if spg_input.f12_down():
                                time.sleep(0.5)
                                continue
                            _w, _h = _im.size
                            ok = spg_input.click_client(hwnd, int(_w * 0.917), int(_h * 0.153))
                            if ok:
                                _last[0] = time.time()
                                set_hud('自动打：已点「准备就绪」，等待战斗…')
                                print('[auto] 点准备就绪')
                except Exception:
                    traceback.print_exc()
                time.sleep(0.8)

        threading.Thread(target=auto_loop, daemon=True).start()
        print('  自动打: 开启（休整期自动点准备就绪）')
    threading.Thread(target=worker, daemon=True).start()
    ov.run()


if __name__ == '__main__':
    try:
        _other = _single_instance()
        if _other:
            print('[skip] 已有助手在跑 (pid %s)，本次启动退出' % _other)
            import sys as _sys
            _sys.exit(0)
        main()
    except SystemExit:
        raise
    except Exception:
        import traceback as _tb
        _p = os.path.join(WRITABLE, '_spg_crash.log')
        try:
            io.open(_p, 'a', encoding='utf-8').write('\n==== %s ====\n' % time.strftime('%Y-%m-%d %H:%M:%S') + _tb.format_exc())
        except Exception:
            pass
        _tb.print_exc()
        raise


