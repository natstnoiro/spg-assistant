# -*- coding: utf-8 -*-
"""盟约条识别：图标模板匹配认名字 + 小数字 OCR 认层数

比纯 OCR 稳：名字不再依赖字体识别，模板只认图标形状。
模板由 build_cov_icons.py 从实机截图裁出来，存在 data/cov_icons/<名字>.png
"""
import io
import os
import re

import numpy as np

import spg_img

HERE = os.path.dirname(os.path.abspath(__file__))
ICON_DIR = os.path.join(HERE, 'data', 'cov_icons')
BAR = (0.24, 0.050, 0.80, 0.215)
TPL_SCALE = 1.0
MATCH_MIN = 0.72

_TEMPLATES = None


def _load():
    global _TEMPLATES
    if _TEMPLATES is not None:
        return _TEMPLATES
    tpl = []
    try:
        for fn in sorted(os.listdir(ICON_DIR)):
            if not fn.endswith('.png'):
                continue
            p = os.path.join(ICON_DIR, fn)
            im = spg_img.load_gray(p)
            if im is None:
                continue
            tpl.append((os.path.splitext(fn)[0], im))
    except Exception:
        tpl = []
    _TEMPLATES = tpl
    return _TEMPLATES


def _digits(eng, crop):
    try:
        from PIL import Image
        txt, _ = _rec(eng, Image.fromarray(crop), 3)
        ds = re.sub(r'\D', '', txt or '')
        return int(ds) if ds else 0
    except Exception:
        return 0


def _rec(eng, im, scale=3):
    from PIL import ImageOps
    im = ImageOps.autocontrast(im.convert('L'))
    if scale != 1:
        im = im.resize((int(im.width * scale), int(im.height * scale)), 1)
    res, _ = eng.ocr(np.array(im.convert('RGB')), use_det=False, use_cls=False, use_rec=True)
    if not res:
        return '', 0.0
    r = res[0]
    return (r[0], r[1]) if isinstance(r[0], str) else (r[1], r[2])


NAME_DY = 0.052      # 名字中心 → 图标中心的纵向偏移（帧高比例）
ICON_HALF = 0.019    # 图标半径（帧宽比例）


_last_learn = 0.0


def _try_learn(bar_img, eng, known_xs, W, H):
    """看到没模板的盟约：用 OCR 的名字 + 位置裁一个图标存成新模板（自动累积）"""
    global _TEMPLATES, _last_learn
    import time as _t
    if _t.time() - _last_learn < 30:
        return []
    _last_learn = _t.time()
    learned = []
    try:
        its = eng.run(bar_img, scale=2, pre='auto')
    except Exception:
        return learned
    ry = int(H * BAR[1])
    for it in its:
        t = (it['text'] or '').strip()
        if not t or re.fullmatch(r'\d{1,3}', t):
            continue
        name = None
        try:
            name = spg_ocr.match_cov(t, cutoff=0.9)
        except Exception:
            name = None
        if not name or os.path.exists(os.path.join(ICON_DIR, name + '.png')):
            continue
        cx = int(it['cx'])
        if any(abs(cx - kx) < 40 for kx in known_xs):
            continue
        cy = int(it['cy'])
        # 图标中心（bar 坐标）
        icy = cy - int(H * NAME_DY) + 0
        half = int(W * ICON_HALF)
        box = (max(0, cx - half), max(0, icy - half), min(bar_img.width, cx + half), min(bar_img.height, icy + half))
        crop = bar_img.crop(box)
        if crop.width < 40 or crop.height < 40:
            continue
        crop = crop.crop((0, 0, crop.width, int(crop.height * 0.70)))
        try:
            crop.save(os.path.join(ICON_DIR, name + '.png'))
            learned.append(name)
        except Exception:
            pass
    if learned:
        _TEMPLATES = None
    return learned

COV_DEBUG = []      # 最近一次识别：[(名字, x, 分数, 数字)]


def read_covs(img, eng):
    """图标模板认名字 + 整条 OCR 认数字（按 x 就近配对）"""
    tpl = _load()
    del COV_DEBUG[:]
    if not tpl:
        return {}
    W, H = img.size
    bar = img.crop((int(W * BAR[0]), int(H * BAR[1]), int(W * BAR[2]), int(H * BAR[3])))
    gray = np.asarray(bar.convert('L'))
    th, tw = tpl[0][1].shape[:2]
    # 1) 图标位置
    found = []
    for name, t in tpl:
        if t.shape[0] >= gray.shape[0] or t.shape[1] >= gray.shape[1]:
            continue
        res = spg_img.match_template(gray, t)
        ys, xs = np.where(res >= MATCH_MIN)
        for y, x in zip(ys, xs):
            found.append((float(res[y, x]), name, int(x), int(y)))
    found.sort(reverse=True)
    picked = []
    seen_names = set()
    for sc, name, x, y in found:
        if name in seen_names:            # 同一种盟约只会出现一次，重复匹配全丢掉
            continue
        if any(abs(x - px) < tw * 0.55 and abs(y - py) < 24 for _, _, px, py in picked):
            continue
        picked.append((sc, name, x, y))
        seen_names.add(name)
    picked.sort(key=lambda t: t[2])
    # 真盟约条的图标几乎在同一水平线上，且匹配分普遍较高；否则是装饰误匹配
    if len(picked) >= 3:
        ys = sorted(p[3] for p in picked)
        y0 = ys[len(ys) // 2]
        same_row = [p for p in picked if abs(p[3] - y0) <= 12]
        picked = same_row
    # 真图标那块有圆环，灰度方差大；纯装饰/纯色背景方差很小 → 丢掉
    if picked:
        keep = []
        for sc, name, x, y in picked:
            patch = gray[y:y + th, x:x + tw]
            if patch.size and float(patch.std()) >= 18:
                keep.append((sc, name, x, y))
        picked = keep
    if len(picked) < 3 or max(p[0] for p in picked) < 0.78:
        return {}
    positions = picked
    # 2) 整条 OCR 拿数字
    out = {}
    for sc, name, x, y in positions:
        top = y + int(th * 1.02)
        bot = y + int(th * 1.55)
        crop = gray[max(0, top):min(gray.shape[0], bot),
                    max(0, x + int(tw * 0.22)):min(gray.shape[1], x + int(tw * 0.78))]
        v = 0
        if crop.size and int(crop.max()) >= 170 and (crop > 150).mean() > 0.01:
            # 两次不同放大比例读，结果不一致就当 0（防止把图标边缘读成数字）
            v1 = _digits(eng, crop)
            v2 = _digits(eng, crop[::2, ::2])
            v = v1 if (v1 == v2 or v2 == 0) else (v1 if v1 else v2)
            if v > 99:
                v = 0
        out[name] = max(out.get(name, 0), v)
        try:
            COV_DEBUG.append((name, int(x), round(float(sc), 2), v))
        except Exception:
            pass
    try:
        _try_learn(bar, eng, [p[2] for p in positions], W, H)
    except Exception:
        pass
    return out


if __name__ == '__main__':
    import sys
    import spg_ocr
    from PIL import Image
    eng = spg_ocr.Engine()
    eng.warmup()
    for p in sys.argv[1:]:
        print(os.path.basename(p), read_covs(Image.open(p).convert('RGB'), eng))
