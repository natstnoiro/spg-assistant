# -*- coding: utf-8 -*-
"""装备推荐：这件装备值不值得买、买给谁"""
import io, json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, 'data')

EQUIP = json.load(io.open(os.path.join(D, 'equipment.json'), encoding='utf-8'))
_p = os.path.join(D, 'equipment_combos.json')
COMBOS = json.load(io.open(_p, encoding='utf-8')) if os.path.exists(_p) else {}
# 反查：单件 -> (组合名, 搭档)
PAIR = {}
for name, ab in COMBOS.items():
    PAIR[ab['a']] = (name, ab['b'])
    PAIR[ab['b']] = (name, ab['a'])
EQ = {e['name']: e for e in EQUIP}
OPS = {o['name']: o for o in json.load(io.open(os.path.join(D, 'ops_full.json'), encoding='utf-8'))}

# 通用叠层装备：任何盟约都吃
GENERIC_LAYER = {'随身身份牌': (6, '装备即 +6 层，任意盟约'),
                 '卫戍推荐信': (4, '每回合 +2 层'),
                 '多功能补剂': (3, '战斗中每次伤害 +1，至多 12')}

# 点名装备 -> 该给谁（按盟约或特质关键字）
TAG_RULES = [
    ('不融冰', '谢拉格'), ('不融', '谢拉格'),
    ('维多利亚', '维多利亚'), ('维式', '维多利亚'),
    ('阿戈尔', '阿戈尔'), ('重刃', '阿戈尔'),
    ('精准', '精准'), ('狙击镜', '精准'),
    ('灼燃', '炎'), ('熔铸', '炎'),
    ('乐部', '莱塔尼亚'), ('乐', '莱塔尼亚'),
    ('流沙', '萨尔贡'), ('浓茶', '萨尔贡'),
    ('雪山', '谢拉格'),
    ('灵巧', '灵巧'), ('涡轮', '灵巧'),
    ('不屈', '不屈'), ('弹射器', '不屈'),
    ('聚合', '聚合'), ('茧甲', '聚合'),
]

ROLE_HINT = {
    '傀影': '主C', '烛煌': '主C', '塔露拉': '主C', '锏': '主C',
    '暴躁铁皮': '主C', '奥尔佳': '主C', '佩佩': '叠层', '冻河': '叠层',
    '黍': '叠层', '逻各斯': '叠层',
}


def score(eq_name, main, hand_ops, layers=None, hand_equips=None, round_no=8):
    e = EQ.get(eq_name)
    if not e:
        return None
    t = e.get('effect') or ''
    s = {'name': eq_name, 'score': 6.0, 'why': [], 'target': None, 'tier': e.get('tier')}

    # 组合件：已有搭档则大幅加分，没有则标出来
    if eq_name in PAIR:
        combo, partner = PAIR[eq_name]
        if partner in (hand_equips or []):
            s['score'] += 40
            s['why'].append('可合成' + combo)
            s['combo'] = combo
        else:
            s['score'] += 8
            s['why'].append('缺' + partner)
            s['combo'] = combo

    if eq_name in GENERIC_LAYER:
        add, why = GENERIC_LAYER[eq_name]
        s['score'] += 30 + add * 3
        s['why'].append(why)
        s['target'] = pick_target(hand_ops, main, any_op=True)
        return s

    for kw, cov in TAG_RULES:
        if kw in eq_name or kw in t:
            if cov == main:
                s['score'] += 32
                s['why'].append('本家·' + cov)
                s['target'] = pick_target(hand_ops, cov)
            else:
                s['score'] -= 12
                s['why'].append('偏' + cov)
            break

    if re.search(r'层数', t):
        s['score'] += 14
        s['why'].append('叠层')
    if re.search(r'攻击力(加成|提升|\s*\+)', t):
        s['score'] += 12
        s['why'].append('加攻')
        if not s['target']:
            s['target'] = pick_target(hand_ops, main)
    if re.search(r'生命上限|防御力|护盾', t):
        s['score'] += 8
        s['why'].append('生存')
    if re.search(r'资金|售价|价格', t):
        s['score'] += 10
        s['why'].append('经济')
        if round_no <= 6:
            s['score'] += 12          # 前期经济装备滚钱，见钱眼开/精打细算玩偶很关键
            s['why'].append('前期滚钱')
    if re.search(r'技能|技力|周转|回转', t):
        s['score'] += 8
        s['why'].append('技力')
    if e.get('tier', 0) >= 5:
        s['score'] += 4
    if not s['target']:
        s['target'] = pick_target(hand_ops, main)
    s['score'] = max(0, min(100, s['score']))
    return s


def pick_target(hand_ops, cov, any_op=False):
    """给谁：优先本家核心，其次主C，最后第一个"""
    best, best_sc = None, -1
    for n in hand_ops or []:
        o = OPS.get(n)
        if not o:
            continue
        sc = 0
        if cov and cov in o.get('covs', []):
            sc += 30
        sc += {'layer': 12, 'converter': 10, 'cap_boost': 8}.get(o.get('kind'), 4)
        if ROLE_HINT.get(n) == '主C':
            sc += 8
        if sc > best_sc:
            best, best_sc = n, sc
    return best


def recommend(hand_equips, main, hand_ops, topn=2, plan=None, round_no=8):
    out = []
    try:
        import spg_plan
        eqs = spg_plan.equipment_priority(plan)
    except Exception:
        eqs = list((plan or {}).get('equipment') or [])
    core = ((plan or {}).get('core') or [None])[0]
    for n in hand_equips or []:
        r = score(n, main, hand_ops, hand_equips=hand_equips, round_no=round_no)
        if not r:
            continue
        if plan and n in eqs:
            k = eqs.index(n)
            r['score'] = min(100, r['score'] + (30 if k < 5 else 15))
            r['why'].append('打法装备')
            if core and core in (hand_ops or []):
                r['target'] = core
        out.append(r)
    out.sort(key=lambda x: -x['score'])
    return [r for r in out if r['score'] >= 12][:topn]
