# -*- coding: utf-8 -*-
"""快速识别（rec-only）：固定格位 + 只跑识别网络

检测网络（det）每调用一次要 0.6–1.0 秒，是整条链路的瓶颈；而手牌、回合、血量、资金
的位置是固定的，直接把裁好的小图送进识别网络（rec-only，15–30ms/次）就够了。
盟约条位置随层数变化，仍用完整 OCR，但放到后台线程每 2 秒刷一次，不阻塞主循环。

实测：手牌 5 格 0.09s + 回合/血量/资金 0.05s ≈ 0.15s/帧（原来 1.8–4.9s）
"""
import io
import json
import os
import time

import numpy as np
from PIL import Image, ImageOps

import spg_ocr
import spg_gold

HERE = os.path.dirname(os.path.abspath(__file__))

# 手牌名字条中心（1920 宽基准）与 y 带
CARD_CENTERS = (775, 1020, 1265, 1510, 1755)
NAME_BAND = (0.912, 0.948)
NAME_HALF = 95
# 顶栏数字与资金数字的小裁剪
ROUND_DIGIT = (0.362, 0.025, 0.406, 0.072)
LIFE_DIGIT = (0.596, 0.018, 0.640, 0.070)
GOLD_DIGIT = (0.900, 0.700, 0.985, 0.762)
# 盟约条（后台线程用）：图标+层数都在中上方，窄一点能省一半时间
COV_ROI = (0.200, 0.045, 0.800, 0.240)

# 价格：干员按阶数（Ⅰ..Ⅵ → 1..6），装备用 equipment.json 的 price
_PRICE_TIER = {'Ⅰ': 1, 'Ⅱ': 2, 'Ⅲ': 3, 'Ⅳ': 4, 'Ⅴ': 5, 'Ⅵ': 6}
_EQ_PRICE = {}
try:
    with io.open(os.path.join(HERE, 'data', 'equipment.json'), encoding='utf-8') as _f:
        _EQ_PRICE = {e['name']: int(e.get('price') or 0) for e in json.load(_f)}
except Exception:
    _EQ_PRICE = {}


_CHESS_PRICE = {}
try:
    with io.open(os.path.join(HERE, 'data', 'economy.json'), encoding='utf-8') as _f:
        _eco = json.load(_f)
    for _t, _v in (_eco.get('chessPrice') or {}).items():
        _CHESS_PRICE[int(_t)] = int((_v or {}).get('normal') or 0)
except Exception:
    _CHESS_PRICE = {}


def price_of(name, kind='op'):
    if kind == 'equip':
        return _EQ_PRICE.get(name, 0)
    try:
        import spg_score
        tier = (spg_score.OP.get(name) or {}).get('tier')
        t = _PRICE_TIER.get(tier)
        # 真实价目：1阶2金、2~4阶3金、5~6阶4金
        if t and _CHESS_PRICE.get(t):
            return _CHESS_PRICE[t]
        return t or 0
    except Exception:
        return 0


LAST_SLOTS = []   # 调试：每个格子读到的原文/置信度

UI_WORDS = {
    '升级', '刷新', '冻结', '收起', '查看', '准备就绪', '回合', '资金', '生命',
    '剩余可放置角色', '本局禁用', '附加盟约', '已拥有', '结束', '确定', '取消',
}


def _rec(eng, im, scale=3):
    """只跑识别网络：返回 (text, score)"""
    im = ImageOps.autocontrast(im.convert('L'))
    if scale != 1:
        im = im.resize((int(im.width * scale), int(im.height * scale)), Image.LANCZOS)
    res, _ = eng.ocr(np.array(im.convert('RGB')), use_det=False, use_cls=False, use_rec=True)
    if not res:
        return '', 0.0
    r = res[0]
    if isinstance(r[0], str):
        return r[0].strip(), float(r[1])
    return (r[1] or '').strip(), float(r[2])


def _crop(img, box):
    W, H = img.size
    return img.crop((int(W * box[0]), int(H * box[1]), int(W * box[2]), int(H * box[3])))


def _digits(txt):
    """从文本里取数字；「一/丨/I/l」当 1（游戏里 1 常被认成笔画）"""
    s = (txt or '').replace('一', '1').replace('丨', '1').replace('I', '1').replace('l', '1')
    ds = ''.join(ch for ch in s if ch.isdigit())
    return int(ds) if ds else None


def hand_sig(img):
    """手牌名字条的廉价指纹（5 格缩到 16x6 灰度），用来判断要不要重认手牌"""
    W, H = img.size
    k = W / 1920.0
    y0, y1 = int(H * NAME_BAND[0]), int(H * NAME_BAND[1])
    h = 0
    for cx in CARD_CENTERS:
        x = cx * k
        c = img.crop((int(x - NAME_HALF * k), y0, int(x + NAME_HALF * k), y1))
        c = c.convert('L').resize((16, 6), Image.BILINEAR)
        h = hash((h, c.tobytes()))
    return h



_NAME_CACHE = {}


def _best_name(raw, cutoff=0.78):
    """名字条常混进杂字（"投奇露希尔"）→ 滑动窗口比一遍，取最像的干员/装备名"""
    import difflib
    if not raw or len(raw) < 2:
        return None, 0.0
    if raw in _NAME_CACHE:
        return _NAME_CACHE[raw]
    if not any('\u4e00' <= ch <= '\u9fff' for ch in raw):
        return None, 0.0
    cands = list(spg_ocr.OP_NAMES)
    try:
        cands += list(spg_ocr.EQ_NAMES)
    except Exception:
        pass
    best, bs = None, 0.0
    for cand in cands:
        n = len(cand)
        if n < 2:
            continue
        for L in (n - 1, n, n + 1):
            if L < 2 or L > len(raw):
                continue
            for i in range(0, len(raw) - L + 1):
                r = difflib.SequenceMatcher(None, raw[i:i + L], cand).ratio()
                if r > bs:
                    bs, best = r, cand
    _NAME_CACHE[raw] = (best, bs) if bs >= cutoff else (None, bs)
    return _NAME_CACHE[raw]

def read_hand(img, eng):
    """固定 5 格名字条 -> 手牌"""
    del LAST_SLOTS[:]
    W, H = img.size
    k = W / 1920.0
    y0, y1 = int(H * NAME_BAND[0]), int(H * NAME_BAND[1])
    roi_x0 = W * spg_ocr.ROI['hand'][0]
    out = []
    seen = []
    for cx in CARD_CENTERS:
        x = cx * k
        c = img.crop((int(x - NAME_HALF * k), y0, int(x + NAME_HALF * k), y1))
        txt, sc = _rec(eng, c, 3)
        # 名字条上下有 ±几像素浮动（装备卡尤其明显）：认不出就上下挪一点再试
        _n0, _m0 = spg_ocr.match_op(txt)
        if not _n0 or _m0 < 0.72:
            _best_txt, _best = txt, (_m0 or 0)
            for _dy in (-6, 6):
                _c2 = img.crop((int(x - NAME_HALF * k), y0 + _dy, int(x + NAME_HALF * k), y1 + _dy))
                _t2, _s2 = _rec(eng, _c2, 3)
                _n2, _m2 = spg_ocr.match_op(_t2)
                if _n2 and _m2 > _best:
                    _best_txt, _best = _t2, _m2
            if _best_txt != txt:
                txt = _best_txt
                sc = max(sc, _best)
        raw = spg_ocr.norm(txt)
        try:
            LAST_SLOTS.append((int(x), (txt or '')[:8], round(sc, 2)))
        except Exception:
            pass
        if not raw or raw in UI_WORDS or sc < 0.45:
            continue
        if raw in spg_ocr._COV_NORM:
            continue
        name, ms = spg_ocr.match_op(txt)
        if not name or ms < 0.72:
            # nametag 常混进杂字（"奥棘刺"/"投奇露希尔"）→ 滑动窗口兜底
            name2, ms2 = _best_name(raw)
            if name2:
                name, ms = name2, min(0.95, ms2)
        # 同一个名字可能真的出现两张（商店里有两张同名卡），只有同一 x 才当重复
        if not name or ms < 0.6:
            continue
        if any(n == name and abs(cx - pcx) < 60 for n, pcx in seen):
            continue
        seen.append((name, cx))
        kind = 'equip' if name in spg_ocr._EQ_NORM.values() else 'op'
        out.append({'name': name, 'kind': kind, 'price': price_of(name, kind), 'score': round(ms, 3),
                    'text': txt, 'cx': round(x - roi_x0, 1),
                    'cy': round((y0 + y1) / 2.0, 1)})
    out.sort(key=lambda d: d['cx'])
    return out


def read_gold(img, eng):
    """资金数字（金菱形右边的数）"""
    c = _crop(img, GOLD_DIGIT)
    txt, sc = _rec(eng, c, 4)
    ds = ''.join(spg_gold._MAP.get(ch, ch) for ch in txt if ch.isdigit() or ch in spg_gold._MAP)
    if not ds:
        return None
    if ds == '8':
        # 只把「可能是空心 0 被认成 8」的情况纠正：孔洞 <=1 就是 0
        try:
            a = np.asarray(c.convert('RGB'))
            m = spg_gold.gold_mask(a)
            ys, xs = np.nonzero(m)
            if len(xs):
                sub = m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
                if spg_gold._holes(sub) <= 1:
                    return 0
        except Exception:
            pass
    return int(ds)


def read_stats(img, eng):
    """回合 / 血量"""
    rt, _ = _rec(eng, _crop(img, ROUND_DIGIT), 4)
    lf, _ = _rec(eng, _crop(img, LIFE_DIGIT), 4)
    return _digits(rt), _digits(lf)


def _sig_crop(img, box):
    c = _crop(img, box).convert('L').resize((12, 5), Image.BILINEAR)
    return hash(c.tobytes())


def read_fast(img, eng, covs=None, cache=None):
    """一帧的快速状态（不发 det）。covs 由后台线程提供；cache 用来跳过没变的区域。"""
    t0 = time.time()
    sig = hand_sig(img)
    if cache is not None and cache.get('hand_sig') == sig:
        hand = cache.get('hand')
    else:
        hand = read_hand(img, eng)
        if cache is not None:
            cache['hand_sig'] = sig
            cache['hand'] = hand
    # 回合/血量/资金：同样只在像素变了才重认
    rsig = _sig_crop(img, ROUND_DIGIT)
    lsig = _sig_crop(img, LIFE_DIGIT)
    gsig = _sig_crop(img, GOLD_DIGIT)
    if cache is not None and cache.get('rlsg') == (rsig, lsig, gsig):
        rnd = cache.get('round')
        life = cache.get('life')
        gold = cache.get('goldv')
    else:
        rnd, life = read_stats(img, eng)
        gold = read_gold(img, eng)
        if cache is not None:
            cache['rlsg'] = (rsig, lsig, gsig)
            cache['round'] = rnd
            cache['life'] = life
            cache['goldv'] = gold
    return {
        'size': list(img.size),
        'round': rnd, 'gold': gold, 'life': life, 'life_max': None,
        'covenants': dict(covs or {}),
        'hand': hand,
        'ops': [h['name'] for h in hand if h['kind'] == 'op'],
        'equips': [h['name'] for h in hand if h['kind'] == 'equip'],
        'cost': round(time.time() - t0, 3),
    }


def read_cov(img, eng):
    """盟约层数：优先图标模板匹配（稳），没模板再退回整条 OCR"""
    try:
        import spg_cov
        d = spg_cov.read_covs(img, eng)
        if d:
            return d
    except Exception:
        pass
    c = _crop(img, COV_ROI)
    its = eng.run(c, scale=2, pre='auto')
    return spg_ocr.parse_covenants(its, c.width)


# 左上「已选中单位」详情面板的名字（点一下待部署/场上单位就会出来）
SEL_NAME_BOX = (0.000, 0.240, 0.150, 0.315)


def read_selected(img, eng):
    """读左上详情面板里的干员名（没有选中单位时返回 (None, '')）"""
    try:
        c = _crop(img, SEL_NAME_BOX)
        txt, sc = _rec(eng, c, 3)
        raw = (txt or '').strip()
        if not raw:
            return None, ''
        name, ms = spg_ocr.match_op(raw)
        if name and ms >= 0.7:
            return name, raw
        # 也可能读到名字 + 等级混在一起，切出前面的中文再试
        import re as _re
        m = _re.match(r'([\u4e00-\u9fff·A-Za-z]{2,6})', raw)
        if m:
            name, ms = spg_ocr.match_op(m.group(1))
            if name and ms >= 0.7:
                return name, raw
    except Exception:
        pass
    return None, ''
