# -*- coding: utf-8 -*-
"""窗口级截图：PrintWindow 优先（不受遮挡/位置影响），失败退回 BitBlt"""
import ctypes
from ctypes import wintypes

import numpy as np
from PIL import Image

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
user32.SetProcessDPIAware()

PW_RENDERFULLCONTENT = 0x00000002
SRCCOPY = 0x00CC0020


BAD = ('助手', 'harness', 'edge', 'chrome', 'firefox', 'browser', 'prts', 'wiki', 'cent', '计算器', '攻略', 'visual studio', 'notepad')


def _classname(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    return buf.value


def find_hwnd(keywords=('明日方舟', 'Arknights')):
    """按标题+窗口类打分，排除浏览器/编辑器"""
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, lp):
        if not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if not n:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        title = buf.value
        low = title.lower()
        if not any(k.lower() in low for k in keywords):
            return True
        if any(b in low for b in BAD):
            return True
        r = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        w, h = r.right - r.left, r.bottom - r.top
        exact = title.strip() in ('明日方舟', 'Arknights')
        if not exact and (w <= 640 or h <= 480):
            return True
        score = 0
        if title.strip() in ('明日方舟', 'Arknights'):
            score += 200
        elif len(title.strip()) > 12:
            score -= 80
        cls = _classname(hwnd)
        if 'Unity' in cls or 'UnrealWindow' in cls:
            score += 60
        score += min(30, w * h // 400000)
        found.append((score, hwnd, title, (r.left, r.top, w, h)))
        return True

    user32.EnumWindows(cb, 0)
    if not found:
        return None
    found.sort(key=lambda x: -x[0])
    score, hwnd, title, rect = found[0]
    return hwnd, title, rect




def _client_size(hwnd):
    cr = wintypes.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(cr))
    return cr.right, cr.bottom


def capture(hwnd, mode='print'):
    w, h = _client_size(hwnd)
    if w <= 0 or h <= 0:
        return None
    hdc = user32.GetDC(hwnd)
    mem = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    old = gdi32.SelectObject(mem, bmp)
    try:
        ok = 0
        if mode == 'print':
            ok = user32.PrintWindow(hwnd, mem, PW_RENDERFULLCONTENT)
        if not ok:
            gdi32.BitBlt(mem, 0, 0, w, h, hdc, 0, 0, SRCCOPY)
        class BMI(ctypes.Structure):
            _fields_ = [('biSize', wintypes.DWORD), ('biWidth', wintypes.LONG),
                        ('biHeight', wintypes.LONG), ('biPlanes', wintypes.WORD),
                        ('biBitCount', wintypes.WORD), ('biCompression', wintypes.DWORD),
                        ('biSizeImage', wintypes.DWORD), ('biXPelsPerMeter', wintypes.LONG),
                        ('biYPelsPerMeter', wintypes.LONG), ('biClrUsed', wintypes.DWORD),
                        ('biClrImportant', wintypes.DWORD)]
        bi = BMI()
        bi.biSize = ctypes.sizeof(BMI)
        bi.biWidth = w
        bi.biHeight = -h
        bi.biPlanes = 1
        bi.biBitCount = 32
        bi.biCompression = 0
        buf = ctypes.create_string_buffer(w * h * 4)
        gdi32.GetDIBits(mem, bmp, 0, h, buf, ctypes.byref(bi), 0)
        arr = np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4)[:, :, :3]
        return Image.fromarray(arr[:, :, ::-1].copy())  # BGR -> RGB
    finally:
        gdi32.SelectObject(mem, old)
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(mem)
        user32.ReleaseDC(hwnd, hdc)


if __name__ == '__main__':
    import sys
    r = find_hwnd()
    if not r:
        print('no window')
        sys.exit(1)
    hwnd, title, rect = r
    print('hwnd', hwnd, title, rect)
    for mode in ('print', 'bitblt'):
        im = capture(hwnd, mode)
        if im is None:
            print(mode, 'None')
            continue
        p = rf'D:\文档\deepseek-harness\default-workspace\research\cap_{mode}.png'
        im.save(p)
        a = np.asarray(im)
        print(mode, im.size, 'mean', round(float(a.mean()), 1), '->', p)
