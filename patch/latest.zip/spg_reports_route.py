# -*- coding: utf-8 -*-
"""给 HTTP 服务挂上「报错反馈页 / 下载页」的路由

在 spg_live.serve 的 H 类里注入：
  GET  /report          报错反馈页（报错反馈.html）
  GET  /api/reports     已收到的报错列表（JSON）
  GET  /api/files       可下载的更新包列表（JSON）
  POST /api/report      提交报错（JSON：name/desc/version/images[base64]/logs[text]）
"""
import base64
import io
import json
import os
import time

ROUTES = '''

        # ---------- 报错反馈 / 下载 ----------
        def _send_json(self, obj):
            body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def _send_html_file(self, fp):
            try:
                body = io.open(fp, 'rb').read()
            except Exception:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def _reports(self):
            out = []
            base = os.path.join(directory, 'records', 'reports')
            if not os.path.isdir(base):
                return out
            for d in sorted(os.listdir(base), reverse=True)[:50]:
                p = os.path.join(base, d)
                if not os.path.isdir(p):
                    continue
                meta = {}
                try:
                    meta = json.load(io.open(os.path.join(p, 'meta.json'), encoding='utf-8'))
                except Exception:
                    pass
                shots = [f for f in os.listdir(p) if f.startswith('shot_')]
                logs = [f for f in os.listdir(p) if f.startswith('log_')]
                out.append({'id': d, 'meta': meta, 'shots': len(shots), 'logs': len(logs),
                            'dir': 'records/reports/' + d})
            return out

        def _files(self):
            out = []
            for f in sorted(os.listdir(directory)):
                if f.lower().endswith('.zip'):
                    p = os.path.join(directory, f)
                    out.append({'name': f, 'size': os.path.getsize(p),
                                'mtime': time.strftime('%m-%d %H:%M', time.localtime(os.path.getmtime(p))),
                                'url': '/' + f})
            return out

        def _save_report(self):
            ln = int(self.headers.get('Content-Length') or 0)
            raw = self.rfile.read(ln)
            data = json.loads(raw.decode('utf-8') or '{}')
            rid = time.strftime('%Y%m%d_%H%M%S')
            base = os.path.join(directory, 'records', 'reports', rid)
            os.makedirs(base, exist_ok=True)
            n = 0
            for i, img in enumerate(data.get('images') or []):
                try:
                    b64 = img.split(',', 1)[-1]
                    with open(os.path.join(base, 'shot_%02d.jpg' % i), 'wb') as f:
                        f.write(base64.b64decode(b64))
                    n += 1
                except Exception:
                    pass
            for i, lg in enumerate(data.get('logs') or []):
                try:
                    io.open(os.path.join(base, 'log_%02d.txt' % i), 'w', encoding='utf-8').write(str(lg))
                except Exception:
                    pass
            meta = {k: data.get(k) for k in ('name', 'desc', 'version', 'ua')}
            meta['id'] = rid
            meta['time'] = time.strftime('%Y-%m-%d %H:%M:%S')
            meta['shots'] = n
            io.open(os.path.join(base, 'meta.json'), 'w', encoding='utf-8').write(
                json.dumps(meta, ensure_ascii=False, indent=1))
            return {'ok': True, 'id': rid, 'shots': n}
'''

HOOK_GET = '''
            if self.path.startswith('/api/reports'):
                self._send_json(self._reports()); return
            if self.path.startswith('/api/files'):
                self._send_json(self._files()); return
            if self.path.startswith('/report'):
                self._send_html_file(os.path.join(directory, '报错反馈.html')); return
'''

HOOK_POST = '''
        def do_POST(self):
            if self.path.startswith('/api/report'):
                try:
                    self._send_json(self._save_report())
                except Exception as e:
                    self._send_json({'ok': False, 'err': str(e)})
                return
            self.send_error(404)
'''


def patch(path):
    s = io.open(path, encoding='utf-8').read()
    if '_send_json' not in s:
        s = s.replace("\n        def do_GET(self):", ROUTES + "\n        def do_GET(self):", 1)
        s = s.replace("        def do_GET(self):\n", "        def do_GET(self):\n" + HOOK_GET, 1)
        # do_POST 放在 do_GET 之前
        s = s.replace(HOOK_GET, HOOK_GET + HOOK_POST, 1)
        io.open(path, 'w', encoding='utf-8').write(s)
    return True


if __name__ == '__main__':
    print(patch(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'spg_live.py')))
