# -*- coding: utf-8 -*-
"""轻量评分：给 overlay 用。规则与 HTML 版保持同一口径（简化）。"""
import io, json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')

with io.open(os.path.join(DATA, 'ops_full.json'), encoding='utf-8') as f:
    OPS = json.load(f)
with io.open(os.path.join(DATA, 'covs_full.json'), encoding='utf-8') as f:
    COVS = json.load(f)
OP = {o['name']: o for o in OPS}
COV = {c['name']: c for c in COVS}

import spg_ocr
TN = spg_ocr.TIER_ROMAN
RATE = {"获得时": 1.7, "进入休整期时": 1.0, "休整期结束时": 1.0, "战斗开始时": 1.0,
        "战斗中": 1.9, "部署时": 1.6, "售出时": 1.2, "other": 0.8}
# 这三个是「加伤害」的核心，收益比主盟约更直接（除非玩不屈大丑流）
DAMAGE_COVS = {'精准': 14, '奥术': 14, '灵巧': 12}
CORE = ["炎", "萨尔贡", "维多利亚", "谢拉格", "阿戈尔", "叙拉古", "卡西米尔",
        "乌萨斯", "伊比利亚", "莱塔尼亚"]
CARRY = {"塔露拉", "锏", "烛煌", "荒芜拉普兰德", "浊心斯卡蒂", "维娜·维多利亚", "耀骑士临光",
         "玛恩纳", "乌尔比安", "缪尔赛思", "蕾缪安", "引星棘刺", "纯烬艾雅法拉", "酒神", "夕",
         "真言", "克莱门莎", "泥岩", "史尔特尔", "歌蕾蒂娅", "艾雅法拉", "异客", "鸿雪"}


def throughput(o, elite=True):
    gains = (o.get('gains_e') if elite else o.get('gains_i')) or {}
    cap = (o.get('cap_e') if elite else o.get('cap_i')) or 0
    rate = RATE.get(o.get('trig'), 0.8)
    total = 0.0
    best = 0.0
    for c, g in gains.items():
        p = g * rate
        if cap:
            p = min(p, cap)
        total += p
        best = max(best, p)
    if o.get('kind') == 'converter':
        total = max(total, 4)
    if o.get('kind') == 'cap_boost':
        total = max(total, 6)
    if o.get('kind') == 'scaling':
        total = 0
    return total, best


def score(name, owned_covs, layers, main, round_no=8, level=5, gold=30, gear=0, goal='clear', ugly=False):
    """owned_covs: {cov: 不同干员数}；layers: {cov: 层数}"""
    o = OP.get(name)
    if not o:
        return None
    eff = dict(owned_covs)
    for c in o['covs']:
        eff[c] = eff.get(c, 0) + 1
    if eff.get('调和', 0) > 0:
        for c in CORE:
            eff[c] = eff.get(c, 0) + 1

    flags = []
    bond = 0
    for c in o['covs']:
        need = COV[c]['need'] if c in COV else 2
        cur = owned_covs.get(c, 0)
        would = eff.get(c, 0)
        if c in CORE:
            if cur < need <= would:
                bond += 38
                flags.append('开' + c)
            if cur < 6 <= would:
                bond += 58
                flags.append('第6名' + c)
        else:
            if cur < need <= would:
                bond += 22
                flags.append('开' + c)
    if main in o['covs']:
        bond += 30 if (main in DAMAGE_COVS or ugly) else 12
    if len(o['covs']) >= 3:
        bond += 10
    bond = min(100, bond)

    tot, per = throughput(o)
    stack = min(100, tot / 20 * 100)
    if o.get('kind') == 'converter':
        stack = max(stack, 70)
    if o.get('kind') == 'cap_boost':
        stack = max(stack, 65)

    tt = (o.get('t1') or '') + (o.get('t2') or '')
    econ = 0
    if re.search('资金', tt): econ += 62
    if re.search('刷新', tt): econ += 52
    if re.search('装备', tt): econ += 42
    if o.get('ttype') == '整备能力': econ += 22
    econ = min(100, econ)

    combat = {1: 22, 2: 34, 3: 46, 4: 58, 5: 72, 6: 88}.get(TN.get(o['tier'], 0), 0)
    if name in CARRY: combat += 12
    combat = min(100, combat)

    W = {'early': [0.34, 0.16, 0.24, 0.26], 'mid': [0.28, 0.30, 0.17, 0.25],
         'late': [0.20, 0.30, 0.10, 0.40]}['early' if round_no <= 4 else 'mid' if round_no <= 9 else 'late']
    if goal == 'core':
        W = [W[0], W[1] + .10, max(.04, W[2] - .10), W[3] + .05]

    total = bond * W[0] + stack * W[1] + econ * W[2] + combat * W[3]
    if o['covs'] and o['covs'][0] == '维多利亚':
        total += min(20, gear * 6) * 0.08
    # 伤害盟约（精准/奥术/灵巧）额外加权：实战里这三个才是主要输出
    for c in o['covs']:
        if c in DAMAGE_COVS:
            total += DAMAGE_COVS[c]
    if main in o['covs']:
        # 主盟约：如果本身就是伤害盟约，正常加分；否则收益不高，只给很少
        # （不屈大丑流例外：不屈是终端，ugly=True 时保留高分）
        if main in DAMAGE_COVS:
            total += 10
        elif ugly:
            total += 10
        else:
            total += 3
    tn = TN.get(o['tier'], 0)
    if tn > level:
        total -= 18 if tn == level + 1 else 34
    if tn > gold and tn <= level:
        total -= 8
    return {'name': name, 'score': max(0, min(100, total)), 'flags': flags,
            'tp': round(tot, 1), 'tier': o['tier'], 'covs': o['covs']}


def recommend(hand_names, layers, main, round_no=8, level=5, gold=30, gear=0, goal='clear', plan=None,
              owned=None, active=None):
    # 不屈大丑流：主盟约就是终端，保持原来的加成
    _ugly = bool(plan) and ('不屈' in ((plan or {}).get('title') or '') or
                            '大丑' in str((plan or {}).get('strategy') or '') or
                            '不屈' in str((plan or {}).get('engines') or {}))
    """hand_names 是「候选（商店里的卡）」；owned 是「已拥有干员」（不知道就传 None/[]）

    注意：商店卡片不等于已拥有，不能拿来算「开盟约」，否则会虚高。
    """
    owned_covs = {}
    for n in (owned or []):
        o = OP.get(n)
        if not o:
            continue
        for c in o['covs']:
            owned_covs[c] = owned_covs.get(c, 0) + 1
    if owned_covs.get('调和', 0) > 0:
        for c in CORE:
            owned_covs[c] = owned_covs.get(c, 0) + 1
    out = []
    for n in hand_names:
        r = score(n, owned_covs, layers, main, round_no, level, gold, gear, goal, ugly=_ugly)
        if r:
            out.append(r)
    # 只按「已激活（有层数）的盟约」推荐：不属于任何激活盟约的卡直接丢掉
    if active:
        act = set(active)
        out = [r for r in out if set(r.get('covs') or []) & act]
    fam = set((plan or {}).get('engines', {}).keys())
    prio = list((plan or {}).get('priority') or [])
    for r in out:
        _dmg = set(r.get('covs') or []) & set(DAMAGE_COVS)
        if main and main not in r.get('covs', []):
            if plan and (set(r.get('covs') or []) & fam):
                r['score'] *= 0.85
                r['flags'].append('副盟约')
            elif _dmg:
                # 精准/奥术/灵巧加的是实打实的伤害，不作为「非本家」打压
                r['score'] *= 0.92
                r['flags'].append('伤害盟约')
            else:
                r['score'] *= 0.5
                r['flags'].append('非本家')
        if plan:
            if r['name'] in prio[:4]:
                r['score'] = min(100, r['score'] + 35)
                r['flags'].append('核心')
            elif r['name'] in prio:
                r['score'] = min(100, r['score'] + 18)
                r['flags'].append('优先')
            if prio and r['name'] == prio[0]:
                r['score'] = min(100, r['score'] + 12)
                r['flags'].append('一号位')
    out.sort(key=lambda x: -x['score'])
    return out


_COV_MEMBERS = None


def _cov_members():
    global _COV_MEMBERS
    if _COV_MEMBERS is not None:
        return _COV_MEMBERS
    d = {}
    try:
        import io as _io, json as _json, os as _os
        p = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'data', 'covs_full.json')
        for c in _json.load(_io.open(p, encoding='utf-8')):
            d[c['name']] = list(c.get('members') or [])
    except Exception:
        d = {}
    _COV_MEMBERS = d
    return d


def support_covs(main, topn=2):
    """主盟约的「配套小盟约」：主盟约成员身上最常一起出现的其它盟约"""
    members = _cov_members().get(main) or []
    cnt = {}
    for m in members:
        o = OP.get(m)
        if not o:
            continue
        for c in (o.get('covs') or []):
            if c == main or c in CORE:
                continue
            cnt[c] = cnt.get(c, 0) + 1
    return [c for c, _ in sorted(cnt.items(), key=lambda x: -x[1])[:topn]]
