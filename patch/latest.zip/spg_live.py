# -*- coding: utf-8 -*-
"""卫戍协议 实时看牌守护进程

- 每隔 N 秒截一次游戏窗口
- OCR 出：回合 / 资金 / 盟约层数 / 手牌干员
- 写入 live_state.json
- 同时用 http.server 把工具目录挂到 127.0.0.1:8765，打开即用

用法:
    python spg_live.py                # 默认全屏截取
    python spg_live.py --window       # 自动找「明日方舟」窗口
    python spg_live.py --bbox 0,0,1920,1080
    python spg_live.py --port 8765 --interval 1.5
"""
import argparse, io, json, os, sys, threading, time, traceback, webbrowser, urllib.parse

from PIL import Image, ImageGrab

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import spg_paths

# 统一路径解析：详见 spg_paths.py（SPG_ROOT → _MEIPASS → 源码根）
ROOT = spg_paths.ROOT
STATE = os.path.join(ROOT, 'live_state.json')


def find_window(keywords=('明日方舟', 'Arknights', 'MAA', '卫戍')):
    """返回 (x, y, w, h) 或 None"""
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        user32.SetProcessDPIAware()
        found = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def cb(hwnd, lparam):
            if not user32.IsWindowVisible(hwnd):
                return True
            n = user32.GetWindowTextLengthW(hwnd)
            if n == 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value
            if any(k.lower() in title.lower() for k in keywords):
                rect = wintypes.RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(rect))
                w, h = rect.right - rect.left, rect.bottom - rect.top
                if w > 400 and h > 300:
                    found.append((rect.left, rect.top, w, h, title))
            return True

        user32.EnumWindows(cb, 0)
        if found:
            found.sort(key=lambda r: r[2] * r[3], reverse=True)
            x, y, w, h, title = found[0]
            print(f'[window] {title} @ {x},{y} {w}x{h}')
            return (x, y, x + w, y + h)
    except Exception as e:
        print('[window] 失败:', e)
    return None


def grab(bbox):
    if bbox:
        return ImageGrab.grab(bbox=bbox, all_screens=True)
    return ImageGrab.grab(all_screens=True)




def diff_ratio(a, b):
    """0=完全相同 1=完全不同（按灰度直方图重叠度估算，快且稳）"""
    if a is None or b is None:
        return 1.0
    ha = a.convert('L').histogram()
    hb = b.convert('L').histogram()
    inter = sum(min(x, y) for x, y in zip(ha, hb))
    total = sum(ha) or 1
    return 1.0 - inter / total


class Worker(threading.Thread):
    def __init__(self, bbox, interval, engine):
        super().__init__(daemon=True)
        self.bbox = bbox
        self.interval = interval
        self.engine = engine
        self.stop = False
        self.last_state = {}
        self.last_parts = None
        self.frames = 0
        self.ocr_runs = 0

    def run(self):
        import spg_ocr
        while not self.stop:
            t0 = time.time()
            try:
                img = grab(self.bbox)
            except Exception as e:
                print('[grab] 失败:', e)
                time.sleep(self.interval)
                continue
            # 只在三块 ROI 变化时跑 OCR
            parts = []
            for k in ('cov', 'hand', 'topbar'):
                parts.append(img.crop((
                    int(img.width * spg_ocr.ROI[k][0]), int(img.height * spg_ocr.ROI[k][1]),
                    int(img.width * spg_ocr.ROI[k][2]), int(img.height * spg_ocr.ROI[k][3]))))
            try:
                changed = (self.last_parts is None or
                           any(diff_ratio(a, b) > 0.004 for a, b in zip(parts, self.last_parts)))
            except Exception:
                changed = True
            if changed or not self.last_state:
                try:
                    st = spg_ocr.analyze(img, self.engine)
                    st['ts'] = time.time()
                    st['frames'] = self.frames
                    st['ocr_runs'] = self.ocr_runs + 1
                    self.ocr_runs += 1
                    # 层数为 0 的多半是没读出来，保留上次非零值
                    old = self.last_state.get('covenants', {}) or {}
                    covs = {}
                    for k, v in (st.get('covenants') or {}).items():
                        covs[k] = v if v else old.get(k, 0)
                    st['covenants'] = covs
                    self.last_state = st
                    with io.open(STATE, 'w', encoding='utf-8') as f:
                        json.dump(st, f, ensure_ascii=False)
                except Exception:
                    traceback.print_exc()
                self.last_parts = parts
            self.frames += 1
            dt = time.time() - t0
            time.sleep(max(0.25, self.interval - dt))


def open_later(port, delay=2.5):
    def _go():
        time.sleep(delay)
        url = 'http://127.0.0.1:%d/%s?live=1' % (port, urllib.parse.quote('卫戍协议-规程-抓牌演算器.html'))
        try: webbrowser.open(url)
        except Exception: pass
    threading.Thread(target=_go, daemon=True).start()


def serve(port, directory, open_after=False):
    import http.server, socketserver

    class H(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=directory, **kw)


        # ---------- 报错反馈 / 下载 ----------
        def _send_json(self, obj):
            body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def _send_html_file(self, fp):
            try:
                body = io.open(fp, 'rb').read()
            except Exception:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def _reports(self):
            out = []
            base = os.path.join(directory, 'records', 'reports')
            if not os.path.isdir(base):
                return out
            for d in sorted(os.listdir(base), reverse=True)[:50]:
                p = os.path.join(base, d)
                if not os.path.isdir(p):
                    continue
                meta = {}
                try:
                    meta = json.load(io.open(os.path.join(p, 'meta.json'), encoding='utf-8'))
                except Exception:
                    pass
                shots = [f for f in os.listdir(p) if f.startswith('shot_')]
                logs = [f for f in os.listdir(p) if f.startswith('log_')]
                out.append({'id': d, 'meta': meta, 'shots': len(shots), 'logs': len(logs),
                            'dir': 'records/reports/' + d})
            return out

        def _files(self):
            out = []
            for f in sorted(os.listdir(directory)):
                if f.lower().endswith('.zip'):
                    p = os.path.join(directory, f)
                    out.append({'name': f, 'size': os.path.getsize(p),
                                'mtime': time.strftime('%m-%d %H:%M', time.localtime(os.path.getmtime(p))),
                                'url': '/' + f})
            return out

        def _save_report(self):
            ln = int(self.headers.get('Content-Length') or 0)
            raw = self.rfile.read(ln)
            data = json.loads(raw.decode('utf-8') or '{}')
            rid = time.strftime('%Y%m%d_%H%M%S')
            base = os.path.join(directory, 'records', 'reports', rid)
            os.makedirs(base, exist_ok=True)
            n = 0
            for i, img in enumerate(data.get('images') or []):
                try:
                    b64 = img.split(',', 1)[-1]
                    with open(os.path.join(base, 'shot_%02d.jpg' % i), 'wb') as f:
                        f.write(base64.b64decode(b64))
                    n += 1
                except Exception:
                    pass
            _logs = data.get('logs') or []
            if isinstance(_logs, str):
                _logs = [_logs]
            for i, lg in enumerate(_logs):
                try:
                    io.open(os.path.join(base, 'log_%02d.txt' % i), 'w', encoding='utf-8').write(str(lg))
                except Exception:
                    pass
            meta = {k: data.get(k) for k in ('name', 'desc', 'version', 'ua')}
            meta['id'] = rid
            meta['time'] = time.strftime('%Y-%m-%d %H:%M:%S')
            meta['shots'] = n
            io.open(os.path.join(base, 'meta.json'), 'w', encoding='utf-8').write(
                json.dumps(meta, ensure_ascii=False, indent=1))
            return {'ok': True, 'id': rid, 'shots': n}

        def do_GET(self):

            if self.path.startswith('/api/reports'):
                self._send_json(self._reports()); return
            if self.path.startswith('/api/files'):
                self._send_json(self._files()); return
            if self.path.startswith('/report'):
                self._send_html_file(os.path.join(directory, '报错反馈.html')); return

            if self.path.startswith('/api/plan'):
                from urllib.parse import urlparse, parse_qs
                # keep_blank_values=True 否则 ?set= （空的=自动识别）会被丢掉，切不回自动
                q = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                val = (q.get('set', [''])[0] or '').strip()
                path = os.path.join(directory, 'live_plan.json')
                keys = []
                try:
                    import spg_plan
                    keys = list(spg_plan.PLAY)
                except Exception:
                    keys = []
                if 'set' in q:
                    if val in keys:
                        try:
                            with io.open(path, 'w', encoding='utf-8') as f:
                                json.dump({'plan': val}, f, ensure_ascii=False)
                        except Exception:
                            pass
                    elif val in ('', 'auto'):
                        try:
                            if os.path.exists(path):
                                os.remove(path)
                        except Exception:
                            pass
                cur = ''
                info = None
                try:
                    cur = (json.load(io.open(path, encoding='utf-8')) or {}).get('plan') or ''
                except Exception:
                    cur = ''
                if cur:
                    try:
                        import spg_plan
                        d = spg_plan.PLAY.get(cur) or {}
                        info = {
                            'title': d.get('title') or cur,
                            'strategy': d.get('strategy') or [],
                            'leveling': d.get('leveling') or '',
                            'core': d.get('core') or [],
                            'priority': d.get('priority') or [],
                            'equipment': (d.get('equipment') or [])[:8],
                            'notes': (d.get('notes') or [])[:3],
                            'targets': d.get('targets') or '',
                        }
                    except Exception:
                        info = None
                body = json.dumps({'plan': cur, 'keys': keys, 'info': info}, ensure_ascii=False).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if self.path.startswith('/api/goal'):
                from urllib.parse import urlparse, parse_qs
                q = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                path = os.path.join(directory, 'live_goal.json')
                keys = []
                try:
                    import spg_goal
                    keys = [k for k in spg_goal.engines() if not k.startswith('_')]
                except Exception:
                    keys = []
                if 'clear' in q:
                    try:
                        if os.path.exists(path):
                            os.remove(path)
                    except Exception:
                        pass
                elif 'set' in q:
                    cov = (q.get('cov', [''])[0] or '').strip()
                    try:
                        target = int(q.get('target', ['0'])[0] or 0)
                    except Exception:
                        target = 0
                    if cov and target > 0:
                        try:
                            with io.open(path, 'w', encoding='utf-8') as f:
                                json.dump({'cov': cov, 'target': target}, f, ensure_ascii=False)
                        except Exception:
                            pass
                cov, target = '', 0
                try:
                    d = json.load(io.open(path, encoding='utf-8')) or {}
                    cov = str(d.get('cov') or '')
                    target = int(d.get('target') or 0)
                except Exception:
                    pass
                # 当前层数顺手从 live_state 取一份，面板设完立刻能看到进度
                now = 0
                try:
                    st0 = json.load(io.open(os.path.join(directory, 'live_state.json'),
                                            encoding='utf-8')) or {}
                    now = int((st0.get('covenants') or {}).get(cov) or 0)
                except Exception:
                    now = 0
                body = json.dumps({'cov': cov, 'target': target, 'current': now, 'keys': keys},
                                  ensure_ascii=False).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if self.path.startswith('/api/mode'):
                from urllib.parse import urlparse, parse_qs
                # keep_blank_values=True 否则 ?set= （空的=自动识别）会被丢掉，切不回自动
                q = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                val = (q.get('set', [''])[0] or '').strip()
                path = os.path.join(directory, 'live_hud_mode.txt')
                if val in ('live', 'board'):
                    try:
                        with io.open(path, 'w', encoding='utf-8') as f:
                            f.write(val)
                    except Exception:
                        pass
                cur = 'live'
                try:
                    cur = io.open(path, encoding='utf-8').read().strip() or 'live'
                except Exception:
                    pass
                body = ('{"mode":"%s"}' % cur).encode()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            super().do_GET()

        def do_POST(self):
            if self.path.startswith('/api/report'):
                try:
                    self._send_json(self._save_report())
                except Exception as e:
                    self._send_json({'ok': False, 'err': str(e)})
                return
            self.send_error(404)


        def end_headers(self):
            self.send_header('Cache-Control', 'no-store')
            super().end_headers()

        def log_message(self, *a):
            pass

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(('127.0.0.1', port), H) as httpd:
        print(f'[http] http://127.0.0.1:{port}/卫戍协议-规程-抓牌演算器.html')
        if open_after:
            open_later(port, 0.4)
        httpd.serve_forever()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--window', action='store_true')
    ap.add_argument('--bbox', default=None, help='x1,y1,x2,y2')
    ap.add_argument('--port', type=int, default=8765)
    ap.add_argument('--interval', type=float, default=1.5)
    ap.add_argument('--no-serve', action='store_true')
    ap.add_argument('--open', action='store_true')
    a = ap.parse_args()

    bbox = None
    if a.bbox:
        bbox = tuple(int(x) for x in a.bbox.split(','))
    elif a.window:
        bbox = find_window()

    print('[init] 加载 OCR 引擎…')
    from spg_ocr import Engine
    eng = Engine()
    print('[init] 就绪')

    w = Worker(bbox, a.interval, eng)
    w.start()
    if not a.no_serve:
        try:
            serve(a.port, ROOT, open_after=a.open)
        except KeyboardInterrupt:
            pass
    else:
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
