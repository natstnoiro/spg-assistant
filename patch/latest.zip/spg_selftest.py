# -*- coding: utf-8 -*-
"""自检：地图识别 / 快速识别 / 打法锁定 / 站位规划

用法：run.cmd spg_selftest.py
不依赖游戏窗口，用 shots/ 里的实拍图当固定样本。
"""
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from PIL import Image

import spg_board
import spg_fast
import spg_map
import spg_ocr
import spg_open
import spg_plan
import spg_score

FAIL = []


def check(name, cond, detail=''):
    print(('  ✅ ' if cond else '  ❌ ') + name + (('  ' + str(detail)) if detail else ''))
    if not cond:
        FAIL.append(name)


def main():
    eng = spg_ocr.Engine()
    eng.warmup()
    rec = spg_map.Recognizer()

    print('[1] 地图识别')
    for name in ('board1.png', 'collapsed.png'):
        p = os.path.join(HERE, 'shots', name)
        if not os.path.exists(p):
            continue
        m = rec.match(Image.open(p))
        check(name + ' 认出 m06', bool(m) and m['id'] == 'm06', m and (m['camera'], m['score'], m['margin']))

    print('[2] 快速识别')
    for name, want in (('board1.png', ['坚守盾牌', '摆渡人']), ('collapsed.png', [])):
        p = os.path.join(HERE, 'shots', name)
        if not os.path.exists(p):
            continue
        st = spg_fast.read_fast(Image.open(p).convert('RGB'), eng, {}, {})
        names = [h['name'] for h in st['hand']]
        check(name + ' 手牌', names == want, names)
        check(name + ' 回合=1', st['round'] == 1, st['round'])
        check(name + ' 血量=28', st['life'] == 28, st['life'])
        check(name + ' 资金=0', st['gold'] == 0, st['gold'])

    print('[3] 打法锁定')
    cases = [
        (['暴躁铁皮', '云迹'], '卡西米尔·不屈'),
        (['砾', '瑕光'], '卡西米尔·突袭'),
        (['黑键', '复奏'], '莱塔尼亚'),
        (['蓝毒', '旅骨'], '伊比利亚·蓝毒'),
    ]
    for hand, want in cases:
        key, plan = spg_plan.plan_for(hand, None)
        check(' '.join(hand) + ' -> ' + want, key == want, key)
        if plan:
            recs = spg_score.recommend(hand, {}, {}, 5, plan=plan)
            check('  推荐有序且带核心标记', bool(recs) and any('核心' in r['flags'] for r in recs),
                  [(r['name'], round(r['score']), r['flags'][:2]) for r in recs])

    print('[4] 站位规划')
    up = spg_board._load_upstream()
    for mid, ops in (('m06', ['摆渡人', '灰喉', '杰西卡']), ('m01', ['摆渡人'])):
        pl, _ = spg_board.plan(ops, mid)
        check(mid + ' 有结果', bool(pl), pl)
        code = spg_board.UPSTREAM.get(mid)
        entry = next((m for m in up['maps'] if m['id'] == code), None)
        cells = entry['cells'] if entry else []
        first = up.get('columns', [-2, 9])[0]
        ok = True
        used = set()
        for n, r, c, d in pl:
            i = c - first
            t = cells[r][i] if 0 <= r < len(cells) and 0 <= i < len(cells[r]) else '?'
            if t not in ('G', 'T', 'H') or (r, c) in used:
                ok = False
            used.add((r, c))
        check(mid + ' 只落在可站格且不重复', ok, [(n, r, c, d) for n, r, c, d in pl])

    print('\n[5] 打法装备加权')
    import spg_equip
    key, plan = spg_plan.plan_for(['暴躁铁皮'], None)
    eqs = spg_plan.equipment_priority(plan)
    check('装备黑话已转官方名', '谢拉格不融冰' in eqs, eqs[:3])
    pick = eqs[:1]
    recs = spg_equip.recommend(pick + ['不存在的装备'], '卡西米尔', ['暴躁铁皮'], plan=plan)
    check('打法装备被加分/指向核心', bool(recs) and '打法装备' in recs[0]['why'] and recs[0]['target'] == '暴躁铁皮',
          recs)

    print('\n[6] 目标层数模型')
    import spg_goal
    a = spg_goal.simulate('伊比利亚', {3: 4, 6: 4, 8: 12, 10: 20, 12: 24})[-1]['total']
    check('常规节奏 ≈404', 395 <= a <= 415, a)
    ev = spg_goal.evaluate('伊比利亚', 300, current=120, round_now=6,
                           owned=['旅骨', '深靛', '流明'])
    check('evaluate 可行判定', ev['achievable'] is True and ev['projected'] == 340,
          (ev['projected'], ev['achievable']))
    check('缺核心列得出', '棘刺' in ev['missing'], ev['missing'])
    line = spg_goal.brief(ev)
    check('brief 单行含目标', '\n' not in line and '目标伊比利亚' in line, line)
    got = spg_goal.parse_goal({'cov': '伊比利亚', 'target': '300'})
    check('parse_goal 规范数字', got == ('伊比利亚', 300, []), got)
    check('parse_goal 拒绝无效', spg_goal.parse_goal({'cov': '', 'target': 1}) is None
          and spg_goal.parse_goal({'cov': '伊比利亚', 'target': 0}) is None)
    check('无产出数据不瞎报',
          (not spg_goal.has_model('远见'))
          and '暂无叠层' in spg_goal.brief(spg_goal.evaluate('远见', 200, current=10, round_now=3)))

    print('\n[7] 盟约全览 ban 识别')
    p = os.path.join(HERE, 'shots', 'panel_ban.png')
    if os.path.exists(p):
        rp = spg_open.read_full_panel(Image.open(p).convert('RGB'), eng)
        check('核心可用 5 个', bool(rp) and sorted(rp['core_on']) ==
              sorted(['炎', '阿戈尔', '叙拉古', '卡西米尔', '伊比利亚']),
              rp and rp['core_on'])
        check('核心 ban 5 个', bool(rp) and sorted(rp['core_off']) ==
              sorted(['萨尔贡', '维多利亚', '谢拉格', '乌萨斯', '莱塔尼亚']),
              rp and rp['core_off'])
        check('附加 ban 5 个', bool(rp) and sorted(rp['addons_off']) ==
              sorted(['迅捷', '灵巧', '助力', '远见', '突袭']), rp and rp['addons_off'])
        check('附加可用 11 个', bool(rp) and len(rp['addons_on']) == 11, rp and len(rp['addons_on']))

    print('\n结果：' + ('全部通过' if not FAIL else '失败 %d 项: %s' % (len(FAIL), ', '.join(FAIL))))
    return 0 if not FAIL else 1


if __name__ == '__main__':
    sys.exit(main())
