# -*- coding: utf-8 -*-
"""补丁机制：让 exe 能在不重新打包的情况下更新代码/数据/网页

约定：
- 补丁解压在 exe 同级的 `_patch/` 目录，结构：
    _patch/version.txt        补丁版本号（比如 v26）
    _patch/*.py               被替换的源码模块
    _patch/*.html             被替换的网页
    _patch/data/*.json        被替换的数据
    _patch/data/cov_icons/*   图标模板
- 启动时（frozen）：
    · 把 `_patch/data/**` 覆盖到 `_internal/data/**`（数据走文件，不影响 import）
    · 把 `_patch/*.html` 复制到 exe 同级（HTTP 服务根目录）
    · sys.path 最前面插入 `_patch`，让补丁里的 .py 优先于打包内的模块
"""
import io
import os
import shutil
import sys


def _exe_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def patch_dir():
    return os.path.join(_exe_dir(), '_patch')


def patch_version():
    try:
        return io.open(os.path.join(patch_dir(), 'version.txt'), encoding='utf-8').read().strip()
    except Exception:
        return ''


def _applied_path():
    return os.path.join(_exe_dir(), '_patch_applied.txt')


def _apply_files():
    """把补丁里的数据/网页覆盖过去（.py 不需要复制，靠 sys.path 优先）"""
    d = patch_dir()
    if not os.path.isdir(d):
        return
    base = _exe_dir()
    internal = os.path.join(base, '_internal')
    # 数据
    src_data = os.path.join(d, 'data')
    if os.path.isdir(src_data):
        for root, _dirs, files in os.walk(src_data):
            rel = os.path.relpath(root, d)
            for tgt_base in (os.path.join(internal, rel), os.path.join(base, rel)):
                try:
                    os.makedirs(tgt_base, exist_ok=True)
                except Exception:
                    continue
            for f in files:
                for tgt_base in (os.path.join(internal, rel), os.path.join(base, rel)):
                    try:
                        shutil.copy2(os.path.join(root, f), os.path.join(tgt_base, f))
                    except Exception:
                        pass
    # 网页
    for f in os.listdir(d):
        if f.lower().endswith('.html'):
            try:
                shutil.copy2(os.path.join(d, f), os.path.join(base, f))
            except Exception:
                pass


def apply_on_startup():
    """启动时调用：应用补丁 + 让补丁模块优先加载"""
    d = patch_dir()
    if not os.path.isdir(d):
        return
    ver = patch_version()
    try:
        applied = io.open(_applied_path(), encoding='utf-8').read().strip()
    except Exception:
        applied = ''
    if ver and ver != applied:
        _apply_files()
        try:
            io.open(_applied_path(), 'w', encoding='utf-8').write(ver)
        except Exception:
            pass
        print('[patch] 已应用补丁 %s' % ver)
    if d not in sys.path:
        sys.path.insert(0, d)


if __name__ == '__main__':
    print('patch_dir:', patch_dir())
    print('version:', patch_version() or '(无)')
    apply_on_startup()
