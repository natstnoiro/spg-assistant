# -*- coding: utf-8 -*-
"""悬停浮层：干员显示精锐变化；装备显示进阶（基础→进阶）变化"""
import io
import json, os, re

import tkinter as tk
from tkinter import font as tkfont

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, 'data')
OPS = {o['name']: o for o in json.load(io.open(os.path.join(D, 'ops_full.json'), encoding='utf-8'))}
EQ = {e['name']: e for e in json.load(io.open(os.path.join(D, 'equipment.json'), encoding='utf-8'))}
_COMBO = {}
try:
    _COMBO = json.load(io.open(os.path.join(D, 'item_combo.json'), encoding='utf-8'))
except Exception:
    _COMBO = {}
_COVE = {}
try:
    for c in json.load(io.open(os.path.join(D, 'covenants.json'), encoding='utf-8')):
        _COVE[c['name']] = c
except Exception:
    _COVE = {}


def _clean(s):
    return re.sub(r'\s+', ' ', (s or '')).strip()


def template_diff(t1, t2):
    """文字骨架相同、只有数字变化时，逐个数字标 a→b"""
    a = re.split(r'(\d+)', _clean(t1))
    b = re.split(r'(\d+)', _clean(t2))
    if len(a) != len(b):
        return None
    for i in range(0, len(a), 2):
        if a[i] != b[i]:
            return None
    out, changed = [], 0
    for i in range(len(a)):
        if i % 2 == 1 and a[i] != b[i]:
            out.append(f'【{a[i]}→{b[i]}】')
            changed += 1
        else:
            out.append(a[i])
    return ''.join(out) if changed else None


def _op_text(o, active=None):
    covs = '、'.join(o.get('covs') or [])
    head = f"{o['name']}  {o.get('tier','')}阶 · {covs}"
    t1, t2 = _clean(o.get('t1')), _clean(o.get('t2'))
    if not t1 and not t2:
        return head + _cov_lines(o, active)
    if t1 == t2:
        return f"{head}\n精锐：无变化\n{t1}" + _cov_lines(o, active)
    d = template_diff(t1, t2)
    if d:
        body = f"{head}\n精锐变化：{d}"
    else:
        body = f"{head}\n精锐前：{t1}\n精锐后：{t2}"
    return body + _cov_lines(o, active)


def _eq_text(e):
    name = e['name']
    head = f"{name}  {e.get('tier','')}阶 · {e.get('price','')}金"
    eff = _clean(e.get('effect'))
    cmb = _COMBO.get(name)
    tail = ''
    if cmb:
        tail = f"\n组合：与「{cmb.get('partner')}」同时持有 → 「{cmb.get('result')}」"
    if '【基础&进阶】' in eff:
        return f"{head}\n基础与进阶相同：{eff.replace('【基础&进阶】', '')}" + tail
    m = re.search(r'【基础】(.*?)【进阶】(.*)$', eff)
    if not m:
        return f"{head}\n{eff}" + tail
    a, b = m.group(1).strip(), m.group(2).strip()
    if a == b:
        return f"{head}\n进阶：无变化\n{a}" + tail
    d = template_diff(a, b)
    if d:
        return f"{head}\n进阶变化：{d}" + tail
    return f"{head}\n基础：{a}\n进阶：{b}" + tail


def _cov_lines(o, active=None):
    """没激活的盟约把效果直接贴出来（省得买了才知道）"""
    out = []
    act = set(active or [])
    for c in (o.get('covs') or [])[:2]:
        info = _COVE.get(c)
        if not info:
            continue
        eff = _clean(info.get('effect'))
        tag = '已激活' if c in act else '未激活'
        out.append(f"\n【{c}】{tag}·需{info.get('need', 3)}人：{eff[:220]}")
    return ''.join(out)


def text_for(name, active=None):
    if name in OPS:
        return _op_text(OPS[name], active)
    if name in EQ:
        return _eq_text(EQ[name])
    return None


class InfoWindow:
    def __init__(self, root):
        self.win = tk.Toplevel(root)
        self.win.overrideredirect(True)
        self.win.attributes('-topmost', True)
        self.win.configure(bg='#0d1a16')
        try:
            self.win.attributes('-alpha', 0.95)
        except Exception:
            pass
        self.f = tkfont.Font(family='Microsoft YaHei', size=11)
        self.lbl = tk.Label(self.win, text='', bg='#0d1a16', fg='#d8f5ec',
                            font=self.f, justify='left', anchor='nw', padx=10, pady=8,
                            wraplength=520)
        self.lbl.pack()
        self.win.withdraw()
        self.cur = None
        self._passthrough()

    def _passthrough(self):
        """鼠标穿透：提示窗不该挡住下面的卡牌点击/悬停"""
        try:
            import ctypes
            self.win.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.win.winfo_id())
            GWL_EXSTYLE = -20
            WS_EX_LAYERED = 0x80000
            WS_EX_TRANSPARENT = 0x20
            WS_EX_TOOLWINDOW = 0x80
            ex = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            ctypes.windll.user32.SetWindowLongW(
                hwnd, GWL_EXSTYLE, ex | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW)
        except Exception:
            pass

    def show(self, text, x, y):
        if text == self.cur and self.win.state() != 'withdrawn':
            return
        self.cur = text
        self.lbl.config(text=text)
        self.win.update_idletasks()
        w = min(560, self.lbl.winfo_reqwidth() + 20)
        h = self.lbl.winfo_reqheight() + 16
        self.win.geometry(f'{w}x{h}+{int(x)}+{int(y)}')
        self.win.deiconify()
        self.win.lift()
        self._passthrough()

    def hide(self):
        if self.cur is not None:
            self.cur = None
            self.win.withdraw()
