# -*- coding: utf-8 -*-
"""策略适配 / 保活模式

用户规则：
1. 判断完策略后，按「当前盟约叠层」推荐（不预设死打法）
2. 如果**连续 3~4 个回合**店里都没有「策略适配的干员牌」→ 立刻切「保活打法」
   （买 坚守/聚合/迅捷/不屈 的便宜卡，先别死，别再为找本家牌刷钱）
3. 尽可能在**第 8 回合左右**转回「策略适合的主盟约叠层」

状态机放在 state['_adapt'] 里：
    {'target': '谢拉格', 'streak': 3, 'mode': 'survive', 'last_round': 7, 'note': '...'}
"""
import os

# 保活用小盟约（3 人即可开，便宜）
SURVIVE_COVS = ['坚守', '聚合', '迅捷', '不屈']
SURVIVE_TURNS = 3          # 连续几回合没本家牌就转保活
SWITCH_BACK_ROUND = 8      # 最晚第 8 回合尝试转回主盟约

# 保活期的便宜关键卡（低阶、能立刻开盟约）
SURVIVE_CARDS = {
    '坚守': ['角峰', '摆渡人', '泡泡', '蛇屠箱'],
    '聚合': ['褐果', '波登可', '瑰盐', '莎草'],
    '迅捷': ['陨星', '波登可', '青枳'],
    '不屈': ['折桠', '摆渡人', '砾', '宴'],
}


def _get(state):
    return state.setdefault('_adapt', {'target': '', 'streak': 0, 'mode': 'normal',
                                       'last_round': 0, 'note': ''})


def matches_target(card_covs, target):
    """这张牌能不能服务目标盟约"""
    return bool(target) and (target in (card_covs or []))


def observe(state, round_no, shop_cards, target):
    """每回合更新一次：shop_cards = [(名字, [盟约...]), ...]"""
    st = _get(state)
    st['target'] = target or st.get('target') or ''
    if not round_no or round_no == st.get('last_round'):
        return st
    st['last_round'] = round_no
    hit = any(matches_target(covs, st['target']) for _n, covs in (shop_cards or []))
    if hit:
        st['streak'] = 0
        if st.get('mode') == 'survive':
            st['mode'] = 'normal'
            st['note'] = '拿到本家牌，回正常模式'
    else:
        st['streak'] = int(st.get('streak') or 0) + 1
        if st['streak'] >= SURVIVE_TURNS and st.get('mode') != 'survive':
            st['mode'] = 'survive'
            st['note'] = '连续 %d 回合没本家牌 → 转保活' % st['streak']
    return st


def is_survive(state):
    return _get(state).get('mode') == 'survive'


def filter_cards(state, recs):
    """保活模式下，只留能开保活盟约的牌（按保活优先级排序）"""
    st = _get(state)
    if st.get('mode') != 'survive':
        return recs
    order = {c: i for i, c in enumerate(SURVIVE_COVS)}
    out = []
    for r in recs:
        covs = r.get('covs') or []
        best = min((order.get(c, 9) for c in covs), default=9)
        if best < 9:
            r = dict(r)
            r['score'] = r['score'] + (30 - best * 6)   # 保活期给保活盟约加权
            r.setdefault('flags', []).append('保活')
            out.append((best, r))
    out.sort(key=lambda x: (x[0], -x[1]['score']))
    return [r for _b, r in out]


def status_line(state, round_no, target):
    """HUD 用的一行提示"""
    st = _get(state)
    mode = st.get('mode')
    streak = st.get('streak') or 0
    if mode == 'survive':
        tip = '🛟 保活模式：连续 %d 回合没「%s」牌' % (streak, target or '本家')
        if round_no and round_no >= SWITCH_BACK_ROUND:
            tip += '｜R%d 必须开始转回 %s（先开 坚守+聚合 兜底）' % (round_no, target or '主盟约')
        else:
            tip += '｜先买 坚守/聚合 便宜卡，别刷钱'
        return tip
    if streak:
        return '⚠ 已 %d/3 回合没「%s」牌，再断 1 回合就转保活' % (streak, target or '本家')
    return ''


if __name__ == '__main__':
    s = {}
    shop_hit = [('雪猎', ['谢拉格', '精准'])]
    shop_miss = [('褐果', ['聚合']), ('摆渡人', ['坚守', '不屈'])]
    for r in range(1, 8):
        cards = shop_hit if r == 1 else shop_miss
        st = observe(s, r, cards, '谢拉格')
        print('R%d' % r, st['mode'], 'streak=%d' % st['streak'], '|', status_line(s, r, '谢拉格'))
    print('\n保活过滤示例:')
    recs = [{'name': '雪猎', 'score': 40, 'covs': ['谢拉格', '精准']},
            {'name': '褐果', 'score': 20, 'covs': ['聚合']},
            {'name': '摆渡人', 'score': 18, 'covs': ['坚守', '不屈']},
            {'name': '灰喉', 'score': 30, 'covs': ['精准']}]
    for r in filter_cards(s, recs):
        print('  ', r['name'], round(r['score'], 1), r.get('flags'))
