# -*- coding: utf-8 -*-
"""资金识别：右下角「金色菱形 + 数字」小胶囊

数字是空心黄字，OCR 容易把 0 认成 O/8，所以对单个数字再用「孔洞数」纠正：
空心 0 = 1 个封闭孔，8 = 2 个。
"""
import os
import re

import numpy as np

import spg_img
from PIL import Image

REC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'records')

# 资金胶囊（相对整帧，右下角、手牌上方）
PILL_BOX = (0.850, 0.680, 1.000, 0.782)
# 金条掩膜兜底区域
BAR_BOX = (0.780, 0.620, 1.000, 0.950)

_RE_DIGITS = re.compile(r'^[0-9OoQD]+$')
_MAP = {'O': '0', 'o': '0', 'Q': '0', 'D': '0'}


def gold_mask(a):
    r, g, b = a[:, :, 0].astype(np.int16), a[:, :, 1].astype(np.int16), a[:, :, 2].astype(np.int16)
    return ((r > 140) & (g > 100) & (b < 120) & (r - b > 50)).astype(np.uint8)


def _holes(sub):
    """封闭孔洞数（0 字形 = 1，8 = 2）"""
    return spg_img.count_holes(np.asarray(sub).astype(np.uint8))


def _digit_text(im, eng):
    """返回资金数字（int）或 None"""
    W, H = im.size
    c = im.crop((int(W * PILL_BOX[0]), int(H * PILL_BOX[1]),
                 int(W * PILL_BOX[2]), int(H * PILL_BOX[3])))
    inv = Image.fromarray(255 - np.asarray(c.convert('L')))
    its = eng.run(inv, scale=4, pre='none')
    cands = [it for it in its if _RE_DIGITS.match(it['text'] or '')]
    if not cands:
        return None
    it = max(cands, key=lambda d: d['cx'])
    txt = ''.join(_MAP.get(ch, ch) for ch in it['text'])
    if len(txt) == 1 and txt in ('0', '8'):
        m = gold_mask(np.asarray(c))
        x0 = max(0, int(it['x']) - 1)
        y0 = max(0, int(it['y']) - 1)
        x1 = min(m.shape[1], int(it['x'] + it['w']) + 2)
        y1 = min(m.shape[0], int(it['y'] + it['h']) + 2)
        hh = _holes(m[y0:y1, x0:x1])
        if hh >= 2:
            txt = '8'
        elif hh == 1:
            txt = '0'
    return int(txt) if txt.isdigit() else None


def read_gold(im, eng):
    try:
        v = _digit_text(im, eng)
        if v is not None:
            return v
    except Exception:
        pass
    return _read_bar(im, eng)


def _read_bar(im, eng):
    """兜底：金色长条（旧版 UI）掩膜后取最大连通块 OCR"""
    try:
        W, H = im.size
        box = (int(W * BAR_BOX[0]), int(H * BAR_BOX[1]), int(W * BAR_BOX[2]), int(H * BAR_BOX[3]))
        c = im.crop(box)
        m = gold_mask(np.asarray(c))
        if m.sum() < 200:
            return None
        bb = spg_img.largest_box(m)
        if not bb:
            return None
        x, y, w, h = bb
        pad = 6
        sub = c.crop((max(0, x - pad), max(0, y - pad),
                      min(c.width, x + w + pad), min(c.height, y + h + pad)))
        its = eng.run(Image.fromarray(255 - np.asarray(sub.convert('L'))), scale=4, pre='none')
        cands = [it for it in its if _RE_DIGITS.match(it['text'] or '')]
        if not cands:
            return None
        txt = ''.join(_MAP.get(ch, ch) for ch in max(cands, key=lambda d: d['cx'])['text'])
        return int(txt) if txt.isdigit() else None
    except Exception:
        return None
