# -*- coding: utf-8 -*-
"""独立可拖动 HUD 小窗（单独进程，保证在最上层且能拖动）

读取 live_hud.txt 显示；位置记在 live_hud_pos.json。
"""
import io, json, os, tkinter as tk
from tkinter import font as tkfont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
import sys as _sys
_FROZEN = bool(getattr(_sys, 'frozen', False))
_W = os.environ.get('SPG_DATA') or (_sys._MEIPASS if _FROZEN else ROOT)
HUD_TXT = os.path.join(_W, 'live_hud.txt')
MODE_FILE = os.path.join(_W, 'live_hud_mode.txt')
HUD_POS = os.path.join(_W, 'live_hud_pos.json')
PID_FILE = os.path.join(_W, 'live_hud.pid')


def _alive(pid):
    try:
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
    except Exception:
        pass
    return False


def _singleton():
    try:
        if os.path.exists(PID_FILE):
            old = int(io.open(PID_FILE).read().strip() or 0)
            if old and old != os.getpid() and _alive(old):
                return False
    except Exception:
        pass
    try:
        with io.open(PID_FILE, 'w') as f:
            f.write(str(os.getpid()))
    except Exception:
        pass
    return True


class Hud:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        self.root.configure(bg='#0b1512')
        try:
            self.root.attributes('-alpha', 0.9)
        except Exception:
            pass
        self.f = tkfont.Font(family='Microsoft YaHei', size=14, weight='bold')
        self.lbl = tk.Label(self.root, text='卫戍协议助手 · 拖动我', bg='#0b1512',
                            fg='#2ee6b0', font=self.f, justify='left', anchor='w',
                            padx=12, pady=8, wraplength=980)
        self.lbl.pack(fill='both', expand=True)
        x, y = self._load_pos()
        self.root.geometry(f'620x110+{x}+{y}')
        self._d = {'x': 0, 'y': 0}
        for w in (self.root, self.lbl):
            w.bind('<Button-1>', self._down)
            w.bind('<B1-Motion>', self._move)
            w.bind('<ButtonRelease-1>', self._toggle)
        self._last = None
        self.root.after(200, self._tick)

    def _load_pos(self):
        try:
            d = json.load(io.open(HUD_POS, encoding='utf-8'))
            return int(d['x']), int(d['y'])
        except Exception:
            return 60, 60

    def _save_pos(self):
        try:
            with io.open(HUD_POS, 'w', encoding='utf-8') as f:
                json.dump({'x': self.root.winfo_x(), 'y': self.root.winfo_y()}, f)
        except Exception:
            pass

    def _toggle(self, e):
        try:
            cur = 'live'
            if os.path.exists(MODE_FILE):
                cur = io.open(MODE_FILE, encoding='utf-8').read().strip() or 'live'
            nxt = 'board' if cur != 'board' else 'live'
            with io.open(MODE_FILE, 'w', encoding='utf-8') as f:
                f.write(nxt)
            self._last = None
        except Exception:
            pass

    def _down(self, e):
        self._d['x'] = e.x_root - self.root.winfo_x()
        self._d['y'] = e.y_root - self.root.winfo_y()

    def _move(self, e):
        self.root.geometry(f'+{e.x_root - self._d["x"]}+{e.y_root - self._d["y"]}')

    _dead_cnt = 0

    def _parent_alive(self):
        pid = 0
        for i, a in enumerate(_sys.argv):
            if a == '--parent' and i + 1 < len(_sys.argv):
                try:
                    pid = int(_sys.argv[i + 1])
                except Exception:
                    pid = 0
        if not pid:
            return True
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        except Exception:
            return True

    def _tick(self):
        if self._parent_alive():
            self._dead_cnt = 0
        else:
            self._dead_cnt += 1
        if not self._parent_alive() and self._dead_cnt >= 3:
            try:
                self.root.destroy()
            except Exception:
                pass
            import os as _os
            _os._exit(0)
        try:
            t = io.open(HUD_TXT, encoding='utf-8').read().strip()
            if t and t != self._last:
                self.lbl.config(text=t)
                self._last = t
                # 按内容自适应大小（保持左上角不动）
                self.root.update_idletasks()
                w = min(1020, self.lbl.winfo_reqwidth() + 8)
                h = self.lbl.winfo_reqheight() + 4
                self.root.geometry(f'{w}x{h}+{self.root.winfo_x()}+{self.root.winfo_y()}')
        except Exception:
            pass
        self.root.after(400, self._tick)

    def run(self):
        self.root.protocol('WM_DELETE_WINDOW', lambda: (self._save_pos(), self.root.destroy()))
        self.root.mainloop()


if __name__ == '__main__':
    if _singleton():
        Hud().run()
