# -*- coding: utf-8 -*-
"""统一的路径解析：所有模块从这里取根目录，禁止各自再算 dirname(dirname(...))

三套语义（与原 spg.py 逻辑一致）：
- HERE          本模块所在目录 = 源码运行时 research/live；打包后 _internal（资源只读）
- ROOT          运行时根目录：runs.json / records / live_state.json / html 都在这里
                取 SPG_ROOT 环境变量 → 打包时 _MEIPASS → 源码时 workspace 根
                （spg_main.exe 入口在打包时把 SPG_ROOT/SPG_DATA 都设成 exe 同级目录）
- WRITABLE      可写目录（HUD 文件、pid、调试 dump）= SPG_DATA → ROOT

模块相邻的 data/ 一律用 os.path.join(HERE, 'data')（打包后跟着模块走 _internal）。
"""
import io
import json
import os
import sys

IS_FROZEN = bool(getattr(sys, 'frozen', False))
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.environ.get('SPG_ROOT') or (getattr(sys, '_MEIPASS', None) if IS_FROZEN
                                      else os.path.dirname(os.path.dirname(HERE)))
WRITABLE = os.environ.get('SPG_DATA') or ROOT


def load_json(path, default=None):
    """读 json：失败返回 default（不抛异常）。各模块原来的 try/json.load/except 模式统一到这"""
    try:
        with io.open(path, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def load_json_cached(path, default=None):
    """按 mtime 缓存的 load_json：给「每帧都读、内容很少变」的文件用
    （op_side.json / live_plan.json / economy.json 这类）"""
    try:
        m = os.path.getmtime(path)
    except OSError:
        return default
    c = _CACHE.get(path)
    if c and c[0] == m:
        return c[1]
    v = load_json(path, default)
    try:
        _CACHE[path] = (m, v)
    except Exception:
        pass
    return v


_CACHE = {}
