# -*- coding: utf-8 -*-
"""全自动打：读状态 → 决策 → 点击（先只做「休整期 → 准备就绪」，其余按开关解锁）

用法：
    run.cmd spg_auto.py --dry            # 只打印打算点什么，不点
    run.cmd spg_auto.py --steps 1        # 只执行 1 个动作，然后停
    run.cmd spg_auto.py                  # 一直打（F12 急停）

安全：只在游戏窗口前台时点；F12 / 生成本目录上级的 spg_auto_stop 文件可停。
"""
import argparse
import ctypes
import io
import json
import os
import sys
import time
from ctypes import wintypes

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from PIL import ImageGrab

import spg_fast
import spg_grab
import spg_input
import spg_ocr
import spg_score

# ---- 归一化坐标（1920x1080 标定）----
BTN_READY = (0.917, 0.153)
BTN_REFRESH = (0.845, 0.625)
BTN_FREEZE = (0.730, 0.625)
BTN_UPGRADE = (0.265, 0.930)
CARD_CENTERS = (775, 1020, 1265, 1510, 1755)
CARD_Y = 0.840
READY_BOX = (0.870, 0.120, 0.980, 0.195)


LOG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '_auto.log')


def log(*a):
    line = time.strftime('[%H:%M:%S] ') + ' '.join(str(x) for x in a)
    print(line, flush=True)
    try:
        with io.open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry', action='store_true')
    ap.add_argument('--steps', type=int, default=0)
    ap.add_argument('--interval', type=float, default=0.6)
    ap.add_argument('--buy', action='store_true', help='允许买卡')
    ap.add_argument('--refresh', type=float, default=0, help='留多少金时刷新（0=不刷）')
    a = ap.parse_args()

    spg_input.dpi_aware()
    log('管理员权限:', is_admin())
    win = spg_grab.find_hwnd()
    if not win:
        log('没找到游戏窗口')
        return 1
    hwnd = win[0]
    cr = wintypes.RECT()
    ctypes.windll.user32.GetClientRect(hwnd, ctypes.byref(cr))
    pt = wintypes.POINT(0, 0)
    ctypes.windll.user32.ClientToScreen(hwnd, ctypes.byref(pt))
    bbox = (pt.x, pt.y, pt.x + cr.right, pt.y + cr.bottom)
    W, H = cr.right, cr.bottom
    log('窗口', bbox, W, 'x', H)

    eng = spg_ocr.Engine()
    eng.warmup()
    log('识别就绪')

    actions = 0
    last_ready = 0.0
    shot_dir = os.path.join(HERE, 'shots')
    while True:
        if spg_input.stop_requested(hwnd):
            log('停止（F12/切窗/标记文件）')
            break
        img = ImageGrab.grab(bbox=bbox, all_screens=True)
        st = spg_fast.read_fast(img.convert('RGB'), eng, {}, {})
        ready_txt, _ = spg_fast._rec(eng, spg_fast._crop(img, READY_BOX), 3)
        in_rest = ('准备' in (ready_txt or '')) and ('就' in (ready_txt or ''))
        log('R%s 金%s 血%s 手牌%s | 休整期=%s' % (
            st.get('round'), st.get('gold'), st.get('life'),
            [h['name'] for h in st.get('hand') or []], in_rest))

        if in_rest and time.time() - last_ready > 3.0:
            if a.dry:
                log('  → 打算点「准备就绪」', BTN_READY)
                last_ready = time.time()
            else:
                ok = spg_input.click_client(hwnd, int(W * BTN_READY[0]), int(H * BTN_READY[1]))
                log('  → 点「准备就绪」', 'ok' if ok else '窗口不在前台，跳过')
                if ok:
                    actions += 1
                    last_ready = time.time()
                    img.save(os.path.join(shot_dir, '_auto_%02d.png' % actions))
        if a.steps and actions >= a.steps:
            log('到达步数上限，停')
            break
        time.sleep(a.interval)
    return 0


if __name__ == '__main__':
    sys.exit(main())
