# -*- coding: utf-8 -*-
"""策略界面：格子定位 + 推荐 + 红框数据

网格标定来源：1900x1119 的「选择策略」截图（对应游戏 1920x1080）
格子为 4 列 × 4 行（首屏），顺序与 PRTS 策略表一致：
    第 n 格（0-based，行优先）= strategies[n]
"""
import io, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')

with io.open(os.path.join(DATA, 'strategies.json'), encoding='utf-8') as f:
    STRATS = json.load(f)

# 比例坐标（相对整屏宽高），由 1900x1119 截图反推
GRID = {
    'x0': 0.5063, 'y0': 0.2842,
    'pitch_x': 0.1084, 'pitch_y': 0.1841,
    'tile': 0.0895,
    'cols': 4, 'rows': 4,
}

WORDS = {'资金': 1, '刷新': 1, '装备': 1, '免费': 1, '额外获得': 1,
         '层数': 1, '叠加': 1, '攻击力': 1, '精锐': 1, '复活': 1, '护盾': 1}


def cells(w, h, scroll_rows=0):
    """返回 [(idx, x1,y1,x2,y2)]，idx 为全局序号（0-based）"""
    out = []
    tw = GRID['tile'] * w
    for r in range(GRID['rows']):
        for c in range(GRID['cols']):
            idx = (r + scroll_rows) * GRID['cols'] + c
            x1 = (GRID['x0'] + c * GRID['pitch_x']) * w
            y1 = (GRID['y0'] + r * GRID['pitch_y']) * h
            out.append((idx, x1, y1, x1 + tw, y1 + tw))
    return out


def score_strat(s, cov):
    t = s.get('effect', '')
    sc = 0.0
    why = []
    hp = s.get('hp') or 25
    sc += min(18, max(0, (hp - 22) * 1.6))
    if cov and cov in t:
        sc += 30
        why.append('服务' + cov)
    if any(k in t for k in ('资金', '刷新', '装备', '免费', '额外获得')):
        sc += 14
        why.append('经济')
    if ('层数' in t) or ('叠加' in t):
        sc += 12
        why.append('叠层')
    if any(k in t for k in ('攻击力', '精锐', '复活', '护盾', '生命上限')):
        sc += 10
        why.append('战力')
    if ('3、4或5种' in t) or ('多种盟约' in t):
        sc += 8
        why.append('多盟约')
    for c in ('炎', '萨尔贡', '维多利亚', '谢拉格', '阿戈尔', '叙拉古',
              '卡西米尔', '乌萨斯', '伊比利亚', '莱塔尼亚'):
        if c in t and c != cov:
            sc -= 6
            break
    return sc, why


def recommend(main_cov, topn=3):
    rows = []
    for i, s in enumerate(STRATS):
        sc, why = score_strat(s, main_cov)
        rows.append({'idx': i, 'name': s['name'], 'owner': s['owner'],
                     'hp': s['hp'], 'score': round(sc, 1), 'why': why})
    rows.sort(key=lambda x: -x['score'])
    return rows[:topn]
