# -*- coding: utf-8 -*-
"""卫戍协议 实时识别核心：帧 -> 结构化状态。

只依赖 rapidocr-onnxruntime + Pillow + numpy。
"""
import io, json, os, re, sys, difflib

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, 'data')

# ---------- 内置词表 ----------
COV_NAMES = [
    "炎", "萨尔贡", "维多利亚", "谢拉格", "阿戈尔", "叙拉古", "卡西米尔",
    "乌萨斯", "伊比利亚", "莱塔尼亚",
    "精准", "迅捷", "灵巧", "坚守", "助力", "远见", "奇迹", "投资人",
    "突袭", "不屈", "调和", "协防干员", "独行", "绝技", "聚合", "奥术",
]

EQUIP_NAMES = [
    "维式重锤", "坚守盾牌", "盟约之币", "随身身份牌", "源石溶剂", "虹彩活血饮料",
    "雪祀之衣", "不屈弹射器", "紧急调度券", "战栗维式重锤", "萨尔贡浓茶",
    "精打细算玩偶", "简易通讯机", "见钱眼开玩偶", "卫戍推荐信", "聚合急救箱",
    "灵巧涡轮手套", "叙拉古正装", "精准狙击镜", "炎国短刀", "迅捷作战粮",
    "歌利亚头盔", "阿戈尔重刃", "奥术法阵", "坚固维式重锤", "加速维式重锤",
    "突袭手雷", "驮兽储蓄罐", "乌萨斯呼吸器", "多功能补剂", "伊比利亚骨刺刀",
    "定期存折", "不退者之盾", "寻呼模块", "蜂鸣器", "伪装服", "卡西米尔竞技旗",
    "灼燃维式重锤", "护盾无人机", "M3茧甲", "莱塔尼亚小鼓", "谢拉格不融冰",
    "可靠怀表", "一次性促销券", "驱逐者警棍", "动能单手弩", "汲取者之喙",
    "双模机械臂", "信标", "拟态物质", "博士投影", "天马之盔", "电流维式重锤",
    "佣兵名牌", "人事部记录", "瓶装烈性反应", "不退者力场", "驱逐者瓦斯",
    "投机骰子", "天马之枪", "人事部文档", "变形同构体", "动能加速器",
    "汲取者之心", "终极维式重锤", "不退者卫护系统", "动能轰击弩", "汲取者之镰",
    "驱逐者防暴装备", "天马之耀",
]

# OCR 常见误字修正（针对游戏内字体）
FIX = {
    "竟技": "竞技", "奥木": "奥术", "迅揵": "迅捷", "坚守盾": "坚守盾牌",
}


def _load_ops():
    p = os.path.join(DATA_DIR, 'ops.json')
    with io.open(p, encoding='utf-8') as f:
        ops = json.load(f)
    return [o['name'] for o in ops if o.get('tier') != '—']


OP_NAMES = _load_ops()


def norm(s):
    s = (s or '').strip()
    s = s.replace('·', '').replace(' ', '').replace('　', '')
    s = re.sub(r'[\[\]【】()（）<>《》\.。,，:：;；\'"`~!！?？|/\\_\-—+*#@$%^&]', '', s)
    return s


_OP_NORM = {norm(n): n for n in OP_NAMES}
_COV_NORM = {norm(n): n for n in COV_NAMES}
_EQ_NORM = {norm(n): n for n in EQUIP_NAMES}
_ALL = list(_OP_NORM.items()) + list(_EQ_NORM.items())


try:
    _NICK = json.load(io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'nicknames.json'), encoding='utf-8'))
except Exception:
    _NICK = {}


def match_op(text, cutoff=0.72):
    """把 OCR 文本匹配到干员名。返回 (name, score) 或 (None, 0)。"""
    t = norm(text)
    if t in _NICK:
        return _NICK[t], 1.0
    if not t:
        return None, 0.0
    if t in _OP_NORM:
        return _OP_NORM[t], 1.0
    best, bs = None, 0.0
    for key, name in _ALL:
        if abs(len(key) - len(t)) > 2:
            continue
        s = difflib.SequenceMatcher(None, t, key).ratio()
        # 包含关系加权
        if key in t or t in key:
            s = max(s, 0.86)
        if s > bs:
            best, bs = name, s
    if bs >= cutoff:
        return best, bs
    return None, bs


def match_cov(text, cutoff=0.7):
    t = norm(text)
    if not t:
        return None
    if t in _COV_NORM:
        return _COV_NORM[t]
    best, bs = None, 0.0
    for key, name in _COV_NORM.items():
        s = difflib.SequenceMatcher(None, t, key).ratio()
        if key in t:
            s = max(s, 0.9)
        if s > bs:
            best, bs = name, s
    return best if bs >= cutoff else None


def digits_only(text):
    return re.sub(r'\D', '', text or '')


# ---------- OCR 封装 ----------
def auto_threads():
    """按核数给 ONNX 线程数：默认给了会自旋，太多费电、太少慢"""
    try:
        import os as _os
        env = _os.environ.get('SPG_THREADS')
        if env:
            return max(1, int(env))
        n = _os.cpu_count() or 4
        return 4 if n >= 8 else 2
    except Exception:
        return 2


class Engine:
    def __init__(self, threads=None):
        from rapidocr_onnxruntime import RapidOCR
        self.threads = int(threads or auto_threads())
        try:
            self.ocr = RapidOCR(use_angle_cls=False, intra_op_num_threads=self.threads)
        except TypeError:
            self.ocr = RapidOCR(use_angle_cls=False)

    def warmup(self):
        """空跑一次，避免第一帧推理特别慢"""
        try:
            from PIL import Image as _I
            self.run(_I.new('RGB', (320, 80), (20, 20, 20)), scale=1, pre='auto')
        except Exception:
            pass

    def run(self, img, scale=2, pre='auto'):
        """img: PIL.Image -> [{text,score,x,y,w,h,cx,cy}]"""
        if img.width < 160:
            return []
        if pre == 'auto':
            from PIL import ImageOps
            img = ImageOps.autocontrast(img.convert('L'))
        w, h = img.size
        if scale != 1:
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
        res, _ = self.ocr(np.array(img.convert('RGB')))
        out = []
        if not res:
            return out
        for box, txt, score in res:
            xs = [p[0] / scale for p in box]
            ys = [p[1] / scale for p in box]
            x0, x1 = min(xs), max(xs)
            y0, y1 = min(ys), max(ys)
            out.append({
                'text': (txt or '').strip(),
                'score': float(score),
                'x': x0, 'y': y0, 'w': x1 - x0, 'h': y1 - y0,
                'cx': (x0 + x1) / 2, 'cy': (y0 + y1) / 2,
            })
        return out


# ---------- ROI 定义（相对整帧的比例） ----------
# 依据 1280x720 实机录制帧标定；坐标以「游戏画面」左上角为原点
ROI = {
    'topbar':  (0.20, 0.008, 0.85, 0.066),  # 回合 / 资金
    'cov':     (0.10, 0.040, 0.92, 0.260),  # 盟约条（图标+层数+名字）
    'hand':    (0.045, 0.880, 0.92, 0.995),  # 手牌：只取名字条
}
# 回合数字所在的小框（整条顶栏一起认时常漏），以及顶栏右侧的资金数字兜底区域
ROUND_BOX = (0.296, 0.010, 0.400, 0.074)
GOLD_TEXT = (0.560, 0.010, 0.680, 0.074)


def crop_rel(img, box):
    w, h = img.size
    x0, y0, x1, y1 = box
    return img.crop((int(w * x0), int(h * y0), int(w * x1), int(h * y1)))


def parse_covenants(items, roi_w):
    """盟约条：图标 + 上/下方白色层数 + 下方盟约名。
    数字与名字按 x 就近配对（数字一般在名字正上方）。返回 {name: layers}
    """
    names, nums = [], []
    for it in items:
        raw = it['text']
        d = digits_only(raw)
        has_cjk = bool(re.search(r'[\u4e00-\u9fff]', raw))
        if d and not has_cjk:
            if len(d) <= 4:
                nums.append((int(d), it))
            continue
        if d and has_cjk:
            # 形如「11维多利亚」：拆出数字 + 名字
            cn = re.sub(r'[\d\s\.\*,，]', '', raw)
            c = match_cov(cn)
            if c:
                names.append((c, it))
                if len(d) <= 4:
                    nums.append((int(d), it))
            continue
        c = match_cov(raw)
        if c:
            names.append((c, it))

    result = {}
    used = set()
    for cname, nit in names:
        best, bestd, bi = None, 1e9, -1
        for i, (val, it) in enumerate(nums):
            if i in used:
                continue
            dx = abs(it['cx'] - nit['cx'])
            dy = abs(it['cy'] - nit['cy'])
            if dx > roi_w * 0.075 or dy > 60:
                continue
            dist = dx + dy * 0.5
            if dist < bestd:
                bestd, best, bi = dist, val, i
        if best is not None:
            result[cname] = best
            used.add(bi)
        else:
            result.setdefault(cname, 0)
    return result


def parse_hand(items, roi_w):
    """手牌：返回 [{'name','kind','score'}]。
    排除盟约名（那些是卡面上的盟约标签）与 UI 词。
    """
    out = []
    seen = set()
    ui_words = {'升级', '刷新', '冻结', '收起', '查看', '准备就绪', '回合', '资金', '生命',
                '剩余可放置角色', '本局禁用', '附加盟约', '已拥有', '结束', '确定', '取消'}
    for it in items:
        raw = norm(it['text'])
        if not raw or raw in ui_words:
            continue
        # 卡面盟约标签：整串正好是盟约名 → 跳过
        if raw in _COV_NORM:
            continue
        if match_cov(it['text'], cutoff=0.95) and len(raw) <= 4:
            continue
        n, s = match_op(it['text'])
        if not n:
            continue
        if len(raw) <= 1:
            continue
        if n in seen:
            continue
        seen.add(n)
        kind = 'equip' if n in _EQ_NORM.values() else 'op'
        out.append({'name': n, 'kind': kind, 'score': round(s, 3),
                    'text': it['text'], 'cx': round(it['cx'], 1), 'cy': round(it['cy'], 1)})
    out.sort(key=lambda d: d['cx'])
    return out


def parse_topbar(items, roi_w, roi_x0=0.0, full_w=None):
    """顶栏：回合在左侧；`a/b` 是目标生命。资金不在这里（右下角金条）。"""
    res = {'round': None, 'gold': None, 'life': None, 'life_max': None}
    if not items:
        return res
    W = max(1.0, full_w or roi_w)
    for it in items:
        txt = it['text'] or ''
        if re.search(r'[\u4e00-\u9fff]', txt) and ('回合' not in txt):
            continue
        pair = re.search(r'(\d+)\s*/\s*(\d+)', txt)
        if pair and res['life'] is None:
            res['life'] = int(pair.group(1))
            res['life_max'] = int(pair.group(2))
            continue
        groups = re.findall(r'\d+', txt)
        if not groups:
            continue
        r = (it['cx'] + roi_x0 * W) / W
        v = int(groups[-1])
        if 0.30 <= r <= 0.48 and res['round'] is None:
            res['round'] = v
        elif 0.50 <= r <= 0.63 and res['life'] is None:
            # 顶栏中间「城堡图标 + 数字」= 当前生命
            res['life'] = v
    return res


def analyze(img, engine, debug=False):
    """整帧 -> 状态 dict"""
    W, H = img.size
    cov_img = crop_rel(img, ROI['cov'])
    hand_img = crop_rel(img, ROI['hand'])
    top_img = crop_rel(img, ROI['topbar'])

    cov_items = engine.run(cov_img, scale=3, pre='auto')
    hand_items = engine.run(hand_img, scale=2, pre='auto')
    top_items = engine.run(top_img, scale=3, pre='auto')

    covs = parse_covenants(cov_items, cov_img.width)
    hand = parse_hand(hand_items, hand_img.width)
    top = parse_topbar(top_items, top_img.width, ROI['topbar'][0], W)

    gold = None
    try:
        import spg_gold
        gold = spg_gold.read_gold(img, engine)
    except Exception:
        gold = None

    state = {
        'size': [W, H],
        'round': top['round'],
        'gold': gold,
        'life': top['life'],
        'life_max': top['life_max'],
        'covenants': covs,
        'hand': hand,
        'ops': [h['name'] for h in hand if h['kind'] == 'op'],
        'equips': [h['name'] for h in hand if h['kind'] == 'equip'],
    }
    if debug:
        state['_cov_items'] = cov_items
        state['_top_items'] = top_items
        state['_hand_items'] = hand_items
    return state


if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else None
    eng = Engine()
    if target:
        img = Image.open(target)
        st = analyze(img, eng, debug=True)
        out = target + '.state.json'
        with io.open(out, 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False, indent=1)
        print('wrote', out)

def analyze_parallel(img, engines, do_gold=True):
    """三块区域并行 OCR（每块用独立引擎，onnxruntime 会释放 GIL）"""
    from concurrent.futures import ThreadPoolExecutor
    W, H = img.size
    cov_img = crop_rel(img, ROI['cov'])
    hand_img = crop_rel(img, ROI['hand'])
    top_img = crop_rel(img, ROI['topbar'])
    while len(engines) < 3:
        engines.append(engines[0])
    with ThreadPoolExecutor(max_workers=3) as ex:
        fc = ex.submit(engines[0].run, cov_img, 2, 'auto')
        fh = ex.submit(engines[1].run, hand_img, 2, 'auto')
        ft = ex.submit(engines[2].run, top_img, 2, 'auto')
        cov_items = fc.result()
        hand_items = fh.result()
        top_items = ft.result()
    covs = parse_covenants(cov_items, cov_img.width)
    hand = parse_hand(hand_items, hand_img.width)
    top = parse_topbar(top_items, top_img.width, ROI['topbar'][0], W)
    gold = None
    if do_gold:
        try:
            import spg_gold
            gold = spg_gold.read_gold(img, engines[0])
        except Exception:
            gold = None
    return {
        'size': [W, H],
        'round': top['round'],
        'gold': gold,
        'life': top['life'],
        'life_max': top['life_max'],
        'covenants': covs,
        'hand': hand,
        'ops': [h['name'] for h in hand if h['kind'] == 'op'],
        'equips': [h['name'] for h in hand if h['kind'] == 'equip'],
    }

def _sig(img):
    """区域指纹：缩到 24x8 灰度后取字节"""
    return img.convert('L').resize((24, 8)).tobytes()


def _sig_close(a, b, tol=7):
    """高帧率时画面有轻微抖动，允许平均差值小于 tol 视为同一帧"""
    if not a or not b or len(a) != len(b):
        return False
    if a == b:
        return True
    diff = 0
    for x, y in zip(a, b):
        diff += x - y if x > y else y - x
    return diff / len(a) < tol


def analyze_cached(img, engines, cache, do_gold=True):
    """按区域指纹缓存：区域没变就复用上次 OCR 结果，只有变了的区域才算"""
    from concurrent.futures import ThreadPoolExecutor
    W, H = img.size
    while len(engines) < 3:
        engines.append(engines[0])
    regions = {}
    for name in ('cov', 'hand', 'topbar'):
        roi = ROI[name]
        regions[name] = img.crop((int(W * roi[0]), int(H * roi[1]),
                                  int(W * roi[2]), int(H * roi[3])))
    # 回合数字在深色小框里，整条顶栏一起认时常被漏掉，单独再切一块
    regions['roundbox'] = img.crop((int(W * ROUND_BOX[0]), int(H * ROUND_BOX[1]),
                                    int(W * ROUND_BOX[2]), int(H * ROUND_BOX[3])))
    if do_gold:
        regions['gold'] = img.crop((int(W * 0.70), int(H * 0.58), W, int(H * 0.95)))
        regions['goldtxt'] = img.crop((int(W * GOLD_TEXT[0]), int(H * GOLD_TEXT[1]),
                                       int(W * GOLD_TEXT[2]), int(H * GOLD_TEXT[3])))
    sigs = {k: _sig(v) for k, v in regions.items()}
    todo = [k for k in regions if not _sig_close(cache.get(k + '_sig'), sigs[k])]
    tasks = []
    with ThreadPoolExecutor(max_workers=len(todo) or 1) as ex:
        for k in todo:
            if k in ('gold', 'goldtxt'):
                continue
            sc = 3 if k == 'roundbox' else 2
            tasks.append((k, ex.submit(engines[0].run, regions[k], sc, 'auto')))
        for k, f in tasks:
            cache[k + '_items'] = f.result()
            cache[k + '_sig'] = sigs[k]
    cov_img, hand_img, top_img = regions['cov'], regions['hand'], regions['topbar']
    covs = parse_covenants(cache.get('cov_items') or [], cov_img.width)
    hand = parse_hand(cache.get('hand_items') or [], hand_img.width)
    top = parse_topbar(cache.get('topbar_items') or [], top_img.width, ROI['topbar'][0], W)
    if top['round'] is None:
        for it in (cache.get('roundbox_items') or []):
            ds = re.findall(r'\d+', it['text'] or '')
            if ds:
                top['round'] = int(ds[-1])
    gold = cache.get('gold', None)
    if do_gold and 'gold' in todo:
        try:
            import spg_gold
            gold = spg_gold.read_gold(img, engines[0])
            cache['gold'] = gold
        except Exception:
            gold = None
    return {
        'size': [W, H], 'round': top['round'], 'gold': gold,
        'life': top['life'], 'life_max': top['life_max'],
        'covenants': covs, 'hand': hand,
        'ops': [h['name'] for h in hand if h['kind'] == 'op'],
        'equips': [h['name'] for h in hand if h['kind'] == 'equip'],
    }
