# -*- coding: utf-8 -*-
"""目标层数演算：给定「目标盟约 + 目标层数」，估算能不能达成、还缺什么

模型（经用户确认）：
- 层数只在盟约激活后增长，**只增不减**
- 每个 S.W.E.E.P. 策略**一回合最多用一次**
- 每回合产出 = Σ 场上叠层卡的固定产出 + 指令加成

用法：
    from spg_goal import evaluate, simulate
    simulate("伊比利亚", timeline={3:4, 6:4, 8:12, 10:20, 12:24}, cmds=[...])
"""
import io
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'data')
MAX_ROUND = 15

_ENG = None
_CMD = None


def _load(name):
    try:
        with io.open(os.path.join(DATA, name), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def engines():
    global _ENG
    if _ENG is None:
        _ENG = _load('stack_engines.json')
    return _ENG


def cmds():
    global _CMD
    if _CMD is None:
        d = _load('sweep_cmds.json')
        _CMD = {it['skill']: it.get('layer') for it in (d.get('items') or []) if it.get('layer')}
    return _CMD


def card_output(cov, name):
    """某张卡对某盟约的每回合固定产出（没数据返回 0）"""
    e = engines().get(cov) or {}
    return int((e.get('per_round') or {}).get(name, 0))


def cmd_layer(cmd_name, tier=3, base=0, extra_value=None):
    """某条指令每回合能加多少层（按「一回合一次」）"""
    eff = cmds().get(cmd_name)
    if not eff or eff.get('kind') not in ('flat', 'extra_trigger'):
        return 0
    amt = int(eff.get('amount') or 0)
    if eff.get('by_tier'):
        amt = tier
    cd = max(1, int(eff.get('cooldown') or 1))
    if eff['kind'] == 'extra_trigger':
        # 额外触发一次 = 被指定那张卡自己的一回合产出（不是全队产出）
        return int(extra_value if extra_value is not None else 0)
    return amt // cd if cd > 1 else amt


def simulate(cov, timeline=None, cmd_names=None, from_round=None, rounds=MAX_ROUND, start=0,
             extra_value=None):
    """timeline: {回合: 该回合起新增的每回合产出}；返回每回合明细

    指令按 cmd_from 生效（默认 timeline 里第一个出现的回合）
    """
    timeline = timeline or {}
    cmd_names = cmd_names or []
    cmd_from = from_round or (min(timeline) if timeline else 1)
    total = int(start)
    rows = []
    for r in range(1, rounds + 1):
        gain = sum(v for rr, v in timeline.items() if rr <= r)
        if r >= cmd_from:
            for c in cmd_names:
                gain += cmd_layer(c, base=gain, extra_value=extra_value)
        gain = max(0, int(gain))
        total += gain
        rows.append({'round': r, 'gain': gain, 'total': total})
    return rows


def evaluate(cov, target, current=0, round_now=1, owned=None, cmd_names=None):
    """判断目标能不能达成，返回结构化建议"""
    owned = owned or []
    e = engines().get(cov) or {}
    per_round = e.get('per_round') or {}
    missing = [n for n in (e.get('core') or []) if n not in owned]
    have_gain = sum(int(per_round.get(n, 0)) for n in owned if n in per_round)
    cmd_gain = 0
    for c in (cmd_names or []):
        cmd_gain += cmd_layer(c, base=have_gain)
    remain = max(0, MAX_ROUND - round_now + 1)
    projected = int(current) + (have_gain + cmd_gain) * remain
    best_gain = sum(int(v) for v in per_round.values()) + cmd_gain
    best = int(current) + best_gain * remain
    return {
        'cov': cov, 'target': int(target), 'current': int(current),
        'round_now': round_now, 'remain': remain,
        'gain_now': have_gain + cmd_gain, 'gain_best': best_gain,
        'projected': projected, 'best_case': best,
        'achievable': projected >= target,
        'achievable_best': best >= target,
        'missing': missing[:6],
        'advice': _advice(cov, target, current, projected, best, missing, have_gain, cmd_gain),
    }


def _advice(cov, target, current, projected, best, missing, gain_now, cmd_gain):
    if projected >= target:
        return '按当前节奏可行（预计 %d ≥ 目标 %d）' % (projected, target)
    if best >= target:
        gap = target - current
        return ('当前 %d 不够，补齐核心卡后可达 %d；缺：%s' %
                (projected, best, '、'.join(missing[:3]) or '（指令）'))
    return ('目标偏高：满配上限约 %d，达不到 %d。建议先冲更低目标或换打法' % (best, target))


if __name__ == '__main__':
    # 自测：三场景对照（应分别约 404 / 599 / 1054）
    A = {3: 4, 6: 4, 8: 12, 10: 20, 12: 24}
    a = simulate('伊比利亚', A)[-1]['total']
    b = simulate('伊比利亚', A, ['东之极道', '条文修正', '强制休整'],
                 from_round=8, extra_value=24)[-1]['total']
    C = {3: 4, 6: 18, 8: 42, 12: 66}
    c = simulate('伊比利亚', C, ['东之极道', '条文修正', '强制休整'],
                 from_round=7, extra_value=24)[-1]['total']
    print('A 常规 =', a, ' B +指令 =', b, ' C 极速 =', c)
    print(evaluate('伊比利亚', 999, current=120, round_now=6, owned=['旅骨', '海沫', '深靛'],
                   cmd_names=['东之极道', '条文修正']))
