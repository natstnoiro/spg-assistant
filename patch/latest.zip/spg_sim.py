# -*- coding: utf-8 -*-
"""层数推演：给定主盟约 + 目标层数，算出需要谁、每回合多少层、要几回合。

用法:
    python spg_sim.py 莱塔尼亚 999
    python spg_sim.py --all 999
"""
import io, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, 'data')

OPS = json.load(io.open(os.path.join(D, 'ops_full.json'), encoding='utf-8'))
COVS = {c['name']: c for c in json.load(io.open(os.path.join(D, 'covs_full.json'), encoding='utf-8'))}
EQUIP = json.load(io.open(os.path.join(D, 'equipment.json'), encoding='utf-8'))

RATE = {'获得时': 1.7, '进入休整期时': 1.0, '休整期结束时': 1.0, '战斗开始时': 1.0,
        '战斗中': 1.9, '部署时': 1.6, '售出时': 1.2, '刷新时': 1.2, 'other': 0.9}
from spg_score import CORE


def throughput(op, cov, elite=True):
    g = (op.get('gains_e') if elite else op.get('gains_i')) or {}
    cap = (op.get('cap_e') if elite else op.get('cap_i')) or 0
    if cov not in g:
        return 0.0
    per = g[cov] * RATE.get(op.get('trig'), 0.9)
    if cap:
        per = min(per, cap)
    return per


def engines(cov):
    rows = []
    for o in OPS:
        if o.get('kind') == 'special':
            continue
        t = throughput(o, cov)
        if t > 0:
            rows.append({'name': o['name'], 'tp': round(t, 1), 'tier': o['tier'],
                         'trig': o.get('trig'), 'gain': (o.get('gains_e') or {}).get(cov),
                         'cap': o.get('cap_e'), 'covs': o['covs']})
    rows.sort(key=lambda x: -x['tp'])
    return rows


def equip_bonus(cov):
    """装备加成：通用类（随身身份牌/卫戍推荐信/多功能补剂）+ 点名类"""
    out = []
    for e in EQUIP:
        t = e.get('effect') or ''
        if '层数' not in t:
            continue
        m = re.findall(r'层数\s*\+?(\d+)', t)
        if not m:
            continue
        add = max(int(x) for x in m)
        generic = ('所属盟约' in t) or ('无须激活' in t) or ('无需激活' in t)
        if generic or (cov in t):
            out.append({'name': e['name'], 'tier': e['tier'], 'add': add,
                        'generic': generic, 'effect': re.sub(r'\s+', ' ', t)[:60]})
    out.sort(key=lambda x: -x['add'])
    return out


def sim(cov, target=999, turns=14, buys=6):
    """buys: 每回合额外买装备次数（随身身份牌=装备时+6 层，可反复买）"""
    need = COVS.get(cov, {}).get('need', 3)
    rows = engines(cov)
    if not rows:
        return {'cov': cov, 'error': '没有能叠该盟约的干员'}
    top = rows[:6]
    base = sum(r['tp'] for r in top)
    if len(top) >= 6:
        base *= 1.3
    eq = equip_bonus(cov)
    # 通用装备：随身身份牌 +6/次（可反复买），卫戍推荐信 +2/回合，补剂 +12/战斗
    per_buy = max([e['add'] for e in eq if e['generic']] or [0])
    buy_gain = per_buy * buys
    steady = sum(e['add'] for e in eq if e['generic'] and '休整期' in (e['effect'] or ''))
    total = base + buy_gain + steady
    t = max(1, int(-(-target // max(1e-6, total))))
    return {
        'cov': cov, 'need': need, 'target': target,
        'team': top, 'base': round(base, 1), 'buy_gain': buy_gain,
        'per_turn': round(total, 1), 'turns_needed': t, 'within': t <= turns,
        'equip': eq[:4], 'pool': len(rows), 'buys': buys,
    }


def show(r):
    if r.get('error'):
        print(f"{r['cov']}: {r['error']}")
        return
    print(f"\n=== {r['cov']}  目标 {r['target']} 层（激活需 {r['need']} 人，池子 {r['pool']} 人）")
    print(f"  阵容：" + ' / '.join(f"{t['name']}({t['tp']})" for t in r['team']))
    print(f"  干员叠层 {r['base']}/回合 + 刷装备 {r['buy_gain']}/回合 = {r['per_turn']}/回合")
    print(f"  → 需要 {r['turns_needed']} 回合"
          f"{'  ✅ 14 回合内可达成' if r['within'] else '  ❌ 14 回合内做不到'}"
          f"（按每回合买 {r['buys']} 件装备）")
    if r['equip']:
        print("  关键装备：" + ' / '.join(f"{e['name']}(+{e['add']})" for e in r['equip']))


if __name__ == '__main__':
    if len(sys.argv) >= 2 and sys.argv[1] == '--all':
        target = int(sys.argv[2]) if len(sys.argv) > 2 else 999
        for c in CORE:
            show(sim(c, target))
    else:
        cov = sys.argv[1] if len(sys.argv) > 1 else '莱塔尼亚'
        target = int(sys.argv[2]) if len(sys.argv) > 2 else 999
        show(sim(cov, target))
