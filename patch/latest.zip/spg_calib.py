# -*- coding: utf-8 -*-
"""自动校准：把窗口画面在屏幕截图里模板匹配，得到真实左上角

解决 DPI/边框导致的 ClientToScreen 偏移。
"""
import numpy as np
import cv2
from PIL import Image, ImageGrab

import spg_grab


def locate(hwnd, debug=False):
    win = spg_grab.capture(hwnd, 'bitblt')
    if win is None:
        return None
    screen = ImageGrab.grab(all_screens=True)
    W, H = win.size
    # 取窗口中部一块做模板（避开边缘和动态区域）
    x0, y0 = int(W * 0.30), int(H * 0.42)
    x1, y1 = int(W * 0.62), int(H * 0.60)
    tpl = win.crop((x0, y0, x1, y1)).convert('L')
    sc = 0.5
    tpl_s = tpl.resize((int(tpl.width * sc), int(tpl.height * sc)), Image.LANCZOS)
    scr = screen.convert('L')
    scr_np = np.asarray(scr)
    r = cv2.matchTemplate(scr_np, np.asarray(tpl_s), cv2.TM_CCOEFF_NORMED)
    _, mx, _, loc = cv2.minMaxLoc(r)
    if mx < 0.55:
        return None
    cx = loc[0] / sc
    cy = loc[1] / sc
    ox = int(round(cx - x0))
    oy = int(round(cy - y0))
    if debug:
        print(f'[calib] score={mx:.3f} origin=({ox},{oy})')
    return ox, oy, W, H, mx


if __name__ == '__main__':
    r = spg_grab.find_hwnd()
    if r:
        print(locate(r[0], debug=True))
